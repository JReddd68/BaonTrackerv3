#include "baon_core.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iterator>
#include <sstream>

namespace baon {
namespace {

const char* kPeso = "\xE2\x82\xB1";  // UTF-8 for the peso sign

bool isDigit(char c) { return c >= '0' && c <= '9'; }

int daysInMonth(int y, int m) {
    static const int d[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (m == 2) return ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) ? 29 : 28;
    return d[m - 1];
}

bool parseIso(const std::string& s, int& y, int& m, int& d) {
    if (s.size() != 10 || s[4] != '-' || s[7] != '-') return false;
    const int digitPos[] = {0, 1, 2, 3, 5, 6, 8, 9};
    for (int i : digitPos)
        if (!isDigit(s[i])) return false;
    y = std::atoi(s.substr(0, 4).c_str());
    m = std::atoi(s.substr(5, 2).c_str());
    d = std::atoi(s.substr(8, 2).c_str());
    return m >= 1 && m <= 12 && d >= 1 && d <= daysInMonth(y, m);
}

// Days since 1970-01-01 (Howard Hinnant's civil-date algorithm).
long long daysFromCivil(int y, int m, int d) {
    y -= m <= 2;
    const long long era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = static_cast<unsigned>(y - era * 400);
    const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + static_cast<long long>(doe) - 719468;
}

bool isoToDays(const std::string& iso, long long& out) {
    int y, m, d;
    if (!parseIso(iso, y, m, d)) return false;
    out = daysFromCivil(y, m, d);
    return true;
}

std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && (s[a] == ' ' || s[a] == '\t' || s[a] == '\r' || s[a] == '\n')) a++;
    while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t' || s[b - 1] == '\r' || s[b - 1] == '\n')) b--;
    return s.substr(a, b - a);
}

std::string lower(std::string s) {
    for (char& c : s)
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
    return s;
}

std::string truncateUtf8(const std::string& s, size_t maxCodePoints) {
    size_t count = 0;
    for (size_t i = 0; i < s.size(); i++) {
        if ((static_cast<unsigned char>(s[i]) & 0xC0) != 0x80) {
            if (count == maxCodePoints) return s.substr(0, i);
            count++;
        }
    }
    return s;
}

std::string cleanNote(const std::string& raw) {
    std::string s = raw;
    for (char& c : s)
        if (c == '\r' || c == '\n') c = ' ';
    return truncateUtf8(trim(s), 60);
}

std::string normalizeCategory(const std::string& raw) {
    const std::string c = lower(trim(raw));
    if (c == "food") return "Food";
    if (c == "school") return "School";
    if (c == "personal") return "Personal";
    if (c == "strolling") return "Strolling";
    return "Personal";
}

// Same behaviour as JavaScript parseFloat(): longest numeric prefix, otherwise NaN.
double jsParseFloat(const std::string& in) {
    const std::string s = trim(in);
    size_t i = 0;
    if (i < s.size() && (s[i] == '+' || s[i] == '-')) i++;
    size_t digitsStart = i;
    while (i < s.size() && isDigit(s[i])) i++;
    size_t intDigits = i - digitsStart;
    size_t fracDigits = 0;
    if (i < s.size() && s[i] == '.') {
        size_t j = i + 1;
        while (j < s.size() && isDigit(s[j])) j++;
        fracDigits = j - (i + 1);
        if (intDigits > 0 || fracDigits > 0) i = j;
    }
    if (intDigits == 0 && fracDigits == 0) return std::nan("");
    if (i < s.size() && (s[i] == 'e' || s[i] == 'E')) {
        size_t j = i + 1;
        if (j < s.size() && (s[j] == '+' || s[j] == '-')) j++;
        size_t expStart = j;
        while (j < s.size() && isDigit(s[j])) j++;
        if (j > expStart) i = j;
    }
    return std::strtod(s.substr(0, i).c_str(), nullptr);
}

// Strip commas and the peso sign, then parse (mirrors .replace(/[₱,]/g, '')).
double parseMoney(const std::string& in) {
    std::string out;
    const std::string peso = kPeso;
    for (size_t i = 0; i < in.size();) {
        if (in.compare(i, peso.size(), peso) == 0) { i += peso.size(); continue; }
        if (in[i] == ',') { i++; continue; }
        out += in[i++];
    }
    return jsParseFloat(out);
}

std::vector<std::string> parseCsvLine(const std::string& line) {
    std::vector<std::string> result;
    std::string cur;
    bool inQuotes = false;
    for (size_t i = 0; i < line.size(); i++) {
        const char c = line[i];
        if (c == '"') {
            if (inQuotes && i + 1 < line.size() && line[i + 1] == '"') { cur += '"'; i++; }
            else inQuotes = !inQuotes;
        } else if (c == ',' && !inQuotes) {
            result.push_back(trim(cur));
            cur.clear();
        } else {
            cur += c;
        }
    }
    result.push_back(trim(cur));
    return result;
}

std::string csvField(const std::string& v) {
    if (v.find_first_of("\",\r\n") == std::string::npos) return v;
    std::string out = "\"";
    for (char c : v) {
        if (c == '"') out += "\"\"";
        else out += c;
    }
    return out + "\"";
}

std::string jsonEscape(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof buf, "\\u%04x", c);
                    out += buf;
                } else {
                    out += static_cast<char>(c);
                }
        }
    }
    return out;
}

std::string num(double v, int decimals = 2) {
    if (!std::isfinite(v)) v = 0;
    char buf[64];
    std::snprintf(buf, sizeof buf, "%.*f", decimals, v);
    return buf;
}

}  // namespace

// ---------------------------------------------------------------- helpers

std::string Core::today() const {
    if (!todayOverride_.empty()) return todayOverride_;
    std::time_t t = std::time(nullptr);
    std::tm lt{};
    localtime_r(&t, &lt);
    char buf[40];
    std::snprintf(buf, sizeof buf, "%04d-%02d-%02d", lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday);
    return buf;
}

std::string Core::newId() { return "tx_" + std::to_string(nextId_++); }

void Core::setTodayOverride(const std::string& iso) {
    std::lock_guard<std::mutex> lk(mu_);
    todayOverride_ = iso;
}

// ------------------------------------------------------------- persistence

void Core::init(const std::string& storagePath) {
    std::lock_guard<std::mutex> lk(mu_);
    path_ = storagePath;
    std::ifstream in(path_, std::ios::binary);
    if (!in) return;  // first launch: stay at zero
    std::string text((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    importLocked(text);
}

void Core::saveLocked() const {
    if (path_.empty()) return;
    const std::string tmp = path_ + ".tmp";
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out) return;
        out << exportLocked(false);
        if (!out) return;
    }
    std::rename(tmp.c_str(), path_.c_str());
}

// ------------------------------------------------------------------ metrics

Metrics Core::computeLocked() const {
    Metrics m;
    m.totalDaysInCycle = (cycle_ == "weekly") ? 7 : 30;
    for (const auto& e : expenses_) m.totalSpent += e.amount;
    m.remaining = allowance_ - m.totalSpent;
    m.percentUsed = allowance_ > 0 ? (m.totalSpent / allowance_) * 100.0 : (m.totalSpent > 0 ? 100.0 : 0.0);

    m.savingsGoal = std::max(0.0, savingsGoal_);
    m.maxAllowedSpending = allowance_ - m.savingsGoal;
    m.safeSpendRemaining = m.maxAllowedSpending - m.totalSpent;
    m.savingsPercentOfAllowance = allowance_ > 0 ? (m.savingsGoal / allowance_) * 100.0
                                                 : (m.savingsGoal > 0 ? 100.0 : 0.0);

    // The cycle only "starts" once the first expense is logged. Before that no day has been
    // used up, so the whole cycle is still ahead (e.g. 700 / 7 days = 100 per day, not 700 / 6).
    m.activeDays = 0;
    if (!expenses_.empty()) {
        m.activeDays = 1;
        long long todayDay = 0;
        isoToDays(today(), todayDay);
        long long minDay = 0;
        bool have = false;
        for (const auto& e : expenses_) {
            long long d;
            if (!isoToDays(e.date, d)) continue;
            if (!have || d < minDay) { minDay = d; have = true; }
        }
        if (have) {
            const long long diff = todayDay - minDay + 1;
            m.activeDays = static_cast<int>(std::min<long long>(m.totalDaysInCycle, std::max<long long>(1, diff)));
        }
    }

    const bool any = !expenses_.empty();
    m.dailyAverage = any ? m.totalSpent / std::max(1, m.activeDays) : 0.0;
    m.txAverage = any ? m.totalSpent / static_cast<double>(expenses_.size()) : 0.0;
    m.remainingDays = std::max(0, m.totalDaysInCycle - m.activeDays);

    m.targetDailyBudget = std::max(0.0, m.maxAllowedSpending) / m.totalDaysInCycle;
    m.hasEnoughHistory = m.activeDays >= 3;

    const double pool = m.savingsGoal > 0 ? m.safeSpendRemaining : m.remaining;
    m.safeDailySpend = pool > 0 ? pool / std::max(1, m.remainingDays) : 0.0;

    m.paceDaily = m.hasEnoughHistory ? m.dailyAverage : std::min(m.targetDailyBudget, m.safeDailySpend);
    m.projectedEndBalance = m.remaining - m.paceDaily * m.remainingDays;
    return m;
}

Metrics Core::metrics() const {
    std::lock_guard<std::mutex> lk(mu_);
    return computeLocked();
}

std::string Core::metricsJson() const {
    const Metrics m = metrics();
    std::ostringstream o;
    o << "{\"totalDaysInCycle\":" << m.totalDaysInCycle
      << ",\"totalSpent\":" << num(m.totalSpent)
      << ",\"remaining\":" << num(m.remaining)
      << ",\"percentUsed\":" << num(m.percentUsed, 6)
      << ",\"activeDays\":" << m.activeDays
      << ",\"remainingDays\":" << m.remainingDays
      << ",\"dailyAverage\":" << num(m.dailyAverage, 6)
      << ",\"paceDaily\":" << num(m.paceDaily, 6)
      << ",\"hasEnoughHistory\":" << (m.hasEnoughHistory ? "true" : "false")
      << ",\"txAverage\":" << num(m.txAverage, 6)
      << ",\"projectedEndBalance\":" << num(m.projectedEndBalance, 6)
      << ",\"safeDailySpend\":" << num(m.safeDailySpend, 6)
      << ",\"targetDailyBudget\":" << num(m.targetDailyBudget, 6)
      << ",\"savingsGoal\":" << num(m.savingsGoal)
      << ",\"maxAllowedSpending\":" << num(m.maxAllowedSpending)
      << ",\"safeSpendRemaining\":" << num(m.safeSpendRemaining)
      << ",\"savingsPercentOfAllowance\":" << num(m.savingsPercentOfAllowance, 6) << "}";
    return o.str();
}

std::string Core::stateJson() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::ostringstream o;
    o << "{\"allowance\":" << num(allowance_) << ",\"savingsGoal\":" << num(savingsGoal_)
      << ",\"cycle\":\"" << cycle_ << "\",\"expenses\":[";
    for (size_t i = 0; i < expenses_.size(); i++) {
        const auto& e = expenses_[i];
        if (i) o << ",";
        o << "{\"id\":\"" << jsonEscape(e.id) << "\",\"note\":\"" << jsonEscape(e.note)
          << "\",\"amount\":" << num(e.amount) << ",\"category\":\"" << jsonEscape(e.category)
          << "\",\"date\":\"" << jsonEscape(e.date) << "\"}";
    }
    o << "]}";
    return o.str();
}

// ---------------------------------------------------------------- mutations

bool Core::setAllowance(double v) {
    if (!std::isfinite(v) || v < 0) return false;
    std::lock_guard<std::mutex> lk(mu_);
    allowance_ = std::round(v * 100.0) / 100.0;
    saveLocked();
    return true;
}

bool Core::setSavingsGoal(double v) {
    if (!std::isfinite(v) || v < 0) return false;
    std::lock_guard<std::mutex> lk(mu_);
    savingsGoal_ = std::round(v * 100.0) / 100.0;
    saveLocked();
    return true;
}

void Core::setCycle(const std::string& cycle) {
    std::lock_guard<std::mutex> lk(mu_);
    cycle_ = (cycle == "monthly") ? "monthly" : "weekly";
    saveLocked();
}

std::string Core::addExpense(double amount, const std::string& category,
                             const std::string& note, const std::string& date) {
    if (!std::isfinite(amount)) return "";
    amount = std::round(amount * 100.0) / 100.0;
    if (amount <= 0) return "";
    std::lock_guard<std::mutex> lk(mu_);
    Expense e;
    e.id = newId();
    e.amount = amount;
    e.category = trim(category).empty() ? "Food" : normalizeCategory(category);
    const std::string n = cleanNote(note);
    e.note = n.empty() ? e.category + " expense" : n;
    long long ignore;
    e.date = isoToDays(date, ignore) ? date : today();
    expenses_.insert(expenses_.begin(), e);  // newest first, like unshift()
    saveLocked();
    return e.id;
}

double Core::deleteExpense(const std::string& id) {
    std::lock_guard<std::mutex> lk(mu_);
    for (auto it = expenses_.begin(); it != expenses_.end(); ++it) {
        if (it->id == id) {
            const double amt = it->amount;
            expenses_.erase(it);
            saveLocked();
            return amt;
        }
    }
    return -1.0;
}

int Core::clearExpenses() {
    std::lock_guard<std::mutex> lk(mu_);
    const int n = static_cast<int>(expenses_.size());
    expenses_.clear();
    saveLocked();
    return n;
}

void Core::resetAll() {
    std::lock_guard<std::mutex> lk(mu_);
    allowance_ = 0;
    savingsGoal_ = 0;
    cycle_ = "weekly";
    expenses_.clear();
    saveLocked();
}

// ------------------------------------------------------------------- CSV

std::string Core::exportLocked(bool withBom) const {
    const Metrics m = computeLocked();
    std::string out = withBom ? "\xEF\xBB\xBF" : "";
    auto row = [&](std::initializer_list<std::string> cols) {
        bool first = true;
        for (const auto& c : cols) {
            if (!first) out += ",";
            out += csvField(c);
            first = false;
        }
        out += "\r\n";
    };
    row({"BAONTRACK SUMMARY", "VALUE"});
    row({"Cycle", cycle_ == "weekly" ? "Weekly (7d)" : "Monthly (30d)"});
    row({"Allowance", num(allowance_)});
    row({"Savings Goal", num(m.savingsGoal)});
    row({"Total Spent", num(m.totalSpent)});
    row({"Remaining Balance", num(m.remaining)});
    out += "\r\n";
    row({"Date", "Category", "Description", "Amount"});
    std::vector<Expense> sorted = expenses_;
    std::stable_sort(sorted.begin(), sorted.end(),
                     [](const Expense& a, const Expense& b) { return a.date > b.date; });
    for (const auto& e : sorted) row({e.date, e.category, e.note, num(e.amount)});
    return out;
}

std::string Core::exportCsv(bool withBom) const {
    std::lock_guard<std::mutex> lk(mu_);
    return exportLocked(withBom);
}

ImportResult Core::importLocked(const std::string& rawIn) {
    ImportResult res;
    std::string text = rawIn;
    if (text.compare(0, 3, "\xEF\xBB\xBF") == 0) text.erase(0, 3);

    std::vector<std::string> lines;
    {
        std::string cur;
        std::istringstream ss(text);
        while (std::getline(ss, cur)) {
            cur = trim(cur);
            if (!cur.empty()) lines.push_back(cur);
        }
    }
    if (lines.empty()) { res.error = "The selected CSV file is empty."; return res; }

    bool haveAllow = false, haveSave = false, haveCycle = false, inExpenses = false;
    double impAllow = 0, impSave = 0;
    std::string impCycle;
    std::vector<Expense> imported;

    for (size_t i = 0; i < lines.size(); i++) {
        const auto cols = parseCsvLine(lines[i]);
        const std::string c0 = trim(cols.empty() ? "" : cols[0]);
        const std::string c0l = lower(c0);
        const bool hasC1 = cols.size() > 1;

        if (c0l == "baontrack summary") { inExpenses = false; continue; }
        if (!inExpenses && c0l == "cycle" && hasC1 && !cols[1].empty()) {
            impCycle = lower(cols[1]).find("monthly") != std::string::npos ? "monthly" : "weekly";
            haveCycle = true;
            continue;
        }
        if (!inExpenses && c0l == "allowance" && hasC1) {
            const double v = parseMoney(cols[1]);
            if (!std::isnan(v) && v >= 0) { impAllow = v; haveAllow = true; }
            continue;
        }
        if (!inExpenses && c0l == "savings goal" && hasC1) {
            const double v = parseMoney(cols[1]);
            if (!std::isnan(v) && v >= 0) { impSave = v; haveSave = true; }
            continue;
        }
        if (!inExpenses && (c0l == "total spent" || c0l == "remaining balance")) continue;
        if (c0l == "date" && hasC1 && lower(cols[1]) == "category") { inExpenses = true; continue; }

        if (inExpenses || cols.size() >= 4) {
            const std::string rawCat = (cols.size() > 1 && !cols[1].empty()) ? cols[1] : "Food";
            const std::string cat = normalizeCategory(rawCat);
            std::string note = (cols.size() > 2 && !cols[2].empty()) ? cols[2] : cat + " expense";
            const double amt = cols.size() > 3 ? parseMoney(cols[3]) : std::nan("");
            if (!std::isnan(amt) && amt > 0) {
                Expense e;
                e.id = newId();
                e.date = c0;
                long long ignore;
                if (!isoToDays(e.date, ignore)) e.date = today();
                e.category = cat;
                e.note = truncateUtf8(note, 60);
                e.amount = std::round(amt * 100.0) / 100.0;
                if (e.amount > 0) imported.push_back(e);
            }
        }
    }

    const bool hasMeta = haveAllow || haveSave || haveCycle;
    if (!hasMeta && imported.empty()) {
        res.error = "No valid BaonTrack summary or expense rows found in CSV.";
        return res;
    }
    const int importedCount = static_cast<int>(imported.size());
    if (haveCycle) cycle_ = impCycle;
    if (haveAllow) allowance_ = std::round(impAllow * 100.0) / 100.0;
    if (haveSave) savingsGoal_ = std::round(impSave * 100.0) / 100.0;
    if (!imported.empty()) {
        if (hasMeta) {
            expenses_ = imported;
        } else {
            imported.insert(imported.end(), expenses_.begin(), expenses_.end());
            expenses_ = imported;
        }
    }
    res.ok = true;
    res.imported = importedCount;
    res.hasMetadata = hasMeta;
    return res;
}

ImportResult Core::importCsv(const std::string& text) {
    std::lock_guard<std::mutex> lk(mu_);
    ImportResult r = importLocked(text);
    if (r.ok) saveLocked();
    return r;
}

std::string Core::importResultJson(const ImportResult& r) {
    std::ostringstream o;
    o << "{\"ok\":" << (r.ok ? "true" : "false") << ",\"imported\":" << r.imported
      << ",\"hasMetadata\":" << (r.hasMetadata ? "true" : "false") << ",\"error\":\""
      << jsonEscape(r.error) << "\"}";
    return o.str();
}

}  // namespace baon
