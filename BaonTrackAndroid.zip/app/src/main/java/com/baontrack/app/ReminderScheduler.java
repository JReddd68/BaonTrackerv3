package com.baontrack.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.Calendar;

/**
 * Keeps the notification settings and schedules (or cancels) the repeating alarms:
 * the daily "log your expenses" reminder and the morning check that warns about the end of the cycle.
 */
final class ReminderScheduler {
    private static final String PREFS = "baon_prefs";
    private static final int REQUEST_CODE_REMINDER = 4001;
    private static final int REQUEST_CODE_CYCLE = 4002;
    static final int DEFAULT_HOUR = 20;
    static final int DEFAULT_MINUTE = 0;
    private static final int CYCLE_ALERT_HOUR = 8;   // the cycle warning is checked every morning at 8:00

    private ReminderScheduler() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Android 13+ asks the user before an app may show notifications. */
    static boolean hasNotificationPermission(Context c) {
        return Build.VERSION.SDK_INT < 33
                || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    static String stateJson(Context c) {
        SharedPreferences p = prefs(c);
        return "{\"enabled\":" + p.getBoolean("enabled", false)
                + ",\"hour\":" + p.getInt("hour", DEFAULT_HOUR)
                + ",\"minute\":" + p.getInt("minute", DEFAULT_MINUTE)
                + ",\"cycleAlerts\":" + p.getBoolean("cycleAlerts", false)
                + ",\"permission\":" + hasNotificationPermission(c) + "}";
    }

    static void save(Context c, boolean enabled, int hour, int minute) {
        prefs(c).edit()
                .putBoolean("enabled", enabled)
                .putInt("hour", Math.max(0, Math.min(23, hour)))
                .putInt("minute", Math.max(0, Math.min(59, minute)))
                .apply();
        apply(c);
    }

    static void setCycleAlerts(Context c, boolean enabled) {
        prefs(c).edit().putBoolean("cycleAlerts", enabled).apply();
        apply(c);
    }

    private static PendingIntent pendingIntent(Context c, Class<?> receiver, int requestCode) {
        Intent i = new Intent(c, receiver);
        return PendingIntent.getBroadcast(c, requestCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Sets both alarms from the saved settings (and cancels the ones that are switched off). */
    static void apply(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences p = prefs(c);

        PendingIntent daily = pendingIntent(c, ReminderReceiver.class, REQUEST_CODE_REMINDER);
        am.cancel(daily);
        if (p.getBoolean("enabled", false)) {
            schedule(am, daily, p.getInt("hour", DEFAULT_HOUR), p.getInt("minute", DEFAULT_MINUTE));
        }

        PendingIntent cycle = pendingIntent(c, CycleAlertReceiver.class, REQUEST_CODE_CYCLE);
        am.cancel(cycle);
        if (p.getBoolean("cycleAlerts", false)) {
            schedule(am, cycle, CYCLE_ALERT_HOUR, 0);
        }
    }

    private static void schedule(AlarmManager am, PendingIntent pi, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);

        // Inexact on purpose: needs no special "exact alarm" permission; Android may shift it a little to save battery.
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }
}
