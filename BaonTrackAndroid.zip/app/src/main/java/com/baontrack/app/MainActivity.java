package com.baontrack.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.graphics.drawable.ColorDrawable;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Hosts the BaonTrack UI (assets/index.html) in a WebView. Every calculation,
 * the CSV logic and the saved data live in the C++ core, reached through the
 * "BaonNative" JavaScript interface.
 */
public class MainActivity extends Activity {
    private static final int REQ_PICK_CSV = 1001;
    private static final int REQ_SAVE_CSV = 1002;
    private static final int REQ_NOTIFICATIONS = 1003;
    private static final int MAX_CSV_BYTES = 5 * 1024 * 1024;

    // Opening animation timing
    private static final long INTRO_MIN_MS = 1700;   // shortest time the intro stays up
    private static final long INTRO_MAX_MS = 5000;   // never keep the user waiting longer than this
    private static final float WALLET_DP = 288f;     // size of the wallet canvases (see ic_wallet_*.xml)
    private static final float CLASP_EDGE_X_DP = 200f;   // right edge of the clasp inside that canvas
    private static final float CLASP_CENTER_Y_DP = 153.4f;

    private WebView webView;
    private FrameLayout root;
    private View introView;
    private boolean pageReady, introMinElapsed;
    private boolean barsDark;   // the page's theme as the page reports it (starts as the phone's setting)
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile byte[] pendingExport;

    // App lock
    private static final long RELOCK_AFTER_MS = 15000;   // leaving the app for longer than this asks for the PIN again
    private View lockView;
    private TextView lockDots, lockMessage, lockFingerprintBtn;
    private final StringBuilder lockInput = new StringBuilder();
    private boolean lockRequired;     // true until the user unlocks (fresh launch, or away for a while)
    private boolean biometricActive;
    private long pausedAt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeCore.init(new File(getFilesDir(), "baontrack_state.csv").getAbsolutePath());
        lockRequired = AppLock.isEnabled(this);   // the lock screen itself is shown from onResume()

        barsDark = systemIsDark();
        webView = new WebView(this);
        if (barsDark) webView.setBackgroundColor(0xFF0B1220);  // no white flash while the page loads
        root = new FrameLayout(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);          // we only load our own packaged asset
        ws.setAllowContentAccess(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                finishIntroWhenReady();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "BaonNative");

        // Play the intro on a fresh launch only (not when Android restores the activity,
        // and not when the user has turned animations off).
        boolean animationsOn = Settings.Global.getFloat(
                getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f;
        if (savedInstanceState == null && animationsOn) startIntro();
        else { applyAppWindowBackground(); applySystemBars(barsDark); }

        webView.loadUrl("file:///android_asset/index.html");
    }

    // ------------------------------------------------------------------ opening animation

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    /**
     * Purple intro drawn over the WebView. It starts as the same picture the system shows while the app
     * launches (purple screen + wallet), then the clasp snaps shut, the wallet bounces and the name fades in.
     * It fades out once the page has loaded and the animation has had time to play.
     */
    private void startIntro() {
        introView = getLayoutInflater().inflate(R.layout.intro_overlay, root, false);
        root.addView(introView);

        Window w = getWindow();
        int purple = getColor(R.color.splash_bg);
        w.setStatusBarColor(purple);
        w.setNavigationBarColor(purple);
        setDarkBarIcons(false);   // white icons on the purple intro

        View wallet = introView.findViewById(R.id.introWallet);
        View clasp = introView.findViewById(R.id.introClasp);
        View title = introView.findViewById(R.id.introTitle);
        View tagline = introView.findViewById(R.id.introTagline);

        // Start state: empty wallet (what the splash shows), clasp folded away, texts hidden.
        clasp.setPivotX(dp(CLASP_EDGE_X_DP));
        clasp.setPivotY(dp(CLASP_CENTER_Y_DP));
        clasp.setScaleX(0f);
        clasp.setAlpha(0f);
        title.setAlpha(0f);
        title.setTranslationY(title.getTranslationY() + dp(16));
        tagline.setAlpha(0f);
        tagline.setTranslationY(tagline.getTranslationY() + dp(16));

        // 1. clasp snaps out of the right edge
        clasp.animate().setStartDelay(250).setDuration(450).scaleX(1f).alpha(1f)
                .setInterpolator(new OvershootInterpolator(2.4f)).start();

        // 2. whole wallet gives a little bounce as it closes
        wallet.setPivotX(dp(WALLET_DP) / 2f);
        wallet.setPivotY(dp(WALLET_DP) / 2f);
        wallet.animate().setStartDelay(560).setDuration(150).scaleX(1.07f).scaleY(1.07f)
                .withEndAction(() -> wallet.animate().setStartDelay(0).setDuration(320)
                        .scaleX(1f).scaleY(1f).setInterpolator(new OvershootInterpolator(3f)).start())
                .start();

        // 3. name and tagline rise in
        title.animate().setStartDelay(550).setDuration(450).alpha(1f)
                .translationY(title.getTranslationY() - dp(16))
                .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        tagline.animate().setStartDelay(720).setDuration(450).alpha(1f)
                .translationY(tagline.getTranslationY() - dp(16))
                .setInterpolator(new DecelerateInterpolator(1.6f)).start();

        handler.postDelayed(() -> { introMinElapsed = true; finishIntroWhenReady(); }, INTRO_MIN_MS);
        handler.postDelayed(this::dismissIntro, INTRO_MAX_MS);   // safety net
    }

    private void finishIntroWhenReady() {
        if (pageReady && introMinElapsed) dismissIntro();
    }

    private void dismissIntro() {
        final View intro = introView;
        if (intro == null) return;
        introView = null;
        intro.animate().setStartDelay(0).setDuration(380).alpha(0f).scaleX(1.08f).scaleY(1.08f)
                .setInterpolator(new AccelerateInterpolator(1.2f))
                .withEndAction(() -> {
                    root.removeView(intro);
                    applyAppWindowBackground();
                    applySystemBars(barsDark);
                }).start();
        // bring the bars to the page's theme while the purple fades out
        applySystemBars(barsDark);
    }

    /** The launch theme paints a purple window background; swap it for the page colour once we are running. */
    private void applyAppWindowBackground() {
        getWindow().setBackgroundDrawable(new ColorDrawable(barsDark ? 0xFF0B1220 : 0xFFF8FAFC));
    }

    /** dark = black status bar and navigation bar with white icons (clock, wifi, battery); otherwise white bars with dark icons. */
    private void applySystemBars(boolean dark) {
        Window w = getWindow();
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        int color = dark ? 0xFF0B1220 : 0xFFFFFFFF;
        w.setStatusBarColor(color);
        w.setNavigationBarColor(color);
        setDarkBarIcons(!dark);
    }

    /** true = dark icons (for a light bar), false = white icons (for a dark bar). */
    private void setDarkBarIcons(boolean darkIcons) {
        View decor = getWindow().getDecorView();
        int flags = decor.getSystemUiVisibility();
        int mask = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) mask |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        decor.setSystemUiVisibility(darkIcons ? (flags | mask) : (flags & ~mask));
    }

    // ------------------------------------------------------------------ app lock

    @Override
    protected void onResume() {
        super.onResume();
        if (!AppLock.isEnabled(this)) {
            lockRequired = false;
            hideLock();
            return;
        }
        if (!lockRequired && SystemClock.elapsedRealtime() - pausedAt > RELOCK_AFTER_MS) lockRequired = true;
        if (lockRequired) showLock(true);
        else hideLock();
    }

    @Override
    protected void onPause() {
        super.onPause();
        pausedAt = SystemClock.elapsedRealtime();
        // cover the page right away so the recent-apps preview does not show your money
        if (AppLock.isEnabled(this)) showLock(false);
    }

    private boolean lockVisible() {
        return lockView != null && lockView.getVisibility() == View.VISIBLE;
    }

    private void buildLockView() {
        lockView = getLayoutInflater().inflate(R.layout.lock_overlay, root, false);
        lockDots = (TextView) lockView.findViewById(R.id.lockDots);
        lockMessage = (TextView) lockView.findViewById(R.id.lockMessage);
        lockFingerprintBtn = (TextView) lockView.findViewById(R.id.lockFingerprint);
        lockFingerprintBtn.setOnClickListener(v -> tryBiometric());

        LinearLayout pad = (LinearLayout) lockView.findViewById(R.id.lockPad);
        String[][] keys = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {"", "0", "\u2190"}};
        for (String[] rowKeys : keys) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            for (String k : rowKeys) {
                TextView key = new TextView(this);
                key.setGravity(Gravity.CENTER);
                key.setTextSize(26);
                key.setTextColor(0xFFFFFFFF);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) dp(72), (int) dp(72));
                lp.setMargins((int) dp(10), (int) dp(6), (int) dp(10), (int) dp(6));
                key.setLayoutParams(lp);
                if (!k.isEmpty()) {
                    key.setText(k);
                    key.setBackgroundResource(R.drawable.lock_key_bg);
                    key.setClickable(true);
                    final String label = k;
                    key.setOnClickListener(v -> onLockKey(label));
                }
                row.addView(key);
            }
            pad.addView(row);
        }
        root.addView(lockView);   // added last, so it covers the page and the intro
    }

    private void showLock(boolean tryBio) {
        if (!AppLock.isEnabled(this)) return;
        if (lockView == null) buildLockView();
        lockInput.setLength(0);
        updateLockDots();
        lockMessage.setText("");
        lockFingerprintBtn.setVisibility(AppLock.biometricEnabled(this) && biometricAvailable() ? View.VISIBLE : View.GONE);
        lockView.setVisibility(View.VISIBLE);
        lockView.bringToFront();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        if (tryBio) tryBiometric();
    }

    private void hideLock() {
        if (lockView != null) lockView.setVisibility(View.GONE);
    }

    private void unlockNow() {
        AppLock.recordSuccess(this);
        lockRequired = false;
        hideLock();
    }

    private void updateLockDots() {
        int n = AppLock.pinLength(this);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append(' ');
            sb.append(i < lockInput.length() ? '\u25CF' : '\u25CB');
        }
        lockDots.setText(sb);
    }

    private void onLockKey(String key) {
        long wait = AppLock.lockoutRemainingMs(this);
        if (wait > 0) {
            lockMessage.setText("Too many wrong tries. Try again in " + ((wait + 999) / 1000) + " seconds.");
            return;
        }
        if (key.equals("\u2190")) {
            if (lockInput.length() > 0) lockInput.deleteCharAt(lockInput.length() - 1);
        } else if (lockInput.length() < AppLock.pinLength(this)) {
            lockInput.append(key);
        }
        updateLockDots();
        if (lockInput.length() == AppLock.pinLength(this)) {
            String pin = lockInput.toString();
            lockInput.setLength(0);
            if (AppLock.verify(this, pin)) {
                unlockNow();
                return;
            }
            AppLock.recordFailure(this);
            long left = AppLock.lockoutRemainingMs(this);
            lockMessage.setText(left > 0
                    ? "Too many wrong tries. Try again in " + ((left + 999) / 1000) + " seconds."
                    : "Wrong PIN. Try again.");
            updateLockDots();
        }
    }

    /** Fingerprint is offered on Android 9+ phones that have an enrolled fingerprint. */
    private boolean biometricAvailable() {
        if (Build.VERSION.SDK_INT < 28) return false;
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) return false;
        if (Build.VERSION.SDK_INT >= 29) {
            BiometricManager bm = getSystemService(BiometricManager.class);
            return bm != null && bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
        }
        return true;
    }

    private void tryBiometric() {
        if (Build.VERSION.SDK_INT < 28 || biometricActive) return;
        if (!AppLock.biometricEnabled(this) || !biometricAvailable()) return;
        biometricActive = true;
        BiometricPrompt prompt = new BiometricPrompt.Builder(this)
                .setTitle("Unlock BaonTrack")
                .setSubtitle("Touch the fingerprint sensor")
                .setNegativeButton("Use PIN", getMainExecutor(), (dialog, which) -> { })
                .build();
        prompt.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                biometricActive = false;
                unlockNow();
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                biometricActive = false;   // cancelled or too many tries: the PIN pad is still there
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (lockVisible()) { moveTaskToBack(true); return; }   // do not let "back" reach the page behind the lock
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.removeJavascriptInterface("BaonNative");
            webView.destroy();
        }
        super.onDestroy();
    }

    private boolean systemIsDark() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    private void askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && !ReminderScheduler.hasNotificationPermission(this)) {
            runOnUiThread(() -> requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS));
        }
    }

    private void refreshWidget() {
        BaonWidgetProvider.refresh(getApplicationContext());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            js("window.onNativeReminderPermission && window.onNativeReminderPermission(" + granted + ")");
        }
    }

    private void js(final String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    /** Methods here are called from JavaScript on a background thread. */
    public final class Bridge {
        @JavascriptInterface public boolean isSystemDark() { return systemIsDark(); }

        // ---- add money
        @JavascriptInterface public String addMoney(double amount, String note, String date) {
            String id = NativeCore.addMoney(amount, note, date);
            refreshWidget();
            return id;
        }
        @JavascriptInterface public double deleteMoney(String id) {
            double r = NativeCore.deleteMoney(id);
            refreshWidget();
            return r;
        }

        // ---- GCash tracker
        @JavascriptInterface public String gcashAdd(String type, double amount, double fee, String category,
                                                    String note, String date) {
            return NativeCore.gcashAdd(type, amount, fee, category, note, date);
        }
        @JavascriptInterface public boolean gcashDelete(String id) { return NativeCore.gcashDelete(id); }
        @JavascriptInterface public void gcashClear() { NativeCore.gcashClear(); }
        @JavascriptInterface public String gcashGet() { return NativeCore.gcashGet(); }

        // ---- app lock settings (the lock screen itself is native)
        @JavascriptInterface public String getLockState() {
            return "{\"enabled\":" + AppLock.isEnabled(MainActivity.this)
                    + ",\"pinLength\":" + AppLock.pinLength(MainActivity.this)
                    + ",\"biometricAvailable\":" + biometricAvailable()
                    + ",\"biometricEnabled\":" + AppLock.biometricEnabled(MainActivity.this) + "}";
        }

        @JavascriptInterface public boolean enableLock(String pin) {
            boolean ok = AppLock.enable(MainActivity.this, pin);
            if (ok) runOnUiThread(() -> lockRequired = false);   // you just set it, so you are already in
            return ok;
        }

        @JavascriptInterface public boolean disableLock(String pin) {
            boolean ok = AppLock.disable(MainActivity.this, pin);
            if (ok) runOnUiThread(() -> { lockRequired = false; hideLock(); });
            return ok;
        }

        @JavascriptInterface public boolean changePin(String oldPin, String newPin) {
            return AppLock.change(MainActivity.this, oldPin, newPin);
        }

        @JavascriptInterface public boolean setBiometric(boolean on) {
            if (on && (!AppLock.isEnabled(MainActivity.this) || !biometricAvailable())) return false;
            AppLock.setBiometric(MainActivity.this, on);
            return true;
        }

        /** Called by the page whenever its theme changes, so the phone's bars can match it. */
        @JavascriptInterface
        public void setSystemBars(final boolean dark) {
            runOnUiThread(() -> {
                barsDark = dark;
                webView.setBackgroundColor(dark ? 0xFF0B1220 : 0xFFF8FAFC);
                if (introView == null) {          // during the intro the bars stay purple; dismissIntro() applies them
                    applyAppWindowBackground();
                    applySystemBars(dark);
                }
            });
        }
        @JavascriptInterface public String getState() { return NativeCore.getState(); }
        @JavascriptInterface public String getMetrics() { return NativeCore.getMetrics(); }
        @JavascriptInterface public boolean setAllowance(double v) { boolean r = NativeCore.setAllowance(v); refreshWidget(); return r; }
        @JavascriptInterface public boolean setSavingsGoal(double v) { boolean r = NativeCore.setSavingsGoal(v); refreshWidget(); return r; }
        @JavascriptInterface public void setCycle(String c) { NativeCore.setCycle(c); refreshWidget(); }
        @JavascriptInterface public String addExpense(double a, String cat, String note, String date) {
            String id = NativeCore.addExpense(a, cat, note, date);
            refreshWidget();
            return id;
        }
        @JavascriptInterface public double deleteExpense(String id) { double r = NativeCore.deleteExpense(id); refreshWidget(); return r; }
        @JavascriptInterface public int clearExpenses() { int r = NativeCore.clearExpenses(); refreshWidget(); return r; }
        @JavascriptInterface public void resetAll() { NativeCore.resetAll(); refreshWidget(); }
        // ---- category limits and cycle history
        @JavascriptInterface public boolean setCategoryLimit(String category, double amount) {
            return NativeCore.setCategoryLimit(category, amount);
        }
        @JavascriptInterface public String getCategories() { return NativeCore.getCategories(); }
        @JavascriptInterface public boolean newCycle() { boolean r = NativeCore.newCycle(); refreshWidget(); return r; }
        @JavascriptInterface public String getHistory() { return NativeCore.getHistory(); }
        @JavascriptInterface public void clearHistory() { NativeCore.clearHistory(); }

        // ---- daily reminder
        @JavascriptInterface public String getReminder() { return ReminderScheduler.stateJson(MainActivity.this); }

        @JavascriptInterface
        public void setReminder(boolean enabled, int hour, int minute) {
            ReminderScheduler.save(MainActivity.this, enabled, hour, minute);
            if (enabled && Build.VERSION.SDK_INT >= 33
                    && !ReminderScheduler.hasNotificationPermission(MainActivity.this)) {
                runOnUiThread(() -> requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS));
            }
        }

        @JavascriptInterface
        public void testReminder() { ReminderReceiver.show(MainActivity.this, true); }

        @JavascriptInterface
        public void setCycleAlerts(boolean enabled) {
            ReminderScheduler.setCycleAlerts(MainActivity.this, enabled);
            if (enabled) askNotificationPermissionIfNeeded();
        }

        // ---- summary report
        @JavascriptInterface public String getSummary() { return NativeCore.getSummary(); }

        @JavascriptInterface
        public boolean copyText(String text) {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null) return false;
                cm.setPrimaryClip(ClipData.newPlainText("BaonTrack summary", text));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface public String estimate(double dailySpend, int days, double budget, double saveTarget) {
            return NativeCore.estimate(dailySpend, days, budget, saveTarget);
        }

        @JavascriptInterface
        public void exportCsv(final String filename) {
            pendingExport = NativeCore.exportCsvBytes();
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/csv");
                i.putExtra(Intent.EXTRA_TITLE, filename);
                startActivityForResult(i, REQ_SAVE_CSV);
            });
        }

        @JavascriptInterface
        public void pickCsv() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "text/csv", "text/comma-separated-values", "text/plain",
                        "application/vnd.ms-excel", "application/octet-stream"});
                startActivityForResult(Intent.createChooser(i, "Choose a CSV file"), REQ_PICK_CSV);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        final Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;

        if (requestCode == REQ_SAVE_CSV) {
            boolean ok = false;
            if (uri != null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) { out.write(pendingExport); ok = true; }
                } catch (Exception ignored) { }
            }
            pendingExport = null;
            js("window.onNativeSaved && window.onNativeSaved(" + ok + ")");
        } else if (requestCode == REQ_PICK_CSV) {
            if (uri == null) return;  // user cancelled
            String result;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int n;
                while (in != null && (n = in.read(chunk)) != -1) {
                    buf.write(chunk, 0, n);
                    if (buf.size() > MAX_CSV_BYTES) throw new IllegalStateException("too big");
                }
                result = NativeCore.importCsv(buf.toByteArray());
                refreshWidget();
            } catch (Exception e) {
                result = "{\"ok\":false,\"imported\":0,\"hasMetadata\":false,\"error\":\"Unable to read the selected CSV file.\"}";
            }
            js("window.onNativeImport && window.onNativeImport(" + result + ")");
        }
    }
}
