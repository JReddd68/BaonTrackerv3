#include <cassert>
#include <cstdio>
#include <iostream>
#include "../app/src/main/cpp/baon_core.h"
int main() {
    std::remove("/tmp/baon_state.csv");
    {
        baon::Core c; c.init("/tmp/baon_state.csv"); c.setTodayOverride("2026-11-15");
        c.setCycle("monthly"); c.setAllowance(9000); c.setSavingsGoal(4500);
        c.addExpense(120.5, "Food", "Lunch, \"fried\" chicken \xF0\x9F\x8D\x97", "2026-11-14");
        c.addExpense(60, "Strolling", "", "2026-11-15");
        c.addExpense(-5, "Food", "bad", "2026-11-15");          // rejected
        assert(c.addExpense(0, "Food", "bad", "") == "");
    }
    baon::Core r; r.init("/tmp/baon_state.csv"); r.setTodayOverride("2026-11-15");  // reload from disk
    std::string s = r.stateJson();
    std::cout << s << "\n";
    assert(s.find("\"cycle\":\"monthly\"") != std::string::npos);
    assert(s.find("\"allowance\":9000.00") != std::string::npos);
    assert(s.find("fried") != std::string::npos && s.find("\xF0\x9F\x8D\x97") != std::string::npos);
    assert(s.find("Strolling expense") != std::string::npos);
    // standalone 4-column CSV appends; garbage is rejected
    auto a = r.importCsv("2026-11-10,School,Notebook,\xE2\x82\xB1" "1,250.00\n");
    assert(a.ok && a.imported == 1 && !a.hasMetadata);
    auto b = r.importCsv("hello world\n");
    assert(!b.ok);
    std::cout << r.exportCsv(true).substr(3) << "\n";
    assert(r.deleteExpense("nope") < 0);
    std::puts("ALL CSV TESTS PASSED");
}
