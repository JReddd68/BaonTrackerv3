package com.baontrack.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.Calendar;

/** Keeps the daily reminder setting and schedules (or cancels) the repeating alarm. */
final class ReminderScheduler {
    private static final String PREFS = "baon_prefs";
    private static final int REQUEST_CODE = 4001;
    static final int DEFAULT_HOUR = 20;
    static final int DEFAULT_MINUTE = 0;

    private ReminderScheduler() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Android 13+ asks the user before an app may show notifications. */
    static boolean hasNotificationPermission(Context c) {
        return Build.VERSION.SDK_INT < 33
                || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    static String stateJson(Context c) {
        SharedPreferences p = prefs(c);
        return "{\"enabled\":" + p.getBoolean("enabled", false)
                + ",\"hour\":" + p.getInt("hour", DEFAULT_HOUR)
                + ",\"minute\":" + p.getInt("minute", DEFAULT_MINUTE)
                + ",\"permission\":" + hasNotificationPermission(c) + "}";
    }

    static void save(Context c, boolean enabled, int hour, int minute) {
        prefs(c).edit()
                .putBoolean("enabled", enabled)
                .putInt("hour", Math.max(0, Math.min(23, hour)))
                .putInt("minute", Math.max(0, Math.min(59, minute)))
                .apply();
        apply(c);
    }

    private static PendingIntent pendingIntent(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class);
        return PendingIntent.getBroadcast(c, REQUEST_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Schedules the repeating alarm from the saved setting, or cancels it when the reminder is off. */
    static void apply(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = pendingIntent(c);
        am.cancel(pi);

        SharedPreferences p = prefs(c);
        if (!p.getBoolean("enabled", false)) return;

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, p.getInt("hour", DEFAULT_HOUR));
        cal.set(Calendar.MINUTE, p.getInt("minute", DEFAULT_MINUTE));
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);

        // Inexact on purpose: needs no special "exact alarm" permission; Android may shift it a little to save battery.
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }
}
