// Page tests: the About tab of the hidden panel, and the theme being reported to Android for the status bar.
const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const script = html.slice(html.lastIndexOf('<script>') + 8, html.lastIndexOf('</script>'));
const grab = re => { const m = script.match(re); if (!m) throw new Error('not found: ' + re); return m[0]; };
const chips = grab(/const EST_CHIP_BASE[^\n]*\n\s*const EST_CHIP_ON[^\n]*\n\s*const EST_CHIP_OFF[^\n]*\n/);
const showEstTab = grab(/function showEstTab\(tab\) \{[\s\S]*?\n        \}\n/);
const applyTheme = grab(/function applyTheme\(mode, persist\) \{[\s\S]*?\n        \}\n/);

class CL { constructor(){ this.s = new Set(); } toggle(c,on){ on===undefined ? (this.s.has(c)?this.s.delete(c):this.s.add(c)) : (on?this.s.add(c):this.s.delete(c)); } add(c){this.s.add(c);} remove(c){this.s.delete(c);} contains(c){return this.s.has(c);} }
const els = {};
function El(id){ this.id=id; this.textContent=''; this.className=''; this.classList=new CL(); this.setAttribute=()=>{}; }
const root = new El('html');
const document = { documentElement: root, getElementById: id => els[id] || (els[id] = new El(id)), querySelectorAll: () => [] };
const calls = { bars: [], reminder: 0 };
function make(Core) {
  return new Function('document', 'Core', 'calls', `
    ${chips}
    const loadReminder = () => { calls.reminder++; }, renderReminder = () => {};
    const applyChartTheme = () => {};
    ${showEstTab}
    ${applyTheme}
    return { showEstTab, applyTheme };
  `)(document, Core, calls);
}
const api = make({ setSystemBars: v => calls.bars.push(v) });

let fails = 0;
const eq = (label, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); if (!ok) fails++; console.log((ok?'ok   ':'FAIL ')+label+(ok?'':`\n     got:  ${JSON.stringify(got)}\n     want: ${JSON.stringify(want)}`)); };
const hidden = id => document.getElementById(id).classList.contains('hidden');
const on = id => document.getElementById(id).className.includes('bg-brand-600');

api.showEstTab('about');
eq('about: only the About panel is visible', [hidden('estPanel'), hidden('estReminderPanel'), hidden('estAboutPanel')], [true, true, false]);
eq('about: tab highlighted', [on('estTabEstimate'), on('estTabReminder'), on('estTabAbout')], [false, false, true]);
eq('about: heading', [els.estHeadTitle.textContent, els.estHeadIcon.className], ['About', 'fa-solid text-lg fa-circle-info']);
eq('about: no reminder reload', calls.reminder, 0);
api.showEstTab('reminder');
eq('reminder: panel + heading', [hidden('estReminderPanel'), hidden('estAboutPanel'), els.estHeadTitle.textContent], [false, true, 'Daily Reminder']);
eq('reminder: state reloaded', calls.reminder, 1);
api.showEstTab('estimate');
eq('estimation: panel + heading', [hidden('estPanel'), hidden('estAboutPanel'), els.estHeadTitle.textContent], [false, true, 'Estimation']);
api.showEstTab('nonsense');
eq('unknown tab falls back to Estimation', [hidden('estPanel'), els.estHeadTitle.textContent], [false, 'Estimation']);

api.applyTheme('dark', false);
eq('dark: class + Android told', [root.classList.contains('dark'), calls.bars], [true, [true]]);
api.applyTheme('light', false);
eq('light: class + Android told', [root.classList.contains('dark'), calls.bars], [false, [true, false]]);
let threw = false;
try { make(undefined).applyTheme('dark', false); make({}).applyTheme('dark', false); } catch (e) { threw = true; }
eq('works without the Android bridge (browser) or with an older bridge', threw, false);

console.log(fails ? `\n${fails} FAILED` : '\nALL ABOUT/THEME CHECKS PASSED');
process.exit(fails ? 1 : 0);
