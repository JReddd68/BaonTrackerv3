// Page tests for the cycle countdown, rollover prompt, summary report and cycle warnings.
// Needs /tmp/cycle_cli  (g++ -std=c++17 tests/cycle_cli.cpp app/src/main/cpp/baon_core.cpp -o /tmp/cycle_cli)
const fs = require('fs'), cp = require('child_process');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const script = html.slice(html.lastIndexOf('<script>') + 8, html.lastIndexOf('</script>'));
const cut = (a, b) => script.slice(script.indexOf(a), script.indexOf(b));
const fmt = cut('function formatCurrency', 'function getTodayISO');
const time12 = cut('function formatTime12', '/**\n         * Category limits');
const code = cut('let reminderState', '        // Initialize App on Window Load');

class CL { constructor(){ this.s = new Set(); } toggle(c,on){ on===undefined ? (this.s.has(c)?this.s.delete(c):this.s.add(c)) : (on?this.s.add(c):this.s.delete(c)); } add(c){this.s.add(c);} remove(c){this.s.delete(c);} contains(c){return this.s.has(c);} }
const els = {};
function El(id){ this.id=id; this.value=''; this.textContent=''; this.className=''; this.innerHTML=''; this.checked=false; this.classList=new CL(); }
const document = { getElementById: id => { if (!els[id]) { els[id] = new El(id); if (/Modal$/.test(id)) els[id].classList.add('hidden'); } return els[id]; } };
const storage = {};
const localStorage = { getItem: k => (k in storage ? storage[k] : null), setItem: (k, v) => { storage[k] = String(v); }, removeItem: k => { delete storage[k]; } };
const calls = { toasts: [], core: [] };
let TODAY = '2026-11-12', SCENARIO = '';
const cli = mode => cp.execFileSync('/tmp/cycle_cli', [TODAY, mode].concat(SCENARIO ? [SCENARIO] : [])).toString().trim();
let reminderStored = { enabled: false, hour: 20, minute: 0, cycleAlerts: false, permission: true };
let copyResult = true;
const Core = {
  getMetrics: () => cli('metrics'), getSummary: () => cli('summary'),
  getReminder: () => JSON.stringify(reminderStored),
  setCycleAlerts: v => { calls.core.push(['setCycleAlerts', v]); reminderStored.cycleAlerts = v; },
  newCycle: () => { calls.core.push(['newCycle']); return true; },
  setAllowance: v => { calls.core.push(['setAllowance', v]); return true; },
  setSavingsGoal: v => { calls.core.push(['setSavingsGoal', v]); return true; },
  copyText: t => { calls.copied = t; return copyResult; },
};
const appState = { allowance: 1700, effective: 1700, added: 0, topups: [], savingsGoal: 1000, cycle: 'weekly', expenses: [] };
const navigator = { clipboard: null };
const api = new Function('document','Core','appState','calls','localStorage','navigator','window','getTodayISO', `
  ${fmt}
  ${time12}
  const calculateMetrics = () => JSON.parse(Core.getMetrics());
  const openModal = id => document.getElementById(id).classList.remove('hidden');
  const closeModal = id => document.getElementById(id).classList.add('hidden');
  const showToast = (m, t) => calls.toasts.push([m, t || 'success']);
  const syncState = () => {}, renderAll = () => {};
  ${code}
  return { renderCycleCountdown, checkRollover, openRollover, snoozeRollover, confirmRollover, openSummary, copySummary,
           onCycleAlertChange, loadReminder, renderReminder };
`)(document, Core, appState, calls, localStorage, navigator, {}, () => TODAY);

let fails = 0;
const eq = (label, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); if (!ok) fails++; console.log((ok?'ok   ':'FAIL ')+label+(ok?'':`\n     got:  ${JSON.stringify(got)}\n     want: ${JSON.stringify(want)}`)); };
const label = iso => new Date(iso + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
const segs = () => { const m = els.cycleBar.innerHTML.match(/class="flex-1 h-2 rounded-sm ([^"]+)"/g) || []; return m.map(x => x.replace(/.*rounded-sm /, '').replace('"', '')); };
const last = () => calls.toasts[calls.toasts.length - 1];

// ---------------------------------------------------------------- countdown
SCENARIO = 'empty'; api.renderCycleCountdown();
eq('not started: big', els.cycleBig.textContent, '7 days');
eq('not started: sub', els.cycleSub.textContent, 'Your 7-day cycle starts when you log your first expense.');
eq('not started: 7 empty segments', segs(), Array(7).fill('bg-slate-200'));
SCENARIO = '';
TODAY = '2026-11-12'; api.renderCycleCountdown();
eq('day 4: big', els.cycleBig.textContent, '3 days left');
eq('day 4: sub', els.cycleSub.textContent, `Day 4 of 7 · ends ${label('2026-11-15')}`);
eq('day 4: bar', segs(), ['bg-brand-600','bg-brand-600','bg-brand-600','bg-brand-600','bg-slate-200','bg-slate-200','bg-slate-200']);
eq('day 4: normal colour', els.cycleBig.className.includes('text-slate-900'), true);
eq('day 4: no archive banner', els.cycleAction.classList.contains('hidden'), true);
TODAY = '2026-11-13'; api.renderCycleCountdown();
eq('2 days left is amber', [els.cycleBig.textContent, els.cycleBig.className.includes('text-amber-600')], ['2 days left', true]);
TODAY = '2026-11-14'; api.renderCycleCountdown();
eq('1 day left (singular)', els.cycleBig.textContent, '1 day left');
TODAY = '2026-11-15'; api.renderCycleCountdown();
eq('last day', [els.cycleBig.textContent, els.cycleSub.textContent.includes('ends today'), segs().every(c => c === 'bg-amber-500')], ['Last day!', true, true]);
TODAY = '2026-11-16'; api.renderCycleCountdown();
eq('ended: big', els.cycleBig.textContent, 'Cycle ended');
eq('ended: sub', els.cycleSub.textContent, `Your 7-day cycle ended yesterday (${label('2026-11-15')}).`);
eq('ended: rose + banner', [els.cycleBig.className.includes('text-rose-600'), els.cycleAction.classList.contains('hidden'), segs().every(c => c === 'bg-rose-500')], [true, false, true]);
TODAY = '2026-11-18'; api.renderCycleCountdown();
eq('ended 3 days ago', els.cycleSub.textContent.includes('ended 3 days ago'), true);

// ---------------------------------------------------------------- Smart Prompt
TODAY = '2026-11-12'; api.checkRollover();
eq('no prompt while the cycle is running', els.rolloverModal.classList.contains('hidden'), true);
TODAY = '2026-11-16'; api.checkRollover();
eq('prompt on day 8', els.rolloverModal.classList.contains('hidden'), false);
eq('prompt title', els.rolloverTitle.textContent, 'Your 7-day cycle has ended!');
eq('prompt text', els.rolloverText.textContent, 'Archive this week to Cycle History and start a new budget?');
eq('prompt shows the finished cycle', els.rolloverSummary.textContent, '₱650.00 spent of ₱1,700.00 · ₱1,050.00 left');
eq('budget prefilled (carry over)', [els.rolloverAllowance.value, els.rolloverGoal.value], [1700, 1000]);
els.rolloverAllowance.value = '2000'; api.checkRollover();
eq('prompt is not reset while open', els.rolloverAllowance.value, '2000');
api.snoozeRollover();
eq('"Not yet" closes it and remembers today', [els.rolloverModal.classList.contains('hidden'), storage.baon_rollover_snooze], [true, '2026-11-16']);
api.checkRollover();
eq('not asked again the same day', els.rolloverModal.classList.contains('hidden'), true);
TODAY = '2026-11-17'; api.checkRollover();
eq('asked again the next day', els.rolloverModal.classList.contains('hidden'), false);

// ---------------------------------------------------------------- confirm rollover
els.rolloverAllowance.value = '1700'; els.rolloverGoal.value = '1800'; api.confirmRollover();
eq('goal above allowance rejected', [last(), calls.core.some(c => c[0] === 'newCycle')], [['Your savings goal cannot be more than your allowance.', 'error'], false]);
els.rolloverAllowance.value = '-5'; els.rolloverGoal.value = '0'; api.confirmRollover();
eq('negative rejected', last(), ['Enter a valid allowance and savings goal.', 'error']);
els.rolloverAllowance.value = '1800'; els.rolloverGoal.value = '500'; api.confirmRollover();
eq('archives then sets the new budget, in that order', calls.core.filter(c => c[0] !== 'setCycleAlerts'), [['newCycle'], ['setAllowance', 1800], ['setSavingsGoal', 500]]);
eq('closes and clears the snooze', [els.rolloverModal.classList.contains('hidden'), 'baon_rollover_snooze' in storage], [true, false]);
eq('success toast', last(), ['Cycle saved to history. Your new budget is set!', 'success']);
api.openRollover(); els.rolloverAllowance.value = '1000'; els.rolloverGoal.value = '700'; api.confirmRollover();
eq('60% warning', last(), ['⚠️ Warning: Savings goal exceeds 60% of allowance!', 'error']);

// ---------------------------------------------------------------- summary report
TODAY = '2026-11-12'; api.openSummary();
eq('summary text shown', els.summaryText.textContent.startsWith('BAONTRACK SUMMARY\nWeekly cycle (7 days) · Nov 9 – Nov 15, 2026'), true);
eq('summary window opened', els.summaryModal.classList.contains('hidden'), false);
api.copySummary();
eq('copied through Android', [calls.copied === els.summaryText.textContent, last()], [true, ['Summary copied to clipboard', 'success']]);
copyResult = false; api.copySummary();
eq('no clipboard at all -> helpful error', last()[1], 'error');
navigator.clipboard = { writeText: t => Promise.resolve() };
api.copySummary();

// ---------------------------------------------------------------- cycle warnings toggle
api.loadReminder(); api.renderReminder();
els.cycleAlertToggle.checked = true; api.onCycleAlertChange();
eq('warning setting sent to Android', calls.core.filter(c => c[0] === 'setCycleAlerts'), [['setCycleAlerts', true]]);
eq('toast', last(), ['You will get a warning before your cycle ends', 'info']);
reminderStored.permission = false; api.loadReminder(); api.renderReminder();
eq('blocked-notifications note when only cycle warnings are on', els.reminderNote.textContent.startsWith('Notifications are blocked'), true);

setTimeout(() => {
  eq('clipboard fallback worked', last(), ['Summary copied to clipboard', 'success']);
  console.log(fails ? `\n${fails} FAILED` : '\nALL CYCLE UI CHECKS PASSED');
  process.exit(fails ? 1 : 0);
}, 50);
