const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const script = html.slice(html.lastIndexOf('<script>') + 8, html.lastIndexOf('</script>'));
const cut = (a, b) => script.slice(script.indexOf(a), script.indexOf(b));
const parts = [
  cut('function formatCurrency', 'function getTodayISO'),
  cut('const CATEGORIES = {', 'const appStateMarker') ,
];
// CATEGORIES block + escapeHTML + renderExpenseList + new feature code
const catBlock = script.slice(script.indexOf('const CATEGORIES = {'), script.indexOf('};', script.indexOf('const CATEGORIES = {')) + 2);
const listFn = cut('function renderExpenseList', '/**\n         * Prevent XSS');
const escFn = cut('function escapeHTML', '/**\n         * Modal');   // may be empty if marker differs
const esc = script.slice(script.indexOf('function escapeHTML'), script.indexOf('}', script.indexOf('return div.innerHTML') ) + 1);
const feat = cut('function formatTime12', '        // Initialize App on Window Load');

const [catsJson, histJson, stateJson] = fs.readFileSync('/tmp/features.json', 'utf8').trim().split('\n');
class CL { constructor(){ this.s = new Set(); } toggle(c,on){ on===undefined ? (this.s.has(c)?this.s.delete(c):this.s.add(c)) : (on?this.s.add(c):this.s.delete(c)); } add(c){this.s.add(c);} remove(c){this.s.delete(c);} contains(c){return this.s.has(c);} }
const els = {};
function El(id){ this.id=id; this.value=''; this.textContent=''; this.className=''; this.innerHTML=''; this.checked=false; this.style={}; this.classList=new CL(); }
const document = { getElementById: id => els[id] || (els[id] = new El(id)), createElement: () => ({ set textContent(v){ this._t = String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }, get innerHTML(){ return this._t; } }) };
const calls = { toasts: [], modal: [], timers: [], reminder: null, limits: [] };
let reminderStored = { enabled: false, hour: 20, minute: 0, permission: true };
const Core = {
  getCategories: () => catsJson, getHistory: () => histJson,
  getReminder: () => JSON.stringify(reminderStored),
  setReminder: (e, h, m) => { reminderStored = { enabled: e, hour: h, minute: m, permission: true }; calls.reminder = [e, h, m]; },
  testReminder: () => { calls.test = true; }, clearHistory: () => { calls.cleared = true; histOverride = '{"cycles":[]}'; },
  setCategoryLimit: (n, v) => { calls.limits.push([n, v]); }, newCycle: () => true,
};
let histOverride = null;
Core.getHistory = () => histOverride || histJson;
const appState = { allowance: 1700, effective: 1700, added: 0, topups: [], savingsGoal: 1000, cycle: 'weekly', expenses: JSON.parse(stateJson).expenses, activeFilter: 'All' };
const api = new Function('document','Core','appState','calls','setTimeout','window', `
  ${parts[0]}
  ${catBlock}
  const escapeHTML = s => String(s);
  const openModal = id => calls.modal.push('open:'+id), closeModal = id => calls.modal.push('close:'+id);
  const showToast = (m,t) => calls.toasts.push([m,t||'success']);
  const renderAll = () => {};
  ${listFn}
  ${feat}
  return { formatTime12, limitBlock, notifyLimit, categoryInfo, renderHistory, toggleHistoryAll, clearHistoryTap, renderExpenseList,
           openLimits, saveLimits, updateLimitsSummary, loadReminder, renderReminder, onReminderChange, testReminder };
`)(document, Core, appState, calls, (fn, ms) => calls.timers.push([fn, ms]), {});

let fails = 0;
const eq = (label, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); if (!ok) fails++; console.log((ok?'ok   ':'FAIL ')+label+(ok?'':`\n     got:  ${JSON.stringify(got)}\n     want: ${JSON.stringify(want)}`)); };
const has = (label, hay, needle) => { const ok = hay.includes(needle); if (!ok) fails++; console.log((ok?'ok   ':'FAIL ')+label+(ok?'':`\n     missing: ${needle}`)); };

// ---- time formatting
eq('14:35', api.formatTime12('14:35'), '2:35 PM');
eq('00:05', api.formatTime12('00:05'), '12:05 AM');
eq('12:00', api.formatTime12('12:00'), '12:00 PM');
eq('empty', api.formatTime12(''), '');

// ---- expense list shows time and sorts newest first
api.renderExpenseList();
const list = els.expenseListContainer.innerHTML;
has('time on expense row', list, 'Nov 28, 2026 · 12:00 PM');
has('time (AM)', list, 'Nov 28, 2026 · 12:05 AM');
eq('same-day order: later time first', list.indexOf('Notebook') < list.indexOf('Groceries'), true);

// ---- limits
const food = JSON.parse(catsJson).categories[0];
has('limit block shows limit', api.limitBlock(food), 'Limit ₱500.00 · 90%');
has('warn colour', api.limitBlock(food), 'text-amber-600');
eq('no block without limit', api.limitBlock({ limit: 0 }), '');
api.notifyLimit({ status: 'ok' }, { name: 'Food', limit: 500, status: 'warn', percent: 82, remaining: 90 });
eq('80% toast', calls.toasts.slice(-1)[0], ['Food is at 82% of its ₱500.00 limit.', 'info']);
api.notifyLimit({ status: 'warn' }, { name: 'Food', limit: 500, status: 'over', percent: 110, remaining: -50 });
eq('over toast', calls.toasts.slice(-1)[0], ['⚠️ Food is over its limit by ₱50.00.', 'error']);
const n = calls.toasts.length;
api.notifyLimit({ status: 'over' }, { name: 'Food', limit: 500, status: 'over', percent: 120, remaining: -100 });
api.notifyLimit({ status: 'ok' }, { name: 'Food', limit: 500, status: 'ok', percent: 50, remaining: 250 });
eq('no repeat toast when status does not worsen', calls.toasts.length, n);
document.getElementById('limitFood').value = '500'; document.getElementById('limitSchool').value = '1500'; api.updateLimitsSummary();
has('limits above allowance warns', els.limitsSummary.textContent, 'more than your allowance of ₱1,700.00');
document.getElementById('limitFood').value = '500'; document.getElementById('limitSchool').value = ''; api.saveLimits();
eq('save sends all four categories', calls.limits.map(x => x[0]).join(), 'Food,School,Personal,Strolling');
eq('save sends values', calls.limits.map(x => x[1]).join(), '500,0,0,0');
document.getElementById('limitFood').value = '-5'; calls.limits = []; api.saveLimits();
eq('negative limit rejected', [calls.limits.length, calls.toasts.slice(-1)[0][1]], [0, 'error']);

// ---- history
api.renderHistory();
const hist = els.historyList.innerHTML;
has('newest cycle first', hist, 'Nov 20 – Nov 22, 2026');
eq('newest before oldest', hist.indexOf('Nov 20') < hist.indexOf('Nov 12'), true);
has('goal missed', hist, 'Goal missed · saved ₱900.00');
has('goal met', hist, 'Goal met · saved ₱1,070.00');
has('delta vs previous', hist, '▲ ₱170.00 more than the cycle before');
has('expense count + avg', hist, 'Weekly · 4 expenses · avg ₱157.50/day');
has('newest cycle summary', hist, 'Weekly · 1 expense · avg ₱266.67/day');
has('category bar segment', hist, 'bg-amber-500 h-1.5');
eq('clear button visible', els.historyClearBtn.classList.contains('hidden'), false);
eq('"show all" hidden for 2 cycles', els.historyMore.classList.contains('hidden'), true);

// two taps to clear
api.clearHistoryTap();
eq('first tap asks to confirm', [els.historyClearBtn.textContent, !!calls.cleared], ['Tap again to confirm', false]);
api.clearHistoryTap();
eq('second tap clears', [!!calls.cleared, calls.toasts.slice(-1)[0][0]], [true, 'Cycle history cleared.']);
has('empty state after clearing', els.historyList.innerHTML, 'No finished cycles yet');
eq('clear button hidden when empty', els.historyClearBtn.classList.contains('hidden'), true);

// ---- reminder
api.loadReminder(); api.renderReminder();
has('off note', els.reminderNote.textContent, 'Off.');
document.getElementById('reminderToggle').checked = true; document.getElementById('reminderTime').value = '19:30'; api.onReminderChange();
eq('reminder saved to Android', calls.reminder, [true, 19, 30]);
has('note shows 12h time', els.reminderNote.textContent, 'Reminder set for 7:30 PM every day');
eq('toast', calls.toasts.slice(-1)[0], ['Daily reminder set for 7:30 PM', 'info']);
reminderStored.permission = false; api.testReminder();
eq('test blocked without permission', calls.test, undefined);
reminderStored.permission = true; api.testReminder();
eq('test sent', calls.test, true);

console.log(fails ? `\n${fails} FAILED` : '\nALL FEATURE UI CHECKS PASSED');
process.exit(fails ? 1 : 0);
