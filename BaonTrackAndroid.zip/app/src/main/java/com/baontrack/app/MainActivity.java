package com.baontrack.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Hosts the BaonTrack UI (assets/index.html) in a WebView. Every calculation,
 * the CSV logic and the saved data live in the C++ core, reached through the
 * "BaonNative" JavaScript interface.
 */
public class MainActivity extends Activity {
    private static final int REQ_PICK_CSV = 1001;
    private static final int REQ_SAVE_CSV = 1002;
    private static final int MAX_CSV_BYTES = 5 * 1024 * 1024;

    private WebView webView;
    private volatile byte[] pendingExport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeCore.init(new File(getFilesDir(), "baontrack_state.csv").getAbsolutePath());

        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);          // we only load our own packaged asset
        ws.setAllowContentAccess(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "BaonNative");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("BaonNative");
            webView.destroy();
        }
        super.onDestroy();
    }

    private void js(final String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    /** Methods here are called from JavaScript on a background thread. */
    public final class Bridge {
        @JavascriptInterface public String getState() { return NativeCore.getState(); }
        @JavascriptInterface public String getMetrics() { return NativeCore.getMetrics(); }
        @JavascriptInterface public boolean setAllowance(double v) { return NativeCore.setAllowance(v); }
        @JavascriptInterface public boolean setSavingsGoal(double v) { return NativeCore.setSavingsGoal(v); }
        @JavascriptInterface public void setCycle(String c) { NativeCore.setCycle(c); }
        @JavascriptInterface public String addExpense(double a, String cat, String note, String date) {
            return NativeCore.addExpense(a, cat, note, date);
        }
        @JavascriptInterface public double deleteExpense(String id) { return NativeCore.deleteExpense(id); }
        @JavascriptInterface public int clearExpenses() { return NativeCore.clearExpenses(); }
        @JavascriptInterface public void resetAll() { NativeCore.resetAll(); }

        @JavascriptInterface
        public void exportCsv(final String filename) {
            pendingExport = NativeCore.exportCsvBytes();
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/csv");
                i.putExtra(Intent.EXTRA_TITLE, filename);
                startActivityForResult(i, REQ_SAVE_CSV);
            });
        }

        @JavascriptInterface
        public void pickCsv() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "text/csv", "text/comma-separated-values", "text/plain",
                        "application/vnd.ms-excel", "application/octet-stream"});
                startActivityForResult(Intent.createChooser(i, "Choose a CSV file"), REQ_PICK_CSV);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        final Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;

        if (requestCode == REQ_SAVE_CSV) {
            boolean ok = false;
            if (uri != null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) { out.write(pendingExport); ok = true; }
                } catch (Exception ignored) { }
            }
            pendingExport = null;
            js("window.onNativeSaved && window.onNativeSaved(" + ok + ")");
        } else if (requestCode == REQ_PICK_CSV) {
            if (uri == null) return;  // user cancelled
            String result;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int n;
                while (in != null && (n = in.read(chunk)) != -1) {
                    buf.write(chunk, 0, n);
                    if (buf.size() > MAX_CSV_BYTES) throw new IllegalStateException("too big");
                }
                result = NativeCore.importCsv(buf.toByteArray());
            } catch (Exception e) {
                result = "{\"ok\":false,\"imported\":0,\"hasMetadata\":false,\"error\":\"Unable to read the selected CSV file.\"}";
            }
            js("window.onNativeImport && window.onNativeImport(" + result + ")");
        }
    }
}
