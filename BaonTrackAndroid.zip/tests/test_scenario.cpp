// Daily-budget behaviour: logging an expense equal to the daily limit must not change the daily limit.
#include <cassert>
#include <cmath>
#include <cstdio>
#include "../app/src/main/cpp/baon_core.h"
static bool near(double a, double b) { return std::fabs(a - b) < 0.01; }
int main() {
    {   // weekly, 1700 allowance, 1000 savings goal -> 700 spendable -> 100/day
        baon::Core c; c.setTodayOverride("2026-11-16");
        c.setCycle("weekly"); c.setAllowance(1700); c.setSavingsGoal(1000);
        auto m = c.metrics();
        assert(m.remainingDays == 7 && near(m.safeDailySpend, 100) && near(m.targetDailyBudget, 100));
        assert(near(m.projectedEndBalance, 1000));
        c.addExpense(100, "Food", "lunch", "2026-11-16");          // spend exactly the daily limit
        m = c.metrics();
        assert(m.remainingDays == 6 && near(m.safeDailySpend, 100));   // unchanged
        assert(near(m.projectedEndBalance, 1000));
        c.addExpense(100, "Food", "dinner", "2026-11-16");          // overspend today -> limit drops
        m = c.metrics();
        assert(near(m.safeDailySpend, 500.0 / 6));
    }
    {   // monthly example from the report
        baon::Core c; c.setTodayOverride("2026-11-16");
        c.setCycle("monthly"); c.setAllowance(9000); c.setSavingsGoal(4500);
        auto m = c.metrics();
        assert(m.remainingDays == 30 && near(m.safeDailySpend, 150));
    }
    std::puts("SCENARIO TESTS PASSED");
}
