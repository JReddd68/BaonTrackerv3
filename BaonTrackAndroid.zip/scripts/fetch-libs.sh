#!/usr/bin/env bash
# Downloads the UI libraries and packs them into app/src/main/assets/vendor/ so the APK works offline.
#   Tailwind CSS 3.x  -> built to one small static CSS file (only the classes index.html uses)
#   Chart.js          -> chart.umd.js
#   Font Awesome Free -> CSS + woff2 icon fonts
#   Inter             -> variable woff2 (latin + latin-ext; latin-ext holds the peso sign)
# Needs Node.js + npm. Run from anywhere:  bash scripts/fetch-libs.sh
set -euo pipefail

TAILWIND_VERSION=3.4.17
CHARTJS_VERSION=4.4.1
FONTAWESOME_VERSION=6.5.1
INTER_VERSION='^5.1.0'      # @fontsource-variable/inter

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets"
OUT="$ASSETS/vendor"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "==> Downloading packages from npm"
( cd "$WORK" \
  && npm init -y >/dev/null \
  && npm install --no-audit --no-fund --loglevel=error \
       "tailwindcss@$TAILWIND_VERSION" \
       "chart.js@$CHARTJS_VERSION" \
       "@fortawesome/fontawesome-free@$FONTAWESOME_VERSION" \
       "@fontsource-variable/inter@$INTER_VERSION" )
NM="$WORK/node_modules"

need() { [ -s "$1" ] || { echo "ERROR: expected file not found: $1" >&2; exit 1; }; }

rm -rf "$OUT"
mkdir -p "$OUT/inter" "$OUT/fontawesome/css" "$OUT/fontawesome/webfonts"

echo "==> Chart.js"
need "$NM/chart.js/dist/chart.umd.js"
cp "$NM/chart.js/dist/chart.umd.js" "$OUT/chart.umd.js"

echo "==> Font Awesome"
need "$NM/@fortawesome/fontawesome-free/css/all.min.css"
cp "$NM/@fortawesome/fontawesome-free/css/all.min.css" "$OUT/fontawesome/css/all.min.css"
cp "$NM/@fortawesome/fontawesome-free/webfonts/"*.woff2 "$OUT/fontawesome/webfonts/"
need "$OUT/fontawesome/webfonts/fa-solid-900.woff2"

echo "==> Inter"
for f in inter-latin-wght-normal.woff2 inter-latin-ext-wght-normal.woff2; do
  src="$(find "$NM/@fontsource-variable/inter" -name "$f" | head -n 1)"
  if [ -z "$src" ]; then
    echo "ERROR: $f not found in @fontsource-variable/inter. Files present:" >&2
    find "$NM/@fontsource-variable/inter" -name '*.woff2' >&2
    exit 1
  fi
  cp "$src" "$OUT/inter/$f"
done
# latin-ext is declared first with no range (fallback for any other character, incl. the peso sign U+20B1);
# latin comes last, so it wins for ordinary letters and digits.
cat > "$OUT/inter/inter.css" <<'CSS'
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 100 900;
  font-display: swap;
  src: url('./inter-latin-ext-wght-normal.woff2') format('woff2');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 100 900;
  font-display: swap;
  src: url('./inter-latin-wght-normal.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
CSS

echo "==> Tailwind CSS (building from index.html)"
( cd "$ROOT" && "$NM/.bin/tailwindcss" \
    -c scripts/tailwind.config.js \
    -i scripts/tailwind-input.css \
    -o "$OUT/tailwind.css" --minify )
need "$OUT/tailwind.css"

echo "==> Checking the page no longer points at the internet"
if grep -nE '(src|href)=["'"'"']https?://' "$ASSETS/index.html"; then
  echo "ERROR: index.html still loads something from the internet (lines above)." >&2
  exit 1
fi

echo "==> Done. Bundled files:"
( cd "$OUT" && find . -type f -exec du -k {} + | sort -k2 )
