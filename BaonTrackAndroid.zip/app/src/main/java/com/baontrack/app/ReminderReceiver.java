package com.baontrack.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONObject;

import java.io.File;

/** Runs when the daily alarm fires and shows the reminder notification. */
public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "baon_reminder";
    private static final int NOTIFICATION_ID = 7001;

    @Override
    public void onReceive(Context context, Intent intent) {
        show(context, false);
    }

    /** force = true is used by the "Send test" button: it shows the notification even if you already logged today. */
    static void show(Context context, boolean force) {
        NativeCore.init(new File(context.getFilesDir(), "baontrack_state.csv").getAbsolutePath());

        double safe = 0, allowance = 0;
        boolean loggedToday = false;
        try {
            JSONObject m = new JSONObject(NativeCore.getMetrics());
            safe = m.optDouble("safeDailySpend", 0);
            allowance = m.optDouble("allowance", 0);
            loggedToday = m.optBoolean("loggedToday", false);
        } catch (Exception ignored) { }

        if (loggedToday && !force) return;                          // already logged something today: no nagging
        if (!ReminderScheduler.hasNotificationPermission(context)) return;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Daily reminder", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Reminds you to log today's expenses");
            nm.createNotificationChannel(channel);
        }

        String text = allowance > 0
                ? "Did you log today's expenses? Safe to spend today: " + BaonWidgetProvider.money(safe)
                : "Don't forget to log today's expenses.";

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        b.setSmallIcon(R.drawable.ic_stat_wallet)
                .setContentTitle("BaonTrack")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setColor(0xFF5B45E0)
                .setContentIntent(contentIntent)
                .setAutoCancel(true);
        nm.notify(NOTIFICATION_ID, b.build());
    }
}
