// Prints the core's JSON for a fixed scenario so the page's JavaScript can be tested against real output.
#include <cstdio>
#include <string>
#include "../app/src/main/cpp/baon_core.h"
int main() {
    baon::Core c;
    c.setTodayOverride("2026-11-15"); c.setTimeOverride("14:35");
    c.setCycle("weekly"); c.setAllowance(1700); c.setSavingsGoal(1000);
    c.setCategoryLimit("Food", 500);
    c.addExpense(300, "Food", "Lunch", "2026-11-15");
    c.setTimeOverride("08:05"); c.addExpense(100, "Food", "Breakfast", "2026-11-15");
    c.setTimeOverride("21:00"); c.addExpense(150, "Food", "Dinner", "2026-11-14");
    c.addExpense(80, "School", "Pen", "2026-11-12");
    c.newCycle();
    c.setTodayOverride("2026-11-22");
    c.addExpense(800, "Personal", "Shoes", "2026-11-20");
    c.newCycle();
    c.setTodayOverride("2026-11-29");
    c.setTimeOverride("00:05"); c.addExpense(450, "Food", "Groceries", "2026-11-28");
    c.setTimeOverride("12:00"); c.addExpense(60, "School", "Notebook", "2026-11-28");
    std::printf("%s\n%s\n%s\n", c.categoriesJson().c_str(), c.historyJson().c_str(), c.stateJson().c_str());
}
