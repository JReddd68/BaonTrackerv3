// Tiny command-line wrapper used to test the page's JavaScript against the real C++ numbers.
#include <cstdio>
#include <cstdlib>
#include "../app/src/main/cpp/baon_core.h"
int main(int argc, char** argv) {
    if (argc < 5) return 1;
    std::puts(baon::Core::estimateJson(std::atof(argv[1]), std::atoi(argv[2]), std::atof(argv[3]), std::atof(argv[4])).c_str());
}
