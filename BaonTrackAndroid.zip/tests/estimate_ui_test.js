const fs = require('fs'), cp = require('child_process');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const script = html.slice(html.lastIndexOf('<script>') + 8, html.lastIndexOf('</script>'));
const cut = (a, b) => script.slice(script.indexOf(a), script.indexOf(b));
const fmt = cut('function formatCurrency', 'function getTodayISO');
const est = cut('const EST_CHIP_BASE', '/**\n         * Press and hold the wallet icon');
const apply = ''; // included in est

class ClassList { constructor(el){this.el=el;this.set=new Set();} toggle(c,on){ on===undefined?(this.set.has(c)?this.set.delete(c):this.set.add(c)):(on?this.set.add(c):this.set.delete(c)); } add(c){this.set.add(c);} remove(c){this.set.delete(c);} contains(c){return this.set.has(c);} }
const els = {};
function El(id){ this.id=id; this.value=''; this.textContent=''; this.className=''; this.style={}; this.disabled=false; this.classList=new ClassList(this);
  this.parentElement = id==='estProjection' ? {classList:new ClassList()} : null; this._span={textContent:''}; this.querySelector=()=>this._span; }
const document = { getElementById: id => els[id] || (els[id] = new El(id)) };
const calls = { toasts: [], modal: [], goal: null };
const Core = {
  estimate: (d, n, b, t) => cp.execFileSync('/tmp/estimate_cli', [d, n, b, t].map(String)).toString(),
  setSavingsGoal: v => { calls.goal = v; return true; },
};
const appState = { allowance: 1700, savingsGoal: 0, cycle: 'weekly', expenses: [] };
const ctx = new Function('document','Core','appState','calls', `
  ${fmt}
  const openModal = id => calls.modal.push('open:'+id), closeModal = id => calls.modal.push('close:'+id);
  const showToast = (m,t) => calls.toasts.push([m,t||'success']);
  const syncState = () => {}, renderAll = () => {};
  ${est}
  return { openEstimate, setEstDaily, setEstDays, updateEstimate, useEstimateAsGoal, useEstimateTarget, applyEstimateGoal, getLast: () => estLast };
`)(document, Core, appState, calls);

let fails = 0;
const eq = (label, got, want) => { const ok = got === want; if (!ok) fails++; console.log((ok ? 'ok   ' : 'FAIL ') + label + (ok ? '' : `\n     got:  ${got}\n     want: ${want}`)); };
const T = id => els[id].textContent;

ctx.openEstimate();
eq('opens with weekly days', els.estDays.value, 7);
eq('opens with allowance as budget', els.estBudget.value, 1700);
eq('empty state text', T('estTotalSub'), 'Type how much you spend each day');
ctx.setEstDaily(50);
eq('50/day x 7 days -> total', T('estTotal'), '₱350.00');
eq('sub line', T('estTotalSub'), 'in 7 days at ₱50.00 a day');
eq('budget', T('estBudgetVal'), '₱1,700.00');
eq('left over', T('estLeftVal'), '₱1,350.00');
eq('status', T('estStatus'), 'Within budget · 20.6% of your budget used.');
eq('lasts', T('estLasts'), 'At this pace your budget lasts 34 days.');
eq('projection', T('estProjection'), 'That is ₱350.00 per week, or ₱1,500.00 per 30 days.');
eq('use-goal enabled', els.estUseGoal.disabled, false);
eq('use-goal label', els.estUseGoal._span.textContent, 'Use ₱1,350.00 as my savings goal');
eq('bar width', els.estBar.style.width, '20.5882%');
eq('7-day chip active', els.estChip7.className.includes('bg-brand-600'), true);

ctx.setEstDaily(300);
eq('over budget total', T('estTotal'), '₱2,100.00');
eq('over budget status', T('estStatus'), 'Over budget by ₱400.00. Spend at most ₱242.86 a day to stay within ₱1,700.00.');
eq('over budget disables button', els.estUseGoal.disabled, true);
eq('over budget bar is red', els.estBar.className.includes('bg-rose-500'), true);

ctx.setEstDaily(50);
els.estTarget.value = '500'; ctx.updateEstimate();
eq('daily limit finder', T('estTargetResult'), 'Spend at most ₱171.43 a day (₱1,200.00 over 7 days).');
eq('no warning at 500', els.estTargetWarn.classList.contains('hidden'), true);
els.estTarget.value = '1100'; ctx.updateEstimate();
eq('60% warning shows', els.estTargetWarn.classList.contains('hidden'), false);
eq('60% warning text', T('estTargetWarn').startsWith('⚠️ You may die to hunger!'), true);
els.estTarget.value = '2000'; ctx.updateEstimate();
eq('target above budget', T('estTargetResult'), 'That is more than your budget of ₱1,700.00.');
eq('target button disabled', els.estTargetBtn.disabled, true);

ctx.setEstDays(30);
els.estTarget.value = '500'; ctx.updateEstimate();
eq('30-day chip active', els.estChip30.className.includes('bg-brand-600'), true);
eq('30 days limit', T('estTargetResult'), 'Spend at most ₱40.00 a day (₱1,200.00 over 30 days).');

ctx.useEstimateTarget();
eq('target applied as savings goal', calls.goal, 500);
eq('modal closed + toast', JSON.stringify([calls.modal.slice(-1)[0], calls.toasts.slice(-1)[0][0]]), JSON.stringify(['close:estimateModal', 'Savings goal set to ₱500.00']));
els.estTarget.value = ''; ctx.setEstDaily(50); ctx.setEstDays(7); ctx.useEstimateAsGoal();
eq('leftover applied as savings goal', calls.goal, 1350);
eq('over-60% leftover warns', calls.toasts.slice(-1)[0][0], '⚠️ Warning: Savings goal exceeds 60% of allowance!');
console.log(fails ? `\n${fails} FAILED` : '\nALL ESTIMATION UI CHECKS PASSED');
process.exit(fails ? 1 : 0);
