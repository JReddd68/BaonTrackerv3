// BaonTrack core: allowance / savings / expense logic in portable C++17.
// No Android headers here, so it also builds and tests on a PC.
#pragma once
#include <mutex>
#include <string>
#include <vector>

namespace baon {

struct Expense {
    std::string id;
    std::string note;
    std::string category;  // Food | School | Personal | Strolling
    std::string date;      // YYYY-MM-DD
    std::string time;      // HH:MM (24 h, phone clock) when the expense was logged; "" for old entries
    double amount = 0.0;
};

// The four expense categories, in display order.
constexpr int kCategoryCount = 4;
constexpr int kMaxHistory = 100;   // finished cycles kept in the history (oldest are dropped)

// One finished allowance cycle, saved when the user starts a new cycle.
struct CycleRecord {
    std::string start, end;   // YYYY-MM-DD
    std::string cycle;        // "weekly" | "monthly"
    double allowance = 0, savingsGoal = 0, spent = 0;
    int count = 0;            // number of expenses
    double byCategory[kCategoryCount] = {0, 0, 0, 0};
};

struct Metrics {
    int totalDaysInCycle = 7;
    double totalSpent = 0, remaining = 0, percentUsed = 0;
    int activeDays = 1, remainingDays = 0;
    double dailyAverage = 0, paceDaily = 0, txAverage = 0;
    bool hasEnoughHistory = false;
    double projectedEndBalance = 0, safeDailySpend = 0, targetDailyBudget = 0;
    double savingsGoal = 0, maxAllowedSpending = 0, safeSpendRemaining = 0;
    double savingsPercentOfAllowance = 0;
    double allowance = 0;
    bool loggedToday = false;   // at least one expense is dated today

    // Calendar countdown. A cycle starts on the date of its earliest expense and lasts totalDaysInCycle days.
    bool cycleStarted = false;          // false until the first expense is logged
    std::string cycleStart, cycleEnd;   // YYYY-MM-DD (empty until started); cycleEnd is the last day of the cycle
    int cycleDay = 0;                   // 1 on the first day ... totalDaysInCycle on the last day
    int cycleDaysLeft = 7;              // 0 on the last day, negative once the cycle is over
    bool cycleEnded = false;            // today is after the last day
    int cycleDaysOver = 0;              // how many days past the end
};

struct ImportResult {
    bool ok = false;
    int imported = 0;
    bool hasMetadata = false;
    std::string error;
};

class Core {
public:
    // Loads saved data (if any) from storagePath; every change is saved back to it.
    void init(const std::string& storagePath);
    void setTodayOverride(const std::string& iso);  // for tests only
    void setTimeOverride(const std::string& hhmm);  // for tests only

    std::string stateJson() const;
    std::string metricsJson() const;
    Metrics metrics() const;

    bool setAllowance(double v);
    bool setSavingsGoal(double v);
    void setCycle(const std::string& cycle);  // "weekly" | "monthly"

    // Returns the new expense id, or "" if the amount is invalid.
    std::string addExpense(double amount, const std::string& category,
                           const std::string& note, const std::string& date);
    // Returns the refunded amount, or -1 if the id was not found.
    double deleteExpense(const std::string& id);
    int clearExpenses();
    void resetAll();

    // ---- category limits: a spending cap per category for one cycle (0 = no limit)
    bool setCategoryLimit(const std::string& category, double amount);   // false: unknown category / bad amount
    std::string categoriesJson() const;   // spent, limit, percent and status ("none" | "ok" | "warn" 80%+ | "over" 100%+)

    // ---- cycle history
    bool newCycle();                      // saves the finished cycle (if it had expenses), then clears the expenses
    std::string historyJson() const;      // newest first, with the change versus the cycle before
    void clearHistory();

    // Plain-text report of the current cycle, ready to copy and paste.
    std::string summaryText() const;

    // What-if calculator behind the "Estimation" screen. Pure maths: it never reads or changes saved data.
    //   dailySpend  money spent per day          days        number of days (clamped to 1..365)
    //   budget      money available              saveTarget  amount to save, or a negative number for "none"
    static std::string estimateJson(double dailySpend, int days, double budget, double saveTarget);

    std::string exportCsv(bool withBom) const;
    ImportResult importCsv(const std::string& text);
    static std::string importResultJson(const ImportResult& r);

private:
    mutable std::mutex mu_;
    double allowance_ = 0, savingsGoal_ = 0;
    std::string cycle_ = "weekly";
    std::vector<Expense> expenses_;
    std::string path_, todayOverride_, timeOverride_;
    unsigned long nextId_ = 1;
    bool initialized_ = false;
    double limits_[kCategoryCount] = {0, 0, 0, 0};
    std::vector<CycleRecord> history_;

    std::string today() const;
    std::string nowTime() const;
    Metrics computeLocked() const;
    std::string exportLocked(bool withBom) const;
    ImportResult importLocked(const std::string& text);
    std::string newId();
    void saveLocked() const;
};

}  // namespace baon
