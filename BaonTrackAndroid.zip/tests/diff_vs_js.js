// Runs the ORIGINAL calculateMetrics() from the HTML and prints the same metrics for random scenarios.
const fs = require('fs');
const html = fs.readFileSync(process.argv[2], 'utf8');
const start = html.indexOf('function calculateMetrics()');
const end = html.indexOf('function renderDashboardMetrics()');
const src = html.slice(start, end);
let appState, TODAY;
const getTodayISO = () => TODAY;
const calc = new Function('appState', 'getTodayISO', src + '; return calculateMetrics();');

function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
function iso(d) { return d.toISOString().slice(0, 10); }
const scen = [], expected = [];
const base = new Date('2026-11-15T00:00:00Z');
for (let i = 0; i < 400; i++) {
  const cycle = Math.random() < 0.5 ? 'weekly' : 'monthly';
  const allowance = Math.random() < 0.1 ? 0 : rnd(100, 20000);
  const savings = Math.random() < 0.3 ? 0 : rnd(0, Math.round(allowance * 1.2));
  const n = Math.random() < 0.15 ? 0 : rnd(1, 12);
  const ex = [];
  for (let k = 0; k < n; k++) {
    const d = new Date(base); d.setUTCDate(d.getUTCDate() - rnd(0, 35));
    ex.push({ date: iso(d), amount: rnd(1, 3000) + rnd(0, 99) / 100 });
  }
  TODAY = iso(base);
  appState = { allowance, savingsGoal: savings, cycle, expenses: ex };
  expected.push(calc(appState, getTodayISO));
  scen.push(`${cycle} ${allowance} ${savings} ${TODAY} ${n ? ex.map(e => e.date + ':' + e.amount.toFixed(2)).join(',') : '-'}`);
}
fs.writeFileSync('/tmp/scen.txt', scen.join('\n') + '\n');
fs.writeFileSync('/tmp/expected.json', JSON.stringify(expected));
