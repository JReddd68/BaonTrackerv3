// Prints the core's metrics or summary for a fixed scenario on a chosen "today" (for the page's JavaScript tests).
//   cycle_cli <YYYY-MM-DD> <metrics|summary> [empty]
#include <cstdio>
#include <cstring>
#include <string>
#include "../app/src/main/cpp/baon_core.h"
int main(int argc, char** argv) {
    if (argc < 3) return 1;
    baon::Core c;
    c.setTodayOverride(argv[1]);
    c.setCycle("weekly"); c.setAllowance(1700); c.setSavingsGoal(1000); c.setCategoryLimit("Food", 500);
    if (!(argc > 3 && std::strcmp(argv[3], "empty") == 0)) {
        c.addExpense(300, "Food", "rice", "2026-11-09");
        c.addExpense(200, "Food", "lunch", "2026-11-10");
        c.addExpense(100, "School", "pen", "2026-11-12");
        c.addExpense(50, "Strolling", "snack", "2026-11-12");
    }
    std::puts((std::strcmp(argv[2], "summary") == 0 ? c.summaryText() : c.metricsJson()).c_str());
}
