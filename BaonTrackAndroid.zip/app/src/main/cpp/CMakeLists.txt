cmake_minimum_required(VERSION 3.22.1)
project(baoncore LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(baoncore SHARED
        baon_core.cpp
        native_bridge.cpp)

find_library(log-lib log)
target_link_libraries(baoncore ${log-lib})
