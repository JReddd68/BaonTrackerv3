// JNI glue between com.baontrack.app.NativeCore (Java) and baon::Core (C++).
// Strings travel as UTF-8 byte[] so emoji and other 4-byte characters are safe
// (JNI's NewStringUTF only accepts "modified" UTF-8).
#include <jni.h>

#include <string>

#include "baon_core.h"

namespace {

baon::Core& core() {
    static baon::Core instance;
    return instance;
}

std::string toStd(JNIEnv* env, jbyteArray arr) {
    if (!arr) return {};
    const jsize n = env->GetArrayLength(arr);
    std::string s(static_cast<size_t>(n), '\0');
    if (n > 0) env->GetByteArrayRegion(arr, 0, n, reinterpret_cast<jbyte*>(&s[0]));
    return s;
}

jbyteArray toJava(JNIEnv* env, const std::string& s) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(s.size()));
    if (arr && !s.empty())
        env->SetByteArrayRegion(arr, 0, static_cast<jsize>(s.size()),
                                reinterpret_cast<const jbyte*>(s.data()));
    return arr;
}

}  // namespace

#define JNI_FN(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_baontrack_app_NativeCore_##name

JNI_FN(void, nativeInit)(JNIEnv* env, jclass, jbyteArray path) { core().init(toStd(env, path)); }

JNI_FN(jbyteArray, nativeGetState)(JNIEnv* env, jclass) { return toJava(env, core().stateJson()); }

JNI_FN(jbyteArray, nativeGetMetrics)(JNIEnv* env, jclass) { return toJava(env, core().metricsJson()); }

JNI_FN(jboolean, nativeSetAllowance)(JNIEnv*, jclass, jdouble v) { return core().setAllowance(v); }

JNI_FN(jboolean, nativeSetSavingsGoal)(JNIEnv*, jclass, jdouble v) { return core().setSavingsGoal(v); }

JNI_FN(void, nativeSetCycle)(JNIEnv* env, jclass, jbyteArray cycle) { core().setCycle(toStd(env, cycle)); }

JNI_FN(jbyteArray, nativeAddExpense)(JNIEnv* env, jclass, jdouble amount, jbyteArray category,
                                     jbyteArray note, jbyteArray date) {
    return toJava(env, core().addExpense(amount, toStd(env, category), toStd(env, note), toStd(env, date)));
}

JNI_FN(jdouble, nativeDeleteExpense)(JNIEnv* env, jclass, jbyteArray id) {
    return core().deleteExpense(toStd(env, id));
}

JNI_FN(jint, nativeClearExpenses)(JNIEnv*, jclass) { return core().clearExpenses(); }

JNI_FN(void, nativeResetAll)(JNIEnv*, jclass) { core().resetAll(); }

JNI_FN(jboolean, nativeSetCategoryLimit)(JNIEnv* env, jclass, jbyteArray category, jdouble amount) {
    return core().setCategoryLimit(toStd(env, category), amount);
}

JNI_FN(jbyteArray, nativeGetCategories)(JNIEnv* env, jclass) { return toJava(env, core().categoriesJson()); }

JNI_FN(jboolean, nativeNewCycle)(JNIEnv*, jclass) { return core().newCycle(); }

JNI_FN(jbyteArray, nativeGetHistory)(JNIEnv* env, jclass) { return toJava(env, core().historyJson()); }

JNI_FN(void, nativeClearHistory)(JNIEnv*, jclass) { core().clearHistory(); }

JNI_FN(jbyteArray, nativeEstimate)(JNIEnv* env, jclass, jdouble dailySpend, jint days, jdouble budget,
                                   jdouble saveTarget) {
    return toJava(env, baon::Core::estimateJson(dailySpend, days, budget, saveTarget));
}

JNI_FN(jbyteArray, nativeExportCsv)(JNIEnv* env, jclass) { return toJava(env, core().exportCsv(true)); }

JNI_FN(jbyteArray, nativeImportCsv)(JNIEnv* env, jclass, jbyteArray csv) {
    return toJava(env, baon::Core::importResultJson(core().importCsv(toStd(env, csv))));
}
