package com.baontrack.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * The app lock's PIN. The PIN itself is never stored: only a salted PBKDF2 hash of it.
 * The settings live in their own preferences file ("baon_lock").
 */
final class AppLock {
    private static final String PREFS = "baon_lock";
    private static final int ITERATIONS = 10000;
    private static final int MAX_ATTEMPTS = 5;
    private static final long LOCKOUT_MS = 30000L;

    private AppLock() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean isEnabled(Context c) {
        SharedPreferences p = prefs(c);
        return p.getBoolean("enabled", false) && p.contains("hash") && p.contains("salt");
    }

    static int pinLength(Context c) { return prefs(c).getInt("len", 4); }

    static boolean biometricEnabled(Context c) { return prefs(c).getBoolean("bio", false); }

    static void setBiometric(Context c, boolean on) { prefs(c).edit().putBoolean("bio", on).apply(); }

    /** 4 to 6 digits. */
    static boolean isValidPin(String pin) {
        return pin != null && pin.matches("[0-9]{4,6}");
    }

    private static byte[] hash(String pin, byte[] salt) {
        try {
            SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            return f.generateSecret(new PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, 160)).getEncoded();
        } catch (Exception e) {
            return null;
        }
    }

    /** Turns the lock on with this PIN (or replaces the PIN). */
    static boolean enable(Context c, String pin) {
        if (!isValidPin(pin)) return false;
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        byte[] h = hash(pin, salt);
        if (h == null) return false;
        prefs(c).edit()
                .putBoolean("enabled", true)
                .putInt("len", pin.length())
                .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString("hash", Base64.encodeToString(h, Base64.NO_WRAP))
                .putInt("fails", 0)
                .putLong("lockUntil", 0L)
                .apply();
        return true;
    }

    static boolean verify(Context c, String pin) {
        SharedPreferences p = prefs(c);
        String salt = p.getString("salt", null);
        String stored = p.getString("hash", null);
        if (salt == null || stored == null || pin == null) return false;
        byte[] actual = hash(pin, Base64.decode(salt, Base64.NO_WRAP));
        return actual != null && MessageDigest.isEqual(actual, Base64.decode(stored, Base64.NO_WRAP));
    }

    /** Turns the lock off, but only for the right PIN. */
    static boolean disable(Context c, String pin) {
        if (!verify(c, pin)) return false;
        prefs(c).edit().clear().apply();
        return true;
    }

    static boolean change(Context c, String oldPin, String newPin) {
        if (!isValidPin(newPin) || !verify(c, oldPin)) return false;
        boolean bio = biometricEnabled(c);
        if (!enable(c, newPin)) return false;
        setBiometric(c, bio);
        return true;
    }

    // ---- too many wrong PINs: wait 30 seconds
    static long lockoutRemainingMs(Context c) {
        return Math.max(0L, prefs(c).getLong("lockUntil", 0L) - System.currentTimeMillis());
    }

    static void recordFailure(Context c) {
        SharedPreferences p = prefs(c);
        int fails = p.getInt("fails", 0) + 1;
        SharedPreferences.Editor e = p.edit();
        if (fails >= MAX_ATTEMPTS) {
            e.putInt("fails", 0).putLong("lockUntil", System.currentTimeMillis() + LOCKOUT_MS);
        } else {
            e.putInt("fails", fails);
        }
        e.apply();
    }

    static void recordSuccess(Context c) {
        prefs(c).edit().putInt("fails", 0).putLong("lockUntil", 0L).apply();
    }
}
