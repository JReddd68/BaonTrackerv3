// Page tests: Add money, the GCash tracker and the App Lock settings.
// Needs /tmp/wallet.json  (g++ -std=c++17 tests/wallet_cli.cpp app/src/main/cpp/baon_core.cpp -o /tmp/wallet_cli && /tmp/wallet_cli > /tmp/wallet.json)
const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const script = html.slice(html.lastIndexOf('<script>') + 8, html.lastIndexOf('</script>'));
const cut = (a, b) => script.slice(script.indexOf(a), script.indexOf(b));
const grab = re => { const m = script.match(re); if (!m) throw new Error('not found: ' + re); return m[0]; };
const fmt = cut('function formatCurrency', 'function getTodayISO');
const time12 = grab(/function formatTime12\(hhmm\) \{[\s\S]*?\n        \}\n/);
const shortDate = grab(/function shortDate\(iso\) \{[\s\S]*?\n        \}\n/);
const chips = grab(/const EST_CHIP_BASE[^\n]*\n\s*const EST_CHIP_ON[^\n]*\n\s*const EST_CHIP_OFF[^\n]*\n/);
const syncFn = grab(/function syncState\(\) \{[\s\S]*?\n        \}\n/);
const showTab = grab(/function showEstTab\(tab\) \{[\s\S]*?\n        \}\n/);
const code = cut('function renderMoney()', '        // Initialize App on Window Load');

const [stateJson, gcashJson] = fs.readFileSync('/tmp/wallet.json', 'utf8').trim().split('\n');
class CL { constructor(){ this.s = new Set(); } toggle(c,on){ on===undefined ? (this.s.has(c)?this.s.delete(c):this.s.add(c)) : (on?this.s.add(c):this.s.delete(c)); } add(c){this.s.add(c);} remove(c){this.s.delete(c);} contains(c){return this.s.has(c);} }
const els = {};
function El(id){ this.id=id; this.value=''; this.textContent=''; this.className=''; this.innerHTML=''; this.checked=false; this.classList=new CL(); }
const document = { getElementById: id => els[id] || (els[id] = new El(id)) };
const E = id => document.getElementById(id);
const calls = { toasts: [], core: [], timers: [] };
let lockStored = { enabled: false, pinLength: 4, biometricAvailable: true, biometricEnabled: false };
let TODAY = '2026-11-16';
const Core = {
  getState: () => stateJson, gcashGet: () => gcashJson,
  addMoney: (a, n, d) => { calls.core.push(['addMoney', a, n, d]); return Core._moneyId; }, _moneyId: 'tx_9',
  deleteMoney: id => { calls.core.push(['deleteMoney', id]); return Core._deleted; }, _deleted: 200,
  gcashAdd: (...a) => { calls.core.push(['gcashAdd', ...a]); return Core._gcId; }, _gcId: 'tx_20',
  gcashDelete: id => { calls.core.push(['gcashDelete', id]); return Core._gcDel; }, _gcDel: true,
  gcashClear: () => { calls.core.push(['gcashClear']); },
  getLockState: () => JSON.stringify(lockStored),
  enableLock: pin => { calls.core.push(['enableLock', pin]); if (Core._lockOk) { lockStored = { ...lockStored, enabled: true, pinLength: pin.length }; } return Core._lockOk; }, _lockOk: true,
  changePin: (o, n) => { calls.core.push(['changePin', o, n]); return Core._pinOk; }, _pinOk: true,
  disableLock: pin => { calls.core.push(['disableLock', pin]); if (Core._offOk) lockStored = { ...lockStored, enabled: false, biometricEnabled: false }; return Core._offOk; }, _offOk: true,
  setBiometric: on => { calls.core.push(['setBiometric', on]); if (Core._bioOk) lockStored.biometricEnabled = on; return Core._bioOk; }, _bioOk: true,
};
const appState = { allowance: 0, effective: 0, added: 0, topups: [], savingsGoal: 0, cycle: 'weekly', expenses: [] };
const api = new Function('document','Core','appState','calls','setTimeout','getTodayISO', `
  ${fmt}
  ${time12}
  ${shortDate}
  ${chips}
  const escapeHTML = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const openModal = id => document.getElementById(id).classList.remove('hidden'), closeModal = id => document.getElementById(id).classList.add('hidden');
  const showToast = (m, t) => calls.toasts.push([m, t || 'success']);
  const renderAll = () => { calls.core.push(['renderAll']); }, loadReminder = () => {}, renderReminder = () => {};
  ${syncFn}
  ${showTab}
  ${code}
  return { syncState, renderMoney, openMoney, setMoneyNote, updateMoneyPreview, submitMoney, deleteMoneyEntry,
           loadLock, renderLock, onEnableLock, onBiometricChange, onChangePin, onDisableLock,
           loadGcash, setGcType, setGcCategory, renderGcash, submitGcash, deleteGcashEntry, clearGcashTap, toggleGcashAll, showEstTab,
           GC_STYLE, getGc: () => gcState };
`)(document, Core, appState, calls, (fn, ms) => calls.timers.push([fn, ms]), () => TODAY);

let fails = 0;
const eq = (label, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); if (!ok) fails++; console.log((ok?'ok   ':'FAIL ')+label+(ok?'':`\n     got:  ${JSON.stringify(got)}\n     want: ${JSON.stringify(want)}`)); };
const has = (label, hay, needle) => { const ok = hay.includes(needle); if (!ok) fails++; console.log((ok?'ok   ':'FAIL ')+label+(ok?'':`\n     missing: ${needle}\n     in: ${hay.slice(0, 200)}`)); };
const last = () => calls.toasts[calls.toasts.length - 1];
const coreCalls = name => calls.core.filter(c => c[0] === name);

// ---------------------------------------------------------------- add money
api.syncState();
eq('base vs effective allowance after sync', [appState.allowance, appState.effective, appState.added, appState.topups.length], [1700, 1950.5, 250.5, 2]);
api.renderMoney();
eq('allowance card note', [E('statAddedNote').textContent, E('statAddedNote').classList.contains('hidden')], ['Includes ₱250.50 added', false]);
has('list: gift row', E('moneyList').innerHTML, 'Gift from Lola');
has('list: date and time', E('moneyList').innerHTML, 'Nov 15 · 10:20 AM');
has('list: amount', E('moneyList').innerHTML, '+₱200.00');
eq('list: total', E('moneyTotal').textContent, '+₱250.50');
api.openMoney();
eq('modal opens with a clean form', [E('moneyModal').classList.contains('hidden'), E('moneyAmount').value], [false, '']);
eq('preview with nothing typed', E('moneyPreview').textContent, 'Your allowance for this cycle is ₱1,950.50.');
E('moneyAmount').value = '100'; api.updateMoneyPreview();
eq('preview with an amount', E('moneyPreview').textContent, 'Allowance becomes ₱2,050.50 (₱1,950.50 + ₱100.00).');
api.setMoneyNote('Gift'); eq('note chip', E('moneyNote').value, 'Gift');
api.submitMoney();
eq('adds through the core with today\'s date', coreCalls('addMoney')[0], ['addMoney', 100, 'Gift', '2026-11-16']);
eq('success toast', last(), ['Added ₱100.00 to your allowance', 'success']);
eq('form cleared', [E('moneyAmount').value, E('moneyNote').value], ['', '']);
E('moneyAmount').value = ''; api.submitMoney();
eq('empty amount rejected', last(), ['Enter an amount greater than ₱0.', 'error']);
E('moneyAmount').value = '-5'; api.submitMoney();
eq('negative rejected without calling the core', [last()[1], coreCalls('addMoney').length], ['error', 1]);
Core._moneyId = ''; E('moneyAmount').value = '20'; api.submitMoney();
eq('core refusing is reported', last(), ['Enter an amount greater than ₱0.', 'error']);
api.deleteMoneyEntry('tx_1');
eq('delete', [coreCalls('deleteMoney')[0], last()], [['deleteMoney', 'tx_1'], ['Removed ₱200.00 from your allowance', 'info']]);
Core._deleted = -1; const n = calls.toasts.length; api.deleteMoneyEntry('nope');
eq('unknown id: no toast', calls.toasts.length, n);

// ---------------------------------------------------------------- GCash
api.loadGcash(); api.renderGcash();
eq('balance', E('gcBalance').textContent, '₱293.00');
eq('summary line', E('gcSummary').textContent, 'In ₱500.00 · Out ₱200.00 · Fees ₱7.00');
has('breakdown: food', E('gcBreakdown').innerHTML, '₱120.00 · 60%');
has('breakdown: load', E('gcBreakdown').innerHTML, '₱50.00 · 25%');
has('breakdown: other', E('gcBreakdown').innerHTML, '₱30.00 · 15%');
eq('breakdown hides empty categories', E('gcBreakdown').innerHTML.includes('Bills'), false);
has('history: cash in row', E('gcList').innerHTML, '+₱500.00');
has('history: fee shown', E('gcList').innerHTML, 'fee ₱5.00');
has('history: time shown', E('gcList').innerHTML, 'Nov 14 · 8:05 AM');
has('history: spending row', E('gcList').innerHTML, '-₱120.00');
has('history: notes are escaped', E('gcList').innerHTML, 'Tip &lt;b&gt;');
eq('every category the core sends has a style', JSON.parse(gcashJson).entries.every(e => api.GC_STYLE[e.category]) && JSON.parse(gcashJson).outCategories.every(c => api.GC_STYLE[c.name]), true);
eq('date defaults to today', E('gcDate').value, '2026-11-16');
eq('spent chips', E('gcCategories').innerHTML.match(/setGcCategory/g).length, 6);
api.setGcType('in');
eq('cash in chips', [E('gcCategories').innerHTML.match(/setGcCategory/g).length, E('gcSubmit').textContent], [3, 'Add cash in']);
has('cash in default chip highlighted', E('gcCategories').innerHTML, "setGcCategory('Cash in')\" class=\"" + 'px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors bg-brand-600 text-white');
api.setGcCategory('Received'); E('gcAmount').value = '100'; api.submitGcash();
eq('cash in goes to the core', coreCalls('gcashAdd')[0], ['gcashAdd', 'in', 100, 0, 'Received', '', '2026-11-16']);
eq('cash in toast', last(), ['Cash in ₱100.00 added to GCash', 'success']);
api.setGcType('out'); api.setGcCategory('Food');
E('gcAmount').value = '40'; E('gcFee').value = '2'; E('gcNote').value = 'Lunch'; api.submitGcash();
eq('spending goes to the core with fee and note', coreCalls('gcashAdd')[1], ['gcashAdd', 'out', 40, 2, 'Food', 'Lunch', '2026-11-16']);
eq('spending toast', calls.toasts.filter(t => t[0] === 'Spent ₱40.00 from GCash').length, 1);
eq('form cleared after adding', [E('gcAmount').value, E('gcFee').value, E('gcNote').value], ['', '', '']);
E('gcAmount').value = '500'; api.submitGcash();
eq('warns when spending more than the balance', last()[0].startsWith('That is more than your GCash balance'), true);
E('gcAmount').value = ''; api.submitGcash();
eq('empty amount rejected', last(), ['Enter an amount greater than ₱0.', 'error']);
Core._gcId = ''; E('gcAmount').value = '5'; api.submitGcash();
eq('core refusing is reported', last(), ['Enter an amount greater than ₱0.', 'error']);
api.deleteGcashEntry('tx_5');
eq('delete', [coreCalls('gcashDelete')[0], last()], [['gcashDelete', 'tx_5'], ['GCash record removed', 'info']]);
Core._gcDel = false; const m = calls.toasts.length; api.deleteGcashEntry('nope');
eq('unknown record: no toast', calls.toasts.length, m);
api.clearGcashTap();
eq('first tap asks to confirm', [E('gcClearBtn').textContent, coreCalls('gcashClear').length], ['Tap again to confirm', 0]);
api.clearGcashTap();
eq('second tap clears', [coreCalls('gcashClear').length, last()], [1, ['GCash records cleared.', 'info']]);
api.showEstTab('gcash');
eq('GCash tab', [E('estPanel').classList.contains('hidden'), E('estGcashPanel').classList.contains('hidden'), E('estHeadTitle').textContent], [true, false, 'GCash Track']);

// ---------------------------------------------------------------- app lock settings
api.showEstTab('lock');
eq('Lock tab', [E('estLockPanel').classList.contains('hidden'), E('estHeadTitle').textContent, E('estTabLock').className.includes('bg-brand-600')], [false, 'App Lock', true]);
eq('lock off: setup shown, manage hidden', [E('lockSetup').classList.contains('hidden'), E('lockManage').classList.contains('hidden'), E('lockStatusTitle').textContent], [false, true, 'App lock is off']);
eq('fingerprint row shown when the phone has one', E('lockBioRow').classList.contains('hidden'), false);
E('lockNewPin').value = '12'; E('lockConfirmPin').value = '12'; api.onEnableLock();
eq('short PIN rejected', [last(), coreCalls('enableLock').length], [['Your PIN must be 4 to 6 digits.', 'error'], 0]);
E('lockNewPin').value = '12a45'; E('lockConfirmPin').value = '12a45'; api.onEnableLock();
eq('letters rejected', last()[1], 'error');
E('lockNewPin').value = '1234'; E('lockConfirmPin').value = '1235'; api.onEnableLock();
eq('mismatch rejected', [last(), coreCalls('enableLock').length], [['The two PINs do not match.', 'error'], 0]);
Core._lockOk = false; E('lockConfirmPin').value = '1234'; api.onEnableLock();
eq('core refusing is reported', last(), ['Could not turn on the app lock.', 'error']);
Core._lockOk = true; api.onEnableLock();
eq('PIN sent to Android', coreCalls('enableLock').slice(-1)[0], ['enableLock', '1234']);
eq('inputs cleared, lock now on', [E('lockNewPin').value, E('lockStatusTitle').textContent, E('lockManage').classList.contains('hidden'), E('lockSetup').classList.contains('hidden')], ['', 'App lock is on', false, true]);
eq('status note mentions PIN length', E('lockStatusNote').textContent, 'Your 4-digit PIN is needed to open BaonTrack.');
eq('lock-on success toast', last()[0], 'App lock is on. Remember your PIN!');

E('lockBioToggle').checked = true; api.onBiometricChange();
eq('fingerprint on', [coreCalls('setBiometric').slice(-1)[0], lockStored.biometricEnabled, last()], [['setBiometric', true], true, ['Fingerprint unlock is on', 'info']]);
lockStored.biometricEnabled = false; Core._bioOk = false; E('lockBioToggle').checked = true; api.onBiometricChange();
eq('fingerprint refused: toggle resets and a toast explains', [E('lockBioToggle').checked, last()], [false, ['Fingerprint is not available on this phone.', 'error']]);
Core._bioOk = true; lockStored.biometricAvailable = false; api.showEstTab('lock');
eq('fingerprint row hidden when unavailable', E('lockBioRow').classList.contains('hidden'), true);

E('lockOldPin').value = '1234'; E('lockChangeNew').value = '56'; E('lockChangeConfirm').value = '56'; api.onChangePin();
eq('change: short new PIN rejected', last(), ['Your new PIN must be 4 to 6 digits.', 'error']);
E('lockChangeNew').value = '5678'; E('lockChangeConfirm').value = '5679'; api.onChangePin();
eq('change: mismatch rejected', last(), ['The two new PINs do not match.', 'error']);
Core._pinOk = false; E('lockChangeConfirm').value = '5678'; api.onChangePin();
eq('change: wrong current PIN', last(), ['Your current PIN is not right.', 'error']);
Core._pinOk = true; api.onChangePin();
eq('change: success', [coreCalls('changePin').slice(-1)[0], last()], [['changePin', '1234', '5678'], ['PIN changed', 'success']]);

Core._offOk = false; E('lockOffPin').value = '0000'; api.onDisableLock();
eq('turn off: wrong PIN', [last(), E('lockStatusTitle').textContent], [['That PIN is not right.', 'error'], 'App lock is on']);
Core._offOk = true; E('lockOffPin').value = '5678'; api.onDisableLock();
eq('turn off: right PIN', [coreCalls('disableLock').slice(-1)[0], E('lockStatusTitle').textContent, last()[0]], [['disableLock', '5678'], 'App lock is off', 'App lock turned off']);

console.log(fails ? `\n${fails} FAILED` : '\nALL WALLET/LOCK UI CHECKS PASSED');
process.exit(fails ? 1 : 0);
