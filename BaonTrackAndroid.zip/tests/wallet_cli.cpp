// Prints the core's state JSON (with top-ups) and GCash JSON for a fixed scenario, for the page tests.
#include <cstdio>
#include "../app/src/main/cpp/baon_core.h"
int main() {
    baon::Core c;
    c.setTodayOverride("2026-11-15"); c.setTimeOverride("10:20");
    c.setCycle("weekly"); c.setAllowance(1700); c.setSavingsGoal(1000);
    c.addMoney(200, "Gift from Lola", "2026-11-15");
    c.setTimeOverride("11:00"); c.addMoney(50.5, "Extra baon", "2026-11-15");
    c.setTimeOverride("08:05");
    c.gcashAdd("in", 500, 5, "Cash in", "7-Eleven cash in", "2026-11-14");
    c.setTimeOverride("13:45");
    c.gcashAdd("out", 120, 0, "Food", "Jollibee", "2026-11-14");
    c.gcashAdd("out", 50, 2, "Load", "Globe load", "2026-11-15");
    c.gcashAdd("out", 30, 0, "Other", "Tip <b>", "2026-11-15");
    std::printf("%s\n%s\n", c.stateJson().c_str(), c.gcashJson().c_str());
}
