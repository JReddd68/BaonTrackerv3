# BaonTrack — Android (NDK) project

The logic is C++; the screen is your existing HTML UI inside a WebView.

| Part | File |
|---|---|
| Allowance, savings, forecast, CSV, saving to disk (C++17) | `app/src/main/cpp/baon_core.cpp / .h` |
| JNI glue | `app/src/main/cpp/native_bridge.cpp` |
| NDK build script | `app/src/main/cpp/CMakeLists.txt` |
| Java shell (WebView, file picker, "save as") | `app/src/main/java/com/baontrack/app/` |
| UI | `app/src/main/assets/index.html` |

## Build the APK
1. Android Studio → **Open** → select this folder, let Gradle sync.
2. If asked, install **NDK (Side by side)** and **CMake 3.22.1** (Settings → SDK Manager → SDK Tools).
3. Phone: enable USB debugging and press **Run**. Or **Build → Build APK(s)**; the file is in `app/build/outputs/apk/debug/`.

## Notes
* Data is saved in the app's private storage (`baontrack_state.csv`) after every change.
* **Works offline.** Tailwind CSS, Chart.js, Font Awesome and the Inter font are packed inside the APK
  (`app/src/main/assets/vendor/`) and the app has no INTERNET permission. The folder is generated, not
  committed: `scripts/fetch-libs.sh` downloads the libraries from npm and builds `tailwind.css` from
  `index.html`. The GitHub Actions workflow runs it before `gradle assembleDebug`. For a build in
  Android Studio, run `bash scripts/fetch-libs.sh` once first (needs Node.js), and again after you add new
  Tailwind classes to `index.html`.
* **Icon and intro.** The launcher icon is the wallet artwork (`drawable/ic_launcher_*.xml` plus PNGs for
  Android 7.x). On start the app shows a purple intro: the system splash screen, then `MainActivity.startIntro()`
  snaps the wallet clasp shut and fades in the name, then fades out once the page has loaded.
  Timing constants are at the top of `MainActivity`.
* **Estimation.** Press and hold the wallet icon at the top left for about half a second. A what-if calculator opens:
  daily spend x number of days against a budget (for example ₱50 x 7 days = ₱350 of a ₱1,700 budget), how long the
  budget lasts, the weekly and 30-day totals, and a "daily limit finder" that turns a savings target into a
  maximum daily spend. Both parts can be applied as the real savings goal. The maths is `Core::estimateJson` in
  `baon_core.cpp`; nothing is saved unless you tap a "savings goal" button.
* Test the C++ core on a PC (no Android needed):
  `g++ -std=c++17 tests/test_csv.cpp app/src/main/cpp/baon_core.cpp -o t && ./t`
  (also `test_scenario.cpp` and `test_estimate.cpp`)

## Build in the cloud (no PC, no on-phone NDK)
Upload this project to a GitHub repo, open the **Actions** tab, run **Build APK**, then download
the `BaonTrack-debug-apk` artifact. The workflow is `.github/workflows/build.yml`.
