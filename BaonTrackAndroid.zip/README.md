# BaonTrack — Android (NDK) project

The logic is C++; the screen is your existing HTML UI inside a WebView.

| Part | File |
|---|---|
| Allowance, savings, forecast, CSV, saving to disk (C++17) | `app/src/main/cpp/baon_core.cpp / .h` |
| JNI glue | `app/src/main/cpp/native_bridge.cpp` |
| NDK build script | `app/src/main/cpp/CMakeLists.txt` |
| Java shell (WebView, file picker, "save as") | `app/src/main/java/com/baontrack/app/` |
| UI | `app/src/main/assets/index.html` |

## Build the APK
1. Android Studio → **Open** → select this folder, let Gradle sync.
2. If asked, install **NDK (Side by side)** and **CMake 3.22.1** (Settings → SDK Manager → SDK Tools).
3. Phone: enable USB debugging and press **Run**. Or **Build → Build APK(s)**; the file is in `app/build/outputs/apk/debug/`.

## Notes
* Data is saved in the app's private storage (`baontrack_state.csv`) after every change.
* Tailwind, Chart.js, Font Awesome and the Inter font are still loaded from CDNs, so the app needs
  internet. To go fully offline, download those files into `app/src/main/assets/` and change the
  `<script>`/`<link>` URLs at the top of `index.html` to the local file names.
* Test the C++ core on a PC (no Android needed):
  `g++ -std=c++17 tests/test_csv.cpp app/src/main/cpp/baon_core.cpp -o t && ./t`

## Build in the cloud (no PC, no on-phone NDK)
Upload this project to a GitHub repo, open the **Actions** tab, run **Build APK**, then download
the `BaonTrack-debug-apk` artifact. The workflow is `.github/workflows/build.yml`.
