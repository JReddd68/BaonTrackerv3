package com.baontrack.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Runs every morning (when "warn me before my cycle ends" is on) and warns 2 days before the end,
 * 1 day before, on the last day, and for 3 days after the cycle ended while it still waits to be archived.
 */
public class CycleAlertReceiver extends BroadcastReceiver {
    private static final int MAX_DAYS_OVER = 3;

    @Override
    public void onReceive(Context context, Intent intent) {
        NativeCore.init(new File(context.getFilesDir(), "baontrack_state.csv").getAbsolutePath());

        int days = 7, left = 7, over = 0;
        boolean started = false, ended = false;
        double safe = 0;
        try {
            JSONObject m = new JSONObject(NativeCore.getMetrics());
            started = m.optBoolean("cycleStarted", false);
            ended = m.optBoolean("cycleEnded", false);
            days = m.optInt("totalDaysInCycle", 7);
            left = m.optInt("cycleDaysLeft", days);
            over = m.optInt("cycleDaysOver", 0);
            safe = m.optDouble("safeDailySpend", 0);
        } catch (Exception ignored) { }
        if (!started) return;

        String title, text;
        if (ended) {
            if (over > MAX_DAYS_OVER) return;                        // stop nagging after a few days
            title = "Your cycle has ended";
            text = "Your " + days + "-day cycle is over. Open BaonTrack to archive it to Cycle History and set a new budget.";
        } else if (left == 0) {
            title = "Last day of your cycle";
            text = "Today is the last day of your " + days + "-day cycle. Make sure every expense is logged.";
        } else if (left == 1) {
            title = "Your cycle ends tomorrow";
            text = "1 day left in your " + days + "-day cycle. Safe to spend today: " + BaonWidgetProvider.money(safe) + ".";
        } else if (left == 2) {
            title = "2 days left in your cycle";
            text = "Your " + days + "-day cycle ends in 2 days. Safe to spend per day: " + BaonWidgetProvider.money(safe) + ".";
        } else {
            return;
        }

        // one warning per day, even if the alarm fires twice
        SharedPreferences prefs = ReminderScheduler.prefs(context);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        if (today.equals(prefs.getString("lastCycleAlert", ""))) return;
        prefs.edit().putString("lastCycleAlert", today).apply();

        Notifier.post(context, "baon_cycle", "Cycle alerts",
                "Warns you when your allowance cycle is about to end or has ended", 7002, title, text);
    }
}
