// Cycle countdown (auto-rollover) and the summary report.
#include <cassert>
#include <cstdio>
#include <string>
#include "../app/src/main/cpp/baon_core.h"
using baon::Core;
static bool has(const std::string& j, const std::string& piece) { return j.find(piece) != std::string::npos; }

int main() {
    Core c;
    c.setTodayOverride("2026-11-12");
    c.setCycle("weekly"); c.setAllowance(1700); c.setSavingsGoal(1000);

    // not started until the first expense
    std::string m = c.metricsJson();
    assert(has(m, "\"cycleStarted\":false") && has(m, "\"cycleDaysLeft\":7") && has(m, "\"cycleEnded\":false"));
    assert(has(c.summaryText(), "Cycle not started yet") && has(c.summaryText(), "No expenses logged"));

    c.setCategoryLimit("Food", 500);
    c.addExpense(300, "Food", "rice", "2026-11-09");          // the cycle starts on Mon Nov 9 ...
    c.addExpense(200, "Food", "lunch", "2026-11-10");
    c.addExpense(100, "School", "pen", "2026-11-12");
    c.addExpense(50, "Strolling", "snack", "2026-11-12");
    m = c.metricsJson();
    assert(has(m, "\"cycleStarted\":true") && has(m, "\"cycleStart\":\"2026-11-09\"") && has(m, "\"cycleEnd\":\"2026-11-15\""));
    assert(has(m, "\"cycleDay\":4") && has(m, "\"cycleDaysLeft\":3") && has(m, "\"cycleEnded\":false") && has(m, "\"cycleDaysOver\":0"));

    // ... and today is the last day
    c.setTodayOverride("2026-11-15");
    m = c.metricsJson();
    assert(has(m, "\"cycleDay\":7") && has(m, "\"cycleDaysLeft\":0") && has(m, "\"cycleEnded\":false"));

    // Day 8: the cycle has ended
    c.setTodayOverride("2026-11-16");
    m = c.metricsJson();
    assert(has(m, "\"cycleDay\":8") && has(m, "\"cycleDaysLeft\":-1") && has(m, "\"cycleEnded\":true") && has(m, "\"cycleDaysOver\":1"));
    c.setTodayOverride("2026-11-19");
    assert(has(c.metricsJson(), "\"cycleDaysOver\":4"));

    // a monthly cycle across a month and year boundary
    c.setCycle("monthly");
    c.setTodayOverride("2026-12-05");
    m = c.metricsJson();
    assert(has(m, "\"cycleEnd\":\"2026-12-08\"") && has(m, "\"cycleDay\":27") && has(m, "\"cycleDaysLeft\":3"));
    c.setTodayOverride("2026-12-09");
    assert(has(c.metricsJson(), "\"cycleEnded\":true"));

    // starting a new cycle resets the countdown
    c.setCycle("weekly"); c.setTodayOverride("2026-11-16");
    assert(c.newCycle());
    m = c.metricsJson();
    assert(has(m, "\"cycleStarted\":false") && has(m, "\"cycleDaysLeft\":7") && has(m, "\"cycleEnded\":false"));
    c.addExpense(10, "Food", "x", "2026-12-30");
    assert(has(c.metricsJson(), "\"cycleEnd\":\"2027-01-05\""));       // year change

    // ---------------- summary report
    Core s;
    s.setTodayOverride("2026-11-12");
    s.setCycle("weekly"); s.setAllowance(1700); s.setSavingsGoal(1000); s.setCategoryLimit("Food", 500);
    s.addExpense(300, "Food", "rice", "2026-11-09");
    s.addExpense(200, "Food", "lunch", "2026-11-10");
    s.addExpense(100, "School", "pen", "2026-11-12");
    s.addExpense(50, "Strolling", "snack", "2026-11-12");
    const std::string t = s.summaryText();
    std::puts(t.c_str());
    assert(has(t, "BAONTRACK SUMMARY\nWeekly cycle (7 days) · Nov 9 – Nov 15, 2026\nDay 4 of 7 · 3 days left"));
    assert(has(t, "Allowance: \xE2\x82\xB1" "1,700.00") && has(t, "Total spent: \xE2\x82\xB1" "650.00 (38.2% of allowance)"));
    assert(has(t, "Remaining: \xE2\x82\xB1" "1,050.00"));
    assert(has(t, "Savings goal: \xE2\x82\xB1" "1,000.00 · on track (\xE2\x82\xB1" "50.00 above the goal)"));
    assert(has(t, "Savings rate: 61.8% of your allowance is still unspent"));
    assert(has(t, "Biggest category: Food — \xE2\x82\xB1" "500.00 (76.9% of spending)"));
    assert(has(t, "- Food: \xE2\x82\xB1" "500.00 (76.9%) · limit \xE2\x82\xB1" "500.00, 100% used"));
    assert(has(t, "- School: \xE2\x82\xB1" "100.00 (15.4%)") && has(t, "- Strolling: \xE2\x82\xB1" "50.00 (7.7%)"));
    assert(!has(t, "- Personal"));                                         // nothing spent, no limit: left out
    assert(has(t, "Transactions: 4 · average \xE2\x82\xB1" "162.50 per entry · \xE2\x82\xB1" "162.50 per day"));
    assert(has(t, "Safe to spend today: "));

    s.setTodayOverride("2026-11-16");                                       // ended
    assert(has(s.summaryText(), "Cycle ended 1 day ago"));
    s.setTodayOverride("2026-11-15");
    assert(has(s.summaryText(), "Day 7 of 7 · last day"));
    s.addExpense(2000, "Personal", "phone", "2026-11-15");                  // overspent
    const std::string over = s.summaryText();
    assert(has(over, "Overspent by: \xE2\x82\xB1" "950.00") && has(over, "short by \xE2\x82\xB1" "1,950.00"));
    assert(!has(over, "Savings rate"));
    std::puts("CYCLE TESTS PASSED");
}
