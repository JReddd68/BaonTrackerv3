package com.baontrack.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.File;
import java.util.Locale;

/** Home screen widget: today's safe spending, what is left, and how much of the allowance is used. */
public class BaonWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        RemoteViews views = build(context);
        for (int id : appWidgetIds) manager.updateAppWidget(id, views);
    }

    /** Called whenever the data changes so the widget never shows old numbers. */
    static void refresh(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, BaonWidgetProvider.class));
            if (ids == null || ids.length == 0) return;
            RemoteViews views = build(context);
            for (int id : ids) manager.updateAppWidget(id, views);
        } catch (Exception ignored) { }
    }

    /** 1,234.5 -> "₱1,234.50" (negative amounts keep their minus sign in front). */
    static String money(double v) {
        String body = String.format(Locale.US, "\u20B1%,.2f", Math.abs(v));
        return v < 0 && Math.abs(v) >= 0.005 ? "-" + body : body;
    }

    private static RemoteViews build(Context context) {
        NativeCore.init(new File(context.getFilesDir(), "baontrack_state.csv").getAbsolutePath());
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_baon);
        PendingIntent openApp = PendingIntent.getActivity(context, 0, new Intent(context, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.wgRoot, openApp);

        if (AppLock.isEnabled(context)) {   // with the app lock on, no money amounts on the home screen
            views.setTextViewText(R.id.wgLabel, "BaonTrack");
            views.setTextViewText(R.id.wgValue, "Locked");
            views.setTextViewText(R.id.wgDetail, "Tap to unlock");
            views.setTextViewText(R.id.wgFoot, "");
            views.setProgressBar(R.id.wgBar, 100, 0, false);
            return views;
        }

        double safe = 0, remaining = 0, allowance = 0, percentUsed = 0;
        int daysLeft = 0;
        boolean ended = false;
        try {
            JSONObject m = new JSONObject(NativeCore.getMetrics());
            safe = m.optDouble("safeDailySpend", 0);
            remaining = m.optDouble("remaining", 0);
            allowance = m.optDouble("allowance", 0);
            percentUsed = m.optDouble("percentUsed", 0);
            daysLeft = m.optInt("remainingDays", 0);
            ended = m.optBoolean("cycleEnded", false);
        } catch (Exception ignored) { }

        if (allowance <= 0) {
            views.setTextViewText(R.id.wgLabel, "BaonTrack");
            views.setTextViewText(R.id.wgValue, "Set up");
            views.setTextViewText(R.id.wgDetail, "Tap to set your allowance");
            views.setTextViewText(R.id.wgFoot, "");
            views.setProgressBar(R.id.wgBar, 100, 0, false);
        } else {
            int used = (int) Math.max(0, Math.min(100, Math.round(percentUsed)));
            views.setTextViewText(R.id.wgLabel, "Safe to spend today");
            views.setTextViewText(R.id.wgValue, money(safe));
            views.setTextViewText(R.id.wgDetail, money(remaining) + " left of " + money(allowance));
            views.setTextViewText(R.id.wgFoot, ended
                    ? "Cycle ended \u00B7 tap to archive it"
                    : used + "% used \u00B7 " + daysLeft + (daysLeft == 1 ? " day left" : " days left"));
            views.setProgressBar(R.id.wgBar, 100, used, false);
        }

        return views;
    }
}
