// "Add money" (top-ups that raise the allowance) and the separate GCash tracker.
#include <cassert>
#include <cmath>
#include <cstdio>
#include <string>
#include "../app/src/main/cpp/baon_core.h"
using baon::Core;
static bool has(const std::string& j, const std::string& piece) { return j.find(piece) != std::string::npos; }
static const char* kFile = "/tmp/baon_wallet_state.csv";

int main() {
    std::remove(kFile);
    std::string moneyId, gcId;
    {
        Core c; c.init(kFile); c.setTodayOverride("2026-11-15"); c.setTimeOverride("10:20");
        c.setCycle("weekly"); c.setAllowance(1700); c.setSavingsGoal(1000);
        auto m = c.metrics();
        assert(std::fabs(m.safeDailySpend - 100) < 0.01 && m.allowance == 1700);

        // ------------------------------------------------ add money
        assert(c.addMoney(0, "x", "").empty() && c.addMoney(-5, "x", "").empty() && c.addMoney(NAN, "x", "").empty());
        moneyId = c.addMoney(200, "Gift from Lola", "2026-11-15");
        assert(!moneyId.empty());
        m = c.metrics();
        assert(m.allowance == 1900 && std::fabs(m.safeDailySpend - 900.0 / 7) < 0.01);   // more to spend per day
        std::string st = c.stateJson();
        assert(has(st, "\"allowance\":1700.00") && has(st, "\"effectiveAllowance\":1900.00") && has(st, "\"added\":200.00"));
        assert(has(st, "\"note\":\"Gift from Lola\"") && has(st, "\"time\":\"10:20\""));
        c.setTimeOverride("11:00");
        auto id2 = c.addMoney(50.5, "", "bad-date");                                       // bad date -> today
        st = c.stateJson();
        assert(has(st, "\"added\":250.50") && has(st, "\"effectiveAllowance\":1950.50"));
        assert(st.find("Gift from Lola") > st.find("\"amount\":50.50"));                  // newest first
        assert(c.deleteMoney(id2) == 50.5 && c.deleteMoney("nope") < 0);

        c.addExpense(190, "Food", "lunch", "2026-11-15");
        m = c.metrics();
        assert(std::fabs(m.percentUsed - 10.0) < 0.001 && std::fabs(m.remaining - 1710) < 0.01);
        assert(has(c.summaryText(), "Allowance: \xE2\x82\xB1" "1,900.00 (\xE2\x82\xB1" "1,700.00 + \xE2\x82\xB1" "200.00 added)"));

        // ------------------------------------------------ GCash
        assert(has(c.gcashJson(), "\"balance\":0.00") && has(c.gcashJson(), "\"entries\":[]"));
        assert(c.gcashAdd("transfer", 10, 0, "", "", "").empty() && c.gcashAdd("in", 0, 0, "", "", "").empty());
        assert(c.gcashAdd("out", -3, 0, "", "", "").empty());
        gcId = c.gcashAdd("in", 500, 5, "Cash in", "7-Eleven cash in", "2026-11-14");
        assert(!gcId.empty());
        c.gcashAdd("out", 120, 0, "food", "Jollibee", "2026-11-14");
        c.setTimeOverride("12:30");
        c.gcashAdd("out", 50, 2, "LOAD", "", "2026-11-15");                                 // note defaults to the category
        c.gcashAdd("out", 30, 0, "Gadgets", "mystery", "2026-11-15");                       // unknown category -> Other
        c.gcashAdd("in", 100, 0, "Salary", "", "2026-11-15");                               // unknown cash-in category
        std::string g = c.gcashJson();
        assert(has(g, "\"balance\":393.00"));            // 500+100 in; 120+50+30 out; 5+2 fees
        assert(has(g, "\"totalIn\":600.00") && has(g, "\"totalOut\":200.00") && has(g, "\"totalFees\":7.00") && has(g, "\"count\":5"));
        assert(has(g, "{\"name\":\"Food\",\"spent\":120.00,\"count\":1,\"percent\":60.0000}"));
        assert(has(g, "{\"name\":\"Load\",\"spent\":50.00,\"count\":1,\"percent\":25.0000}"));
        assert(has(g, "{\"name\":\"Other\",\"spent\":30.00,\"count\":1,\"percent\":15.0000}"));
        assert(has(g, "\"note\":\"Load\"") && has(g, "\"category\":\"Cash in\",\"note\":\"Cash in\""));
        assert(g.find("Salary") == std::string::npos);
        assert(g.find("\"note\":\"Cash in\"") < g.find("7-Eleven cash in"));                // newest first
        assert(c.gcashDelete(gcId) && !c.gcashDelete(gcId));                                // 7-Eleven cash in removed
        assert(has(c.gcashJson(), "\"balance\":-102.00"));                                   // 100 - 200 - 2 fee (a negative balance is allowed)
        c.gcashAdd("in", 500, 5, "Cash in", "7-Eleven cash in", "2026-11-14");
    }
    {   // ------------------------------------------------ both survive a restart
        Core c; c.init(kFile); c.setTodayOverride("2026-11-15");
        std::string st = c.stateJson();
        assert(has(st, "\"added\":200.00") && has(st, "Gift from Lola"));
        std::string g = c.gcashJson();
        assert(has(g, "\"balance\":393.00") && has(g, "\"fee\":5.00") && has(g, "\"time\":\"12:30\""));

        const std::string csv = c.exportCsv(false);
        assert(has(csv, "MONEY ADDED") && has(csv, "Date,Time,Amount,Note") && has(csv, "GCASH"));
        assert(has(csv, "Date,Time,Type,Category,Description,Amount,Fee"));

        // ------------------------------------------------ new cycle: top-ups go into the history, then reset
        assert(c.newCycle());
        assert(has(c.historyJson(), "\"allowance\":1900.00,\"added\":200.00"));
        assert(has(c.stateJson(), "\"added\":0.00") && has(c.stateJson(), "\"effectiveAllowance\":1700.00"));
        assert(has(c.gcashJson(), "\"balance\":393.00"));                                    // GCash is not touched
        c.addMoney(75, "bonus", "2026-11-16");
        assert(has(c.exportCsv(false), "Added"));

        // top-ups survive "clear all entries" but not "reset everything"
        c.clearExpenses();
        assert(has(c.stateJson(), "\"added\":75.00"));
        c.resetAll();
        assert(has(c.stateJson(), "\"added\":0.00") && has(c.gcashJson(), "\"balance\":393.00"));
    }
    {   // ------------------------------------------------ history keeps "added" after a restart
        Core c; c.init(kFile);
        assert(has(c.historyJson(), "\"added\":200.00") && has(c.gcashJson(), "\"count\":5"));

        // restoring: GCash is only replaced by a file that has it
        auto r = c.importCsv("BAONTRACK SUMMARY,VALUE\nCycle,Weekly (7d)\nAllowance,1000\nSavings Goal,0\n\nDate,Category,Description,Amount\n2026-11-20,Food,Rice,50\n");
        assert(r.ok && has(c.gcashJson(), "\"count\":5") && has(c.stateJson(), "\"added\":0.00"));
        auto r2 = c.importCsv("GCASH,\nDate,Time,Type,Category,Description,Amount,Fee\n2026-11-01,09:15,in,Received,\"Allowance, from mom\",1000,0\n2026-11-02,,out,Bills,Water bill,350.5,15\n2026-11-03,,sideways,Food,bad,10,0\n2026-11-04,,out,Food,bad amount,abc,0\n");
        assert(r2.ok && r2.hasMetadata && r2.imported == 0);
        std::string g = c.gcashJson();
        assert(has(g, "\"count\":2") && has(g, "\"balance\":634.50") && has(g, "Allowance, from mom") && has(g, "\"time\":\"09:15\""));
        assert(has(g, "\"category\":\"Bills\"") && has(g, "\"fee\":15.00"));
        c.gcashClear();
        assert(has(c.gcashJson(), "\"entries\":[]"));

        // full backup round trip: top-ups, GCash and history all come back
        Core a; a.setTodayOverride("2026-11-15"); a.setTimeOverride("08:00");
        a.setAllowance(900); a.addMoney(100, "gift", "2026-11-15"); a.gcashAdd("in", 300, 3, "Cash in", "x", "2026-11-15");
        a.addExpense(10, "Food", "snack", "2026-11-15"); a.newCycle(); a.addMoney(40, "again", "2026-11-15");
        const std::string backup = a.exportCsv(true);
        Core b; b.setTodayOverride("2026-11-15");
        auto r3 = b.importCsv(backup);
        assert(r3.ok && has(b.stateJson(), "\"added\":40.00") && has(b.stateJson(), "\"effectiveAllowance\":940.00"));
        assert(has(b.gcashJson(), "\"balance\":297.00") && has(b.historyJson(), "\"allowance\":1000.00,\"added\":100.00"));
    }
    std::puts("WALLET TESTS PASSED");
}
