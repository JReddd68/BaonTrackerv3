// Estimation screen: checks the numbers from the feature request (50 pesos x 7 days, budget 1700).
#include <cassert>
#include <cstdio>
#include <string>
#include "../app/src/main/cpp/baon_core.h"
using baon::Core;
static bool has(const std::string& j, const std::string& piece) { return j.find(piece) != std::string::npos; }
int main() {
    std::string j = Core::estimateJson(50, 7, 1700, -1);
    assert(has(j, "\"total\":350.00") && has(j, "\"left\":1350.00") && has(j, "\"over\":false"));
    assert(has(j, "\"lastsDays\":34") && has(j, "\"weekTotal\":350.00") && has(j, "\"monthTotal\":1500.00"));
    assert(has(j, "\"hasTarget\":false"));

    j = Core::estimateJson(300, 7, 1700, -1);                       // 2100 > 1700 -> over budget
    assert(has(j, "\"over\":true") && has(j, "\"overBy\":400.00") && has(j, "\"maxDailyInBudget\":242.86"));

    j = Core::estimateJson(0, 7, 1700, -1);                         // nothing entered yet
    assert(has(j, "\"total\":0.00") && has(j, "\"lastsDays\":-1") && has(j, "\"left\":1700.00"));

    j = Core::estimateJson(50, 30, 1700, 500);                      // reverse: save 500 over 30 days
    assert(has(j, "\"targetOk\":true") && has(j, "\"maxTotalForTarget\":1200.00") && has(j, "\"maxDailyForTarget\":40.00"));
    assert(has(j, "\"warn60\":false"));
    j = Core::estimateJson(50, 7, 1700, 1100);                      // 64.7% of the budget -> hunger warning
    assert(has(j, "\"warn60\":true") && has(j, "\"targetOk\":true"));
    j = Core::estimateJson(50, 7, 1700, 2000);                      // more than the budget
    assert(has(j, "\"targetOk\":false") && has(j, "\"maxDailyForTarget\":0.00"));

    j = Core::estimateJson(-5, 0, -1, 0 / 0.0);                     // garbage in, safe numbers out
    assert(has(j, "\"days\":1") && has(j, "\"total\":0.00") && has(j, "\"hasTarget\":false"));
    j = Core::estimateJson(10, 100000, 100, -1);                    // days are clamped to 365
    assert(has(j, "\"days\":365"));
    std::puts("ESTIMATE TESTS PASSED");
}
