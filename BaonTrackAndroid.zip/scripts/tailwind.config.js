// Same settings the page used to pass to the Tailwind CDN script (tailwind.config = {...}).
const path = require('path');

module.exports = {
  // Every class name in the page (including the ones built inside its JavaScript) is written out in full,
  // so scanning index.html is enough to generate all the CSS the app needs.
  content: [path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html')],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        brand: {
          50: '#eef2ff',
          100: '#e0e7ff',
          500: '#6366f1',
          600: '#4f46e5',
          700: '#4338ca',
          900: '#312e81',
        },
      },
    },
  },
};
