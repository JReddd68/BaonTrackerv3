# BaonTrack — Android (NDK) project

The logic is C++; the screen is your existing HTML UI inside a WebView.

| Part | File |
|---|---|
| Allowance, savings, forecast, CSV, saving to disk (C++17) | `app/src/main/cpp/baon_core.cpp / .h` |
| JNI glue | `app/src/main/cpp/native_bridge.cpp` |
| NDK build script | `app/src/main/cpp/CMakeLists.txt` |
| Java shell (WebView, file picker, "save as") | `app/src/main/java/com/baontrack/app/` |
| UI | `app/src/main/assets/index.html` |

## Build the APK
1. Android Studio → **Open** → select this folder, let Gradle sync.
2. If asked, install **NDK (Side by side)** and **CMake 3.22.1** (Settings → SDK Manager → SDK Tools).
3. Phone: enable USB debugging and press **Run**. Or **Build → Build APK(s)**; the file is in `app/build/outputs/apk/debug/`.

## Notes
* Data is saved in the app's private storage (`baontrack_state.csv`) after every change.
* **Works offline.** Tailwind CSS, Chart.js, Font Awesome and the Inter font are packed inside the APK
  (`app/src/main/assets/vendor/`) and the app has no INTERNET permission. The folder is generated, not
  committed: `scripts/fetch-libs.sh` downloads the libraries from npm and builds `tailwind.css` from
  `index.html`. The GitHub Actions workflow runs it before `gradle assembleDebug`. For a build in
  Android Studio, run `bash scripts/fetch-libs.sh` once first (needs Node.js), and again after you add new
  Tailwind classes to `index.html`.
* **Icon and intro.** The launcher icon is the wallet artwork (`drawable/ic_launcher_*.xml` plus PNGs for
  Android 7.x). On start the app shows a purple intro: the system splash screen, then `MainActivity.startIntro()`
  snaps the wallet clasp shut and fades in the name, then fades out once the page has loaded.
  Timing constants are at the top of `MainActivity`.
* **Estimation.** Press and hold the wallet icon at the top left for about half a second. A what-if calculator opens:
  daily spend x number of days against a budget (for example ₱50 x 7 days = ₱350 of a ₱1,700 budget), how long the
  budget lasts, the weekly and 30-day totals, and a "daily limit finder" that turns a savings target into a
  maximum daily spend. Both parts can be applied as the real savings goal. The maths is `Core::estimateJson` in
  `baon_core.cpp`; nothing is saved unless you tap a "savings goal" button.
* **Category limits.** The *Limits* button on the Category Breakdown card sets a cap per category for one cycle.
  Each category shows its limit bar; you get a warning at 80% and again past 100%.
* **Cycle history.** Tapping *New Cycle* first saves the finished week or month (dates, spent, saved, goal met or
  missed, spending per category, change versus the cycle before). The list is at the bottom of the page; it is kept
  in the same saved file and in CSV exports (the `CYCLE HISTORY` block), up to 100 cycles.
* **Log time.** Every expense remembers the time it was logged (phone clock) and shows it in the history list and the
  CSV (`Time` column). Older entries and CSV files without a time still import fine.
* **Daily reminder (hidden).** Press and hold the wallet icon, then open the *Reminder* tab, turn it on and choose a time. The alarm is set in
  `ReminderScheduler`, the notification is built in `ReminderReceiver` (skipped if you already logged today), and
  `BootReceiver` sets it up again after a restart. Android 13+ asks for notification permission the first time.
  The alarm is inexact on purpose (no special permission), so Android may deliver it a few minutes late.
* **Hidden panel.** Press and hold the wallet icon: *Estimation*, *GCash*, *Reminder*, *Lock* and *About* tabs. About holds
  the widget tip and the app info that used to sit in the footer.
* **Add money.** The *Add money* button on the Total Allowance card logs a gift or top-up in the middle of a cycle. It raises
  the allowance for every calculation (daily limit, forecast, percent used, widget, summary); the allowance you type in
  stays the base. The amounts are kept with the cycle in Cycle History ("incl. ₱X added") and start from zero in the new cycle.
  Top-ups can be removed from the same window. Core: `addMoney`, `deleteMoney`, `effectiveAllowance()` in `baon_core.cpp`.
* **GCash Track** (hidden panel). The digital-cash version of the tracker: a balance, *Cash in* and *Spent* entries with an
  optional fee, spending by category (Food, Load, Bills, Shopping, Transfer, Other), a history with delete, and a
  two-tap "Clear records". It is separate from the allowance. Saved with everything else and included in CSV backups (the
  `GCASH` block); restoring a CSV that has no GCash block leaves your GCash records alone.
* **App Lock** (hidden panel, *Lock* tab). Turn it on with a 4 to 6 digit PIN; optionally unlock with your fingerprint
  (Android 9+ with an enrolled fingerprint). The lock screen is native (`MainActivity`, `AppLock`): the PIN is stored only
  as a salted PBKDF2 hash, 5 wrong tries wait 30 seconds, the screen is covered as soon as you leave the app (so the
  recent-apps preview shows nothing), and the PIN is asked again after more than 15 seconds away. With the lock on, the
  widget and the notifications hide your amounts. There is no PIN recovery: clearing the app data in Android Settings
  is the only way back in and it erases the records, so export a CSV backup first. Turning the lock off needs the PIN.
* **Status bar.** The page reports its theme to Android (`setSystemBars`), so the status bar and navigation bar turn black
  with white icons in dark mode and white with dark icons in light mode.
* **Home screen widget.** Touch and hold the home screen, choose Widgets, then BaonTrack. It shows today's safe
  spend, what is left and how much is used, and refreshes whenever data changes (`BaonWidgetProvider`).
* **Cycle countdown and Auto-Cycle Rollover.** The card at the top counts the days left in the cycle (7 or 30). A
  cycle starts on the date of its earliest expense, so the countdown matches the daily-spend maths. After the last
  day, opening (or coming back to) the app shows the *Smart Prompt*: archive the finished cycle to Cycle History and
  start a new budget (your allowance and savings goal are filled in, so it is one tap). *Not yet* is for late
  receipts and asks again the next day. Nothing is archived without your tap.
* **Cycle warnings.** Turn on *Warn me before my cycle ends* in the Reminder tab (press and hold the wallet icon). `CycleAlertReceiver` checks every
  morning at 8:00 and notifies 2 days before the end, 1 day before, on the last day, and for 3 days after the end
  while the cycle is still waiting to be archived (one warning per day).
* **Summary report.** The *Summary* button shows the current cycle as plain text (spent, remaining, savings goal and
  rate, biggest category, per-category totals with limits, averages, safe spend) and copies it to the clipboard.
* Test the C++ core on a PC (no Android needed):
  `g++ -std=c++17 tests/test_csv.cpp app/src/main/cpp/baon_core.cpp -o t && ./t`
  (also `test_scenario.cpp`, `test_estimate.cpp`, `test_features.cpp` and `test_wallet.cpp`; the page scripts are tested with
  `node tests/estimate_ui_test.js`, `features_ui_test.js`, `cycle_ui_test.js`, `about_ui_test.js` and `wallet_ui_test.js` after
  building `estimate_cli`, `features_cli`, `cycle_cli` and `wallet_cli` into `/tmp` (see the top of each test); also
  `test_cycle.cpp`)

## Build in the cloud (no PC, no on-phone NDK)
Upload this project to a GitHub repo, open the **Actions** tab, run **Build APK**, then download
the `BaonTrack-debug-apk` artifact. The workflow is `.github/workflows/build.yml`.
