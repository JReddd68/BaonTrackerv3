package com.baontrack.app;

import java.nio.charset.StandardCharsets;

/** Thin Java wrapper over the C++ core (libbaoncore.so). All logic lives in C++. */
final class NativeCore {
    static {
        System.loadLibrary("baoncore");
    }

    private NativeCore() {}

    private static native void nativeInit(byte[] path);
    private static native byte[] nativeGetState();
    private static native byte[] nativeGetMetrics();
    private static native boolean nativeSetAllowance(double v);
    private static native boolean nativeSetSavingsGoal(double v);
    private static native void nativeSetCycle(byte[] cycle);
    private static native byte[] nativeAddExpense(double amount, byte[] category, byte[] note, byte[] date);
    private static native double nativeDeleteExpense(byte[] id);
    private static native int nativeClearExpenses();
    private static native void nativeResetAll();
    private static native boolean nativeSetCategoryLimit(byte[] category, double amount);
    private static native byte[] nativeGetCategories();
    private static native boolean nativeNewCycle();
    private static native byte[] nativeGetHistory();
    private static native void nativeClearHistory();
    private static native byte[] nativeGetSummary();
    private static native byte[] nativeEstimate(double dailySpend, int days, double budget, double saveTarget);
    private static native byte[] nativeExportCsv();
    private static native byte[] nativeImportCsv(byte[] csv);

    private static byte[] b(String s) { return (s == null ? "" : s).getBytes(StandardCharsets.UTF_8); }
    private static String s(byte[] b) { return b == null ? "" : new String(b, StandardCharsets.UTF_8); }

    static void init(String path) { nativeInit(b(path)); }
    static String getState() { return s(nativeGetState()); }
    static String getMetrics() { return s(nativeGetMetrics()); }
    static boolean setAllowance(double v) { return nativeSetAllowance(v); }
    static boolean setSavingsGoal(double v) { return nativeSetSavingsGoal(v); }
    static void setCycle(String c) { nativeSetCycle(b(c)); }
    static String addExpense(double a, String cat, String note, String date) {
        return s(nativeAddExpense(a, b(cat), b(note), b(date)));
    }
    static double deleteExpense(String id) { return nativeDeleteExpense(b(id)); }
    static int clearExpenses() { return nativeClearExpenses(); }
    static void resetAll() { nativeResetAll(); }
    static String estimate(double dailySpend, int days, double budget, double saveTarget) {
        return s(nativeEstimate(dailySpend, days, budget, saveTarget));
    }
    static boolean setCategoryLimit(String category, double amount) { return nativeSetCategoryLimit(b(category), amount); }
    static String getCategories() { return s(nativeGetCategories()); }
    static boolean newCycle() { return nativeNewCycle(); }
    static String getHistory() { return s(nativeGetHistory()); }
    static void clearHistory() { nativeClearHistory(); }
    static String getSummary() { return s(nativeGetSummary()); }
    static byte[] exportCsvBytes() { return nativeExportCsv(); }
    static String importCsv(byte[] csv) { return s(nativeImportCsv(csv)); }
}
