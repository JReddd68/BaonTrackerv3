package com.baontrack.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

import java.io.File;

/** Runs when the daily alarm fires and shows the "log today's expenses" reminder. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        show(context, false);
    }

    /** force = true is used by the "Send test" button: it shows the notification even if you already logged today. */
    static void show(Context context, boolean force) {
        NativeCore.init(new File(context.getFilesDir(), "baontrack_state.csv").getAbsolutePath());

        double safe = 0, allowance = 0;
        boolean loggedToday = false;
        try {
            JSONObject m = new JSONObject(NativeCore.getMetrics());
            safe = m.optDouble("safeDailySpend", 0);
            allowance = m.optDouble("allowance", 0);
            loggedToday = m.optBoolean("loggedToday", false);
        } catch (Exception ignored) { }

        if (loggedToday && !force) return;                          // already logged something today: no nagging

        String text = allowance > 0
                ? "Did you log today's expenses? Safe to spend today: " + BaonWidgetProvider.money(safe)
                : "Don't forget to log today's expenses.";
        Notifier.post(context, "baon_reminder", "Daily reminder", "Reminds you to log today's expenses",
                7001, "BaonTrack", text);
    }
}
