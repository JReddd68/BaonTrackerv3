// Host-side test driver. Reads scenario lines from stdin:
//   cycle allowance savings today date:amount,date:amount,...
// and prints the metrics JSON for each, so it can be diffed against the original JS.
#include <cstdio>
#include <iostream>
#include <sstream>
#include "../app/src/main/cpp/baon_core.h"

int main() {
    std::string line;
    while (std::getline(std::cin, line)) {
        std::istringstream ss(line);
        std::string cycle, today, items;
        double allow, save;
        ss >> cycle >> allow >> save >> today >> items;
        baon::Core c;
        c.setTodayOverride(today);
        c.setCycle(cycle);
        c.setAllowance(allow);
        c.setSavingsGoal(save);
        std::stringstream is(items);
        std::string tok;
        while (items != "-" && std::getline(is, tok, ',')) {
            auto p = tok.find(':');
            c.addExpense(std::stod(tok.substr(p + 1)), "Food", "t", tok.substr(0, p));
        }
        std::cout << c.metricsJson() << "\n";
    }
}
