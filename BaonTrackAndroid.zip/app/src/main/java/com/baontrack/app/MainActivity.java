package com.baontrack.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Hosts the BaonTrack UI (assets/index.html) in a WebView. Every calculation,
 * the CSV logic and the saved data live in the C++ core, reached through the
 * "BaonNative" JavaScript interface.
 */
public class MainActivity extends Activity {
    private static final int REQ_PICK_CSV = 1001;
    private static final int REQ_SAVE_CSV = 1002;
    private static final int MAX_CSV_BYTES = 5 * 1024 * 1024;

    // Opening animation timing
    private static final long INTRO_MIN_MS = 1700;   // shortest time the intro stays up
    private static final long INTRO_MAX_MS = 5000;   // never keep the user waiting longer than this
    private static final float WALLET_DP = 288f;     // size of the wallet canvases (see ic_wallet_*.xml)
    private static final float CLASP_EDGE_X_DP = 200f;   // right edge of the clasp inside that canvas
    private static final float CLASP_CENTER_Y_DP = 153.4f;

    private WebView webView;
    private FrameLayout root;
    private View introView;
    private boolean pageReady, introMinElapsed;
    private int origStatusBar, origNavBar;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile byte[] pendingExport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeCore.init(new File(getFilesDir(), "baontrack_state.csv").getAbsolutePath());

        webView = new WebView(this);
        if (systemIsDark()) webView.setBackgroundColor(0xFF0B1220);  // no white flash while the page loads
        root = new FrameLayout(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);          // we only load our own packaged asset
        ws.setAllowContentAccess(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                finishIntroWhenReady();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "BaonNative");

        // Play the intro on a fresh launch only (not when Android restores the activity,
        // and not when the user has turned animations off).
        boolean animationsOn = Settings.Global.getFloat(
                getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f;
        if (savedInstanceState == null && animationsOn) startIntro();
        else applyAppWindowBackground();

        webView.loadUrl("file:///android_asset/index.html");
    }

    // ------------------------------------------------------------------ opening animation

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    /**
     * Purple intro drawn over the WebView. It starts as the same picture the system shows while the app
     * launches (purple screen + wallet), then the clasp snaps shut, the wallet bounces and the name fades in.
     * It fades out once the page has loaded and the animation has had time to play.
     */
    private void startIntro() {
        introView = getLayoutInflater().inflate(R.layout.intro_overlay, root, false);
        root.addView(introView);

        Window w = getWindow();
        origStatusBar = w.getStatusBarColor();
        origNavBar = w.getNavigationBarColor();
        int purple = getColor(R.color.splash_bg);
        w.setStatusBarColor(purple);
        w.setNavigationBarColor(purple);

        View wallet = introView.findViewById(R.id.introWallet);
        View clasp = introView.findViewById(R.id.introClasp);
        View title = introView.findViewById(R.id.introTitle);
        View tagline = introView.findViewById(R.id.introTagline);

        // Start state: empty wallet (what the splash shows), clasp folded away, texts hidden.
        clasp.setPivotX(dp(CLASP_EDGE_X_DP));
        clasp.setPivotY(dp(CLASP_CENTER_Y_DP));
        clasp.setScaleX(0f);
        clasp.setAlpha(0f);
        title.setAlpha(0f);
        title.setTranslationY(title.getTranslationY() + dp(16));
        tagline.setAlpha(0f);
        tagline.setTranslationY(tagline.getTranslationY() + dp(16));

        // 1. clasp snaps out of the right edge
        clasp.animate().setStartDelay(250).setDuration(450).scaleX(1f).alpha(1f)
                .setInterpolator(new OvershootInterpolator(2.4f)).start();

        // 2. whole wallet gives a little bounce as it closes
        wallet.setPivotX(dp(WALLET_DP) / 2f);
        wallet.setPivotY(dp(WALLET_DP) / 2f);
        wallet.animate().setStartDelay(560).setDuration(150).scaleX(1.07f).scaleY(1.07f)
                .withEndAction(() -> wallet.animate().setStartDelay(0).setDuration(320)
                        .scaleX(1f).scaleY(1f).setInterpolator(new OvershootInterpolator(3f)).start())
                .start();

        // 3. name and tagline rise in
        title.animate().setStartDelay(550).setDuration(450).alpha(1f)
                .translationY(title.getTranslationY() - dp(16))
                .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        tagline.animate().setStartDelay(720).setDuration(450).alpha(1f)
                .translationY(tagline.getTranslationY() - dp(16))
                .setInterpolator(new DecelerateInterpolator(1.6f)).start();

        handler.postDelayed(() -> { introMinElapsed = true; finishIntroWhenReady(); }, INTRO_MIN_MS);
        handler.postDelayed(this::dismissIntro, INTRO_MAX_MS);   // safety net
    }

    private void finishIntroWhenReady() {
        if (pageReady && introMinElapsed) dismissIntro();
    }

    private void dismissIntro() {
        final View intro = introView;
        if (intro == null) return;
        introView = null;
        intro.animate().setStartDelay(0).setDuration(380).alpha(0f).scaleX(1.08f).scaleY(1.08f)
                .setInterpolator(new AccelerateInterpolator(1.2f))
                .withEndAction(() -> {
                    root.removeView(intro);
                    Window w = getWindow();
                    w.setStatusBarColor(origStatusBar);
                    w.setNavigationBarColor(origNavBar);
                    applyAppWindowBackground();
                }).start();
        // bring the bars back to normal while the purple fades out
        getWindow().setStatusBarColor(origStatusBar);
        getWindow().setNavigationBarColor(origNavBar);
    }

    /** The launch theme paints a purple window background; swap it for the page colour once we are running. */
    private void applyAppWindowBackground() {
        getWindow().setBackgroundDrawable(new ColorDrawable(systemIsDark() ? 0xFF0B1220 : 0xFFF8FAFC));
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.removeJavascriptInterface("BaonNative");
            webView.destroy();
        }
        super.onDestroy();
    }

    private boolean systemIsDark() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    private void js(final String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    /** Methods here are called from JavaScript on a background thread. */
    public final class Bridge {
        @JavascriptInterface public boolean isSystemDark() { return systemIsDark(); }
        @JavascriptInterface public String getState() { return NativeCore.getState(); }
        @JavascriptInterface public String getMetrics() { return NativeCore.getMetrics(); }
        @JavascriptInterface public boolean setAllowance(double v) { return NativeCore.setAllowance(v); }
        @JavascriptInterface public boolean setSavingsGoal(double v) { return NativeCore.setSavingsGoal(v); }
        @JavascriptInterface public void setCycle(String c) { NativeCore.setCycle(c); }
        @JavascriptInterface public String addExpense(double a, String cat, String note, String date) {
            return NativeCore.addExpense(a, cat, note, date);
        }
        @JavascriptInterface public double deleteExpense(String id) { return NativeCore.deleteExpense(id); }
        @JavascriptInterface public int clearExpenses() { return NativeCore.clearExpenses(); }
        @JavascriptInterface public void resetAll() { NativeCore.resetAll(); }
        @JavascriptInterface public String estimate(double dailySpend, int days, double budget, double saveTarget) {
            return NativeCore.estimate(dailySpend, days, budget, saveTarget);
        }

        @JavascriptInterface
        public void exportCsv(final String filename) {
            pendingExport = NativeCore.exportCsvBytes();
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/csv");
                i.putExtra(Intent.EXTRA_TITLE, filename);
                startActivityForResult(i, REQ_SAVE_CSV);
            });
        }

        @JavascriptInterface
        public void pickCsv() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "text/csv", "text/comma-separated-values", "text/plain",
                        "application/vnd.ms-excel", "application/octet-stream"});
                startActivityForResult(Intent.createChooser(i, "Choose a CSV file"), REQ_PICK_CSV);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        final Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;

        if (requestCode == REQ_SAVE_CSV) {
            boolean ok = false;
            if (uri != null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) { out.write(pendingExport); ok = true; }
                } catch (Exception ignored) { }
            }
            pendingExport = null;
            js("window.onNativeSaved && window.onNativeSaved(" + ok + ")");
        } else if (requestCode == REQ_PICK_CSV) {
            if (uri == null) return;  // user cancelled
            String result;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int n;
                while (in != null && (n = in.read(chunk)) != -1) {
                    buf.write(chunk, 0, n);
                    if (buf.size() > MAX_CSV_BYTES) throw new IllegalStateException("too big");
                }
                result = NativeCore.importCsv(buf.toByteArray());
            } catch (Exception e) {
                result = "{\"ok\":false,\"imported\":0,\"hasMetadata\":false,\"error\":\"Unable to read the selected CSV file.\"}";
            }
            js("window.onNativeImport && window.onNativeImport(" + result + ")");
        }
    }
}
