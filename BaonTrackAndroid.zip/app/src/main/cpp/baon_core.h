// BaonTrack core: allowance / savings / expense logic in portable C++17.
// No Android headers here, so it also builds and tests on a PC.
#pragma once
#include <mutex>
#include <string>
#include <vector>

namespace baon {

struct Expense {
    std::string id;
    std::string note;
    std::string category;  // Food | School | Personal | Strolling
    std::string date;      // YYYY-MM-DD
    double amount = 0.0;
};

struct Metrics {
    int totalDaysInCycle = 7;
    double totalSpent = 0, remaining = 0, percentUsed = 0;
    int activeDays = 1, remainingDays = 0;
    double dailyAverage = 0, paceDaily = 0, txAverage = 0;
    bool hasEnoughHistory = false;
    double projectedEndBalance = 0, safeDailySpend = 0, targetDailyBudget = 0;
    double savingsGoal = 0, maxAllowedSpending = 0, safeSpendRemaining = 0;
    double savingsPercentOfAllowance = 0;
};

struct ImportResult {
    bool ok = false;
    int imported = 0;
    bool hasMetadata = false;
    std::string error;
};

class Core {
public:
    // Loads saved data (if any) from storagePath; every change is saved back to it.
    void init(const std::string& storagePath);
    void setTodayOverride(const std::string& iso);  // for tests only

    std::string stateJson() const;
    std::string metricsJson() const;
    Metrics metrics() const;

    bool setAllowance(double v);
    bool setSavingsGoal(double v);
    void setCycle(const std::string& cycle);  // "weekly" | "monthly"

    // Returns the new expense id, or "" if the amount is invalid.
    std::string addExpense(double amount, const std::string& category,
                           const std::string& note, const std::string& date);
    // Returns the refunded amount, or -1 if the id was not found.
    double deleteExpense(const std::string& id);
    int clearExpenses();
    void resetAll();

    // What-if calculator behind the "Estimation" screen. Pure maths: it never reads or changes saved data.
    //   dailySpend  money spent per day          days        number of days (clamped to 1..365)
    //   budget      money available              saveTarget  amount to save, or a negative number for "none"
    static std::string estimateJson(double dailySpend, int days, double budget, double saveTarget);

    std::string exportCsv(bool withBom) const;
    ImportResult importCsv(const std::string& text);
    static std::string importResultJson(const ImportResult& r);

private:
    mutable std::mutex mu_;
    double allowance_ = 0, savingsGoal_ = 0;
    std::string cycle_ = "weekly";
    std::vector<Expense> expenses_;
    std::string path_, todayOverride_;
    unsigned long nextId_ = 1;

    std::string today() const;
    Metrics computeLocked() const;
    std::string exportLocked(bool withBom) const;
    ImportResult importLocked(const std::string& text);
    std::string newId();
    void saveLocked() const;
};

}  // namespace baon
