// Category limits, cycle history, log time and the reminder/widget fields.
#include <cassert>
#include <cstdio>
#include <string>
#include "../app/src/main/cpp/baon_core.h"
using baon::Core;
static bool has(const std::string& j, const std::string& piece) { return j.find(piece) != std::string::npos; }
static const char* kFile = "/tmp/baon_features_state.csv";

int main() {
    std::remove(kFile);
    {
        Core c; c.init(kFile); c.setTodayOverride("2026-11-15"); c.setTimeOverride("14:35");
        c.setCycle("weekly"); c.setAllowance(1700); c.setSavingsGoal(1000);

        // ---------- log time
        auto id = c.addExpense(100, "Food", "lunch", "2026-11-15");
        assert(!id.empty() && has(c.stateJson(), "\"time\":\"14:35\""));
        auto m = c.metrics();
        assert(m.loggedToday && m.allowance == 1700);
        c.deleteExpense(id);
        assert(!c.metrics().loggedToday);

        // ---------- category limits
        assert(c.setCategoryLimit("food", 500) && !c.setCategoryLimit("Snacks", 100) && !c.setCategoryLimit("Food", -1));
        assert(has(c.categoriesJson(), "\"name\":\"Food\",\"spent\":0.00,\"count\":0,\"limit\":500.00"));
        assert(has(c.categoriesJson(), "\"name\":\"School\"") && has(c.categoriesJson(), "\"status\":\"none\""));
        c.addExpense(300, "Food", "a", "2026-11-15");
        assert(has(c.categoriesJson(), "\"percent\":60.0000") && has(c.categoriesJson(), "\"status\":\"ok\""));
        c.addExpense(100, "Food", "b", "2026-11-15");                       // 400 / 500 = 80%
        assert(has(c.categoriesJson(), "\"status\":\"warn\""));
        c.addExpense(150, "Food", "c", "2026-11-14");                       // 550 / 500 = 110%
        assert(has(c.categoriesJson(), "\"status\":\"over\"") && has(c.categoriesJson(), "\"remaining\":-50.00"));
        c.addExpense(80, "School", "pen", "2026-11-12");
        c.addExpense(40, "Strolling", "ice cream", "2026-11-13");
    }
    {   // ---------- everything survives a restart
        Core c; c.init(kFile); c.setTodayOverride("2026-11-15");
        assert(has(c.categoriesJson(), "\"limit\":500.00") && has(c.stateJson(), "\"time\":\"14:35\""));
        const std::string csv = c.exportCsv(false);
        assert(has(csv, "Limit Food,500.00") && has(csv, "Date,Category,Description,Amount,Time"));

        // ---------- cycle history
        assert(c.newCycle());                                               // 670 spent, 5 expenses
        std::string h = c.historyJson();
        assert(has(h, "\"start\":\"2026-11-12\"") && has(h, "\"end\":\"2026-11-15\"") && has(h, "\"spent\":670.00"));
        assert(has(h, "\"saved\":1030.00") && has(h, "\"goalMet\":true") && has(h, "\"count\":5"));
        assert(has(h, "\"Food\":550.00") && has(h, "\"School\":80.00") && has(h, "\"Strolling\":40.00"));
        assert(has(h, "\"days\":4") && has(h, "\"hasPrev\":false"));
        assert(has(c.stateJson(), "\"expenses\":[]"));
        assert(has(c.categoriesJson(), "\"limit\":500.00"));                // limits carry over to the new cycle
        assert(!c.newCycle());                                              // nothing to archive
        assert(c.historyJson().find("\"start\"", c.historyJson().find("\"start\"") + 1) == std::string::npos);

        // second cycle: spend more -> delta against the first
        c.setTodayOverride("2026-11-22");
        c.addExpense(800, "Personal", "shoes", "2026-11-20");
        assert(c.newCycle());
        h = c.historyJson();
        assert(has(h, "\"spent\":800.00") && has(h, "\"hasPrev\":true") && has(h, "\"deltaSpent\":130.00"));
        assert(has(h, "\"goalMet\":false"));                                // saved 900 < goal 1000
        assert(h.find("2026-11-20") < h.find("2026-11-12"));                // newest first
    }
    {   // ---------- history + limits are in the saved file and come back after a restart
        Core c; c.init(kFile);
        assert(has(c.historyJson(), "\"spent\":670.00") && has(c.historyJson(), "\"spent\":800.00"));
        assert(has(c.categoriesJson(), "\"limit\":500.00"));
        const std::string backup = c.exportCsv(true);
        assert(has(backup, "CYCLE HISTORY") && has(backup, "Start,End,Cycle,Allowance"));

        // restoring an old-style file (no history/limit rows, no time column) keeps history and clears limits
        auto r = c.importCsv("BAONTRACK SUMMARY,VALUE\nCycle,Weekly (7d)\nAllowance,1000\nSavings Goal,0\n\nDate,Category,Description,Amount\n2026-11-20,Food,Rice,50\n");
        assert(r.ok && r.imported == 1);
        assert(has(c.historyJson(), "\"spent\":800.00"));
        assert(has(c.categoriesJson(), "\"limit\":0.00") && !has(c.categoriesJson(), "\"limit\":500.00"));
        assert(has(c.stateJson(), "\"time\":\"\""));                        // old entry: no time

        // restoring a full backup brings back limits and history, with times
        auto r2 = c.importCsv(backup);
        assert(r2.ok && has(c.categoriesJson(), "\"limit\":500.00") && has(c.historyJson(), "\"spent\":670.00"));
        c.clearHistory();
        assert(has(c.historyJson(), "\"cycles\":[]"));
        c.resetAll();
        assert(has(c.categoriesJson(), "\"limit\":500.00") == false);
    }
    {   // ---------- history is capped
        Core c; c.setTodayOverride("2026-11-15");
        for (int i = 0; i < baon::kMaxHistory + 5; i++) { c.addExpense(i + 1, "Food", "x", "2026-11-15"); c.newCycle(); }
        const std::string h = c.historyJson();
        size_t n = 0, pos = 0;
        while ((pos = h.find("\"start\"", pos)) != std::string::npos) { n++; pos++; }
        assert(n == static_cast<size_t>(baon::kMaxHistory));
        assert(has(h, "\"spent\":105.00") && !has(h, "\"spent\":1.00,"));    // oldest were dropped
    }
    std::puts("FEATURE TESTS PASSED");
}
