#include "baon_core.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iterator>
#include <sstream>

namespace baon {
namespace {

const char* kPeso = "\xE2\x82\xB1";  // UTF-8 for the peso sign

bool isDigit(char c) { return c >= '0' && c <= '9'; }

int daysInMonth(int y, int m) {
    static const int d[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (m == 2) return ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) ? 29 : 28;
    return d[m - 1];
}

// "HH:MM" on a 24-hour clock
bool isValidTime(const std::string& s) {
    if (s.size() != 5 || s[2] != ':') return false;
    for (int i : {0, 1, 3, 4})
        if (!isDigit(s[i])) return false;
    return std::atoi(s.substr(0, 2).c_str()) < 24 && std::atoi(s.substr(3, 2).c_str()) < 60;
}

bool parseIso(const std::string& s, int& y, int& m, int& d) {
    if (s.size() != 10 || s[4] != '-' || s[7] != '-') return false;
    const int digitPos[] = {0, 1, 2, 3, 5, 6, 8, 9};
    for (int i : digitPos)
        if (!isDigit(s[i])) return false;
    y = std::atoi(s.substr(0, 4).c_str());
    m = std::atoi(s.substr(5, 2).c_str());
    d = std::atoi(s.substr(8, 2).c_str());
    return m >= 1 && m <= 12 && d >= 1 && d <= daysInMonth(y, m);
}

// Days since 1970-01-01 (Howard Hinnant's civil-date algorithm).
long long daysFromCivil(int y, int m, int d) {
    y -= m <= 2;
    const long long era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = static_cast<unsigned>(y - era * 400);
    const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + static_cast<long long>(doe) - 719468;
}

// Days since 1970-01-01 -> "YYYY-MM-DD" (Howard Hinnant's civil-from-days algorithm).
std::string daysToIso(long long z) {
    z += 719468;
    const long long era = (z >= 0 ? z : z - 146096) / 146097;
    const unsigned doe = static_cast<unsigned>(z - era * 146097);
    const unsigned yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    long long y = static_cast<long long>(yoe) + era * 400;
    const unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    const unsigned mp = (5 * doy + 2) / 153;
    const unsigned d = doy - (153 * mp + 2) / 5 + 1;
    const unsigned m = mp < 10 ? mp + 3 : mp - 9;
    y += (m <= 2);
    char buf[40];
    std::snprintf(buf, sizeof buf, "%04lld-%02u-%02u", y, m, d);
    return buf;
}

bool isoToDays(const std::string& iso, long long& out) {
    int y, m, d;
    if (!parseIso(iso, y, m, d)) return false;
    out = daysFromCivil(y, m, d);
    return true;
}

std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && (s[a] == ' ' || s[a] == '\t' || s[a] == '\r' || s[a] == '\n')) a++;
    while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t' || s[b - 1] == '\r' || s[b - 1] == '\n')) b--;
    return s.substr(a, b - a);
}

std::string lower(std::string s) {
    for (char& c : s)
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
    return s;
}

std::string truncateUtf8(const std::string& s, size_t maxCodePoints) {
    size_t count = 0;
    for (size_t i = 0; i < s.size(); i++) {
        if ((static_cast<unsigned char>(s[i]) & 0xC0) != 0x80) {
            if (count == maxCodePoints) return s.substr(0, i);
            count++;
        }
    }
    return s;
}

std::string cleanNote(const std::string& raw) {
    std::string s = raw;
    for (char& c : s)
        if (c == '\r' || c == '\n') c = ' ';
    return truncateUtf8(trim(s), 60);
}

std::string normalizeCategory(const std::string& raw) {
    const std::string c = lower(trim(raw));
    if (c == "food") return "Food";
    if (c == "school") return "School";
    if (c == "personal") return "Personal";
    if (c == "strolling") return "Strolling";
    return "Personal";
}

const char* const kCategoryNames[kCategoryCount] = {"Food", "School", "Personal", "Strolling"};

// -1 when the name is not one of the four categories (case-insensitive, no guessing)
int categoryIndex(const std::string& raw) {
    const std::string c = lower(trim(raw));
    for (int i = 0; i < kCategoryCount; i++)
        if (c == lower(kCategoryNames[i])) return i;
    return -1;
}

const char* const kMonthNames[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

// "2026-11-15" -> "Nov 15" or "Nov 15, 2026"
std::string prettyDate(const std::string& iso, bool withYear) {
    int y, m, d;
    if (!parseIso(iso, y, m, d)) return iso;
    std::string s = std::string(kMonthNames[m - 1]) + " " + std::to_string(d);
    return withYear ? s + ", " + std::to_string(y) : s;
}

// 1234.5 -> "₱1,234.50" (a minus sign goes in front of the peso sign)
std::string peso(double v) {
    const bool negative = v < -0.004;
    const long long cents = std::llround(std::fabs(v) * 100.0);
    std::string whole = std::to_string(cents / 100);
    for (int i = static_cast<int>(whole.size()) - 3; i > 0; i -= 3) whole.insert(static_cast<size_t>(i), ",");
    char frac[8];
    std::snprintf(frac, sizeof frac, ".%02lld", cents % 100);
    return std::string(negative ? "-" : "") + kPeso + whole + frac;
}

std::string plural(long long n, const char* word) {
    return std::to_string(n) + " " + word + (n == 1 ? "" : "s");
}

const char* const kGcashOutNames[kGcashOutCount] = {"Food", "Load", "Bills", "Shopping", "Transfer", "Other"};
const char* const kGcashInNames[kGcashInCount] = {"Cash in", "Received", "Opening balance"};

std::string gcashCategory(bool isIn, const std::string& raw) {
    const std::string c = lower(trim(raw));
    if (isIn) {
        for (const char* n : kGcashInNames) if (c == lower(n)) return n;
        return "Cash in";
    }
    for (const char* n : kGcashOutNames) if (c == lower(n)) return n;
    return "Other";
}

double round2(double v) { return std::isfinite(v) ? std::round(v * 100.0) / 100.0 : 0.0; }

// Same behaviour as JavaScript parseFloat(): longest numeric prefix, otherwise NaN.
double jsParseFloat(const std::string& in) {
    const std::string s = trim(in);
    size_t i = 0;
    if (i < s.size() && (s[i] == '+' || s[i] == '-')) i++;
    size_t digitsStart = i;
    while (i < s.size() && isDigit(s[i])) i++;
    size_t intDigits = i - digitsStart;
    size_t fracDigits = 0;
    if (i < s.size() && s[i] == '.') {
        size_t j = i + 1;
        while (j < s.size() && isDigit(s[j])) j++;
        fracDigits = j - (i + 1);
        if (intDigits > 0 || fracDigits > 0) i = j;
    }
    if (intDigits == 0 && fracDigits == 0) return std::nan("");
    if (i < s.size() && (s[i] == 'e' || s[i] == 'E')) {
        size_t j = i + 1;
        if (j < s.size() && (s[j] == '+' || s[j] == '-')) j++;
        size_t expStart = j;
        while (j < s.size() && isDigit(s[j])) j++;
        if (j > expStart) i = j;
    }
    return std::strtod(s.substr(0, i).c_str(), nullptr);
}

// Strip commas and the peso sign, then parse (mirrors .replace(/[₱,]/g, '')).
double parseMoney(const std::string& in) {
    std::string out;
    const std::string peso = kPeso;
    for (size_t i = 0; i < in.size();) {
        if (in.compare(i, peso.size(), peso) == 0) { i += peso.size(); continue; }
        if (in[i] == ',') { i++; continue; }
        out += in[i++];
    }
    return jsParseFloat(out);
}

std::vector<std::string> parseCsvLine(const std::string& line) {
    std::vector<std::string> result;
    std::string cur;
    bool inQuotes = false;
    for (size_t i = 0; i < line.size(); i++) {
        const char c = line[i];
        if (c == '"') {
            if (inQuotes && i + 1 < line.size() && line[i + 1] == '"') { cur += '"'; i++; }
            else inQuotes = !inQuotes;
        } else if (c == ',' && !inQuotes) {
            result.push_back(trim(cur));
            cur.clear();
        } else {
            cur += c;
        }
    }
    result.push_back(trim(cur));
    return result;
}

std::string csvField(const std::string& v) {
    if (v.find_first_of("\",\r\n") == std::string::npos) return v;
    std::string out = "\"";
    for (char c : v) {
        if (c == '"') out += "\"\"";
        else out += c;
    }
    return out + "\"";
}

std::string jsonEscape(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof buf, "\\u%04x", c);
                    out += buf;
                } else {
                    out += static_cast<char>(c);
                }
        }
    }
    return out;
}

std::string num(double v, int decimals = 2) {
    if (!std::isfinite(v)) v = 0;
    char buf[64];
    std::snprintf(buf, sizeof buf, "%.*f", decimals, v);
    return buf;
}

}  // namespace

// ---------------------------------------------------------------- helpers

std::string Core::today() const {
    if (!todayOverride_.empty()) return todayOverride_;
    std::time_t t = std::time(nullptr);
    std::tm lt{};
    localtime_r(&t, &lt);
    char buf[40];
    std::snprintf(buf, sizeof buf, "%04d-%02d-%02d", lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday);
    return buf;
}

std::string Core::nowTime() const {
    if (!timeOverride_.empty()) return timeOverride_;
    std::time_t t = std::time(nullptr);
    std::tm lt{};
    localtime_r(&t, &lt);
    char buf[16];
    std::snprintf(buf, sizeof buf, "%02d:%02d", lt.tm_hour, lt.tm_min);
    return buf;
}

void Core::setTimeOverride(const std::string& hhmm) {
    std::lock_guard<std::mutex> lk(mu_);
    timeOverride_ = hhmm;
}

std::string Core::newId() { return "tx_" + std::to_string(nextId_++); }

void Core::setTodayOverride(const std::string& iso) {
    std::lock_guard<std::mutex> lk(mu_);
    todayOverride_ = iso;
}

// ------------------------------------------------------------- persistence

void Core::init(const std::string& storagePath) {
    std::lock_guard<std::mutex> lk(mu_);
    if (initialized_) return;   // the app, the reminder and the widget may all call this in one process
    initialized_ = true;
    path_ = storagePath;
    std::ifstream in(path_, std::ios::binary);
    if (!in) return;  // first launch: stay at zero
    std::string text((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    importLocked(text);
}

void Core::saveLocked() const {
    if (path_.empty()) return;
    const std::string tmp = path_ + ".tmp";
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out) return;
        out << exportLocked(false);
        if (!out) return;
    }
    std::rename(tmp.c_str(), path_.c_str());
}

// ------------------------------------------------------------------ metrics

Metrics Core::computeLocked() const {
    Metrics m;
    m.totalDaysInCycle = (cycle_ == "weekly") ? 7 : 30;
    for (const auto& e : expenses_) m.totalSpent += e.amount;
    const double eff = effectiveAllowance();   // allowance + money added this cycle
    m.remaining = eff - m.totalSpent;
    m.percentUsed = eff > 0 ? (m.totalSpent / eff) * 100.0 : (m.totalSpent > 0 ? 100.0 : 0.0);

    m.savingsGoal = std::max(0.0, savingsGoal_);
    m.maxAllowedSpending = eff - m.savingsGoal;
    m.safeSpendRemaining = m.maxAllowedSpending - m.totalSpent;
    m.savingsPercentOfAllowance = eff > 0 ? (m.savingsGoal / eff) * 100.0
                                          : (m.savingsGoal > 0 ? 100.0 : 0.0);

    // The cycle only "starts" once the first expense is logged. Before that no day has been
    // used up, so the whole cycle is still ahead (e.g. 700 / 7 days = 100 per day, not 700 / 6).
    m.activeDays = 0;
    if (!expenses_.empty()) {
        m.activeDays = 1;
        long long todayDay = 0;
        isoToDays(today(), todayDay);
        long long minDay = 0;
        bool have = false;
        for (const auto& e : expenses_) {
            long long d;
            if (!isoToDays(e.date, d)) continue;
            if (!have || d < minDay) { minDay = d; have = true; }
        }
        if (have) {
            const long long diff = todayDay - minDay + 1;
            m.activeDays = static_cast<int>(std::min<long long>(m.totalDaysInCycle, std::max<long long>(1, diff)));
        }
    }

    const bool any = !expenses_.empty();
    m.dailyAverage = any ? m.totalSpent / std::max(1, m.activeDays) : 0.0;
    m.txAverage = any ? m.totalSpent / static_cast<double>(expenses_.size()) : 0.0;
    m.remainingDays = std::max(0, m.totalDaysInCycle - m.activeDays);

    m.targetDailyBudget = std::max(0.0, m.maxAllowedSpending) / m.totalDaysInCycle;
    m.hasEnoughHistory = m.activeDays >= 3;

    const double pool = m.savingsGoal > 0 ? m.safeSpendRemaining : m.remaining;
    m.safeDailySpend = pool > 0 ? pool / std::max(1, m.remainingDays) : 0.0;

    m.paceDaily = m.hasEnoughHistory ? m.dailyAverage : std::min(m.targetDailyBudget, m.safeDailySpend);
    m.projectedEndBalance = m.remaining - m.paceDaily * m.remainingDays;

    // calendar countdown (aligned with activeDays: the cycle starts at the earliest expense)
    m.cycleDaysLeft = m.totalDaysInCycle;
    if (!expenses_.empty()) {
        std::string first = expenses_[0].date;
        for (const auto& e : expenses_)
            if (e.date < first) first = e.date;
        long long startDay = 0, todayDay = 0;
        if (isoToDays(first, startDay) && isoToDays(today(), todayDay)) {
            m.cycleStarted = true;
            m.cycleStart = first;
            m.cycleEnd = daysToIso(startDay + m.totalDaysInCycle - 1);
            m.cycleDay = static_cast<int>(std::max<long long>(1, todayDay - startDay + 1));
            m.cycleDaysLeft = m.totalDaysInCycle - m.cycleDay;
            m.cycleEnded = m.cycleDay > m.totalDaysInCycle;
            m.cycleDaysOver = m.cycleEnded ? m.cycleDay - m.totalDaysInCycle : 0;
        }
    }

    m.allowance = eff;
    const std::string t = today();
    for (const auto& e : expenses_)
        if (e.date == t) { m.loggedToday = true; break; }
    return m;
}

Metrics Core::metrics() const {
    std::lock_guard<std::mutex> lk(mu_);
    return computeLocked();
}

std::string Core::metricsJson() const {
    const Metrics m = metrics();
    std::ostringstream o;
    o << "{\"totalDaysInCycle\":" << m.totalDaysInCycle
      << ",\"totalSpent\":" << num(m.totalSpent)
      << ",\"remaining\":" << num(m.remaining)
      << ",\"percentUsed\":" << num(m.percentUsed, 6)
      << ",\"activeDays\":" << m.activeDays
      << ",\"remainingDays\":" << m.remainingDays
      << ",\"dailyAverage\":" << num(m.dailyAverage, 6)
      << ",\"paceDaily\":" << num(m.paceDaily, 6)
      << ",\"hasEnoughHistory\":" << (m.hasEnoughHistory ? "true" : "false")
      << ",\"txAverage\":" << num(m.txAverage, 6)
      << ",\"projectedEndBalance\":" << num(m.projectedEndBalance, 6)
      << ",\"safeDailySpend\":" << num(m.safeDailySpend, 6)
      << ",\"targetDailyBudget\":" << num(m.targetDailyBudget, 6)
      << ",\"savingsGoal\":" << num(m.savingsGoal)
      << ",\"maxAllowedSpending\":" << num(m.maxAllowedSpending)
      << ",\"safeSpendRemaining\":" << num(m.safeSpendRemaining)
      << ",\"savingsPercentOfAllowance\":" << num(m.savingsPercentOfAllowance, 6)
      << ",\"allowance\":" << num(m.allowance)
      << ",\"loggedToday\":" << (m.loggedToday ? "true" : "false")
      << ",\"cycleStarted\":" << (m.cycleStarted ? "true" : "false")
      << ",\"cycleStart\":\"" << m.cycleStart << "\",\"cycleEnd\":\"" << m.cycleEnd << "\""
      << ",\"cycleDay\":" << m.cycleDay << ",\"cycleDaysLeft\":" << m.cycleDaysLeft
      << ",\"cycleEnded\":" << (m.cycleEnded ? "true" : "false")
      << ",\"cycleDaysOver\":" << m.cycleDaysOver << "}";
    return o.str();
}

std::string Core::stateJson() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::ostringstream o;
    o << "{\"allowance\":" << num(allowance_) << ",\"effectiveAllowance\":" << num(effectiveAllowance())
      << ",\"added\":" << num(topupTotal()) << ",\"savingsGoal\":" << num(savingsGoal_)
      << ",\"cycle\":\"" << cycle_ << "\",\"expenses\":[";
    for (size_t i = 0; i < expenses_.size(); i++) {
        const auto& e = expenses_[i];
        if (i) o << ",";
        o << "{\"id\":\"" << jsonEscape(e.id) << "\",\"note\":\"" << jsonEscape(e.note)
          << "\",\"amount\":" << num(e.amount) << ",\"category\":\"" << jsonEscape(e.category)
          << "\",\"date\":\"" << jsonEscape(e.date) << "\",\"time\":\"" << jsonEscape(e.time) << "\"}";
    }
    o << "],\"topups\":[";
    for (size_t i = 0; i < topups_.size(); i++) {
        const auto& t = topups_[i];
        if (i) o << ",";
        o << "{\"id\":\"" << jsonEscape(t.id) << "\",\"note\":\"" << jsonEscape(t.note)
          << "\",\"amount\":" << num(t.amount) << ",\"date\":\"" << jsonEscape(t.date)
          << "\",\"time\":\"" << jsonEscape(t.time) << "\"}";
    }
    o << "]}";
    return o.str();
}

// ---------------------------------------------------------------- mutations

bool Core::setAllowance(double v) {
    if (!std::isfinite(v) || v < 0) return false;
    std::lock_guard<std::mutex> lk(mu_);
    allowance_ = std::round(v * 100.0) / 100.0;
    saveLocked();
    return true;
}

bool Core::setSavingsGoal(double v) {
    if (!std::isfinite(v) || v < 0) return false;
    std::lock_guard<std::mutex> lk(mu_);
    savingsGoal_ = std::round(v * 100.0) / 100.0;
    saveLocked();
    return true;
}

void Core::setCycle(const std::string& cycle) {
    std::lock_guard<std::mutex> lk(mu_);
    cycle_ = (cycle == "monthly") ? "monthly" : "weekly";
    saveLocked();
}

std::string Core::addExpense(double amount, const std::string& category,
                             const std::string& note, const std::string& date) {
    if (!std::isfinite(amount)) return "";
    amount = std::round(amount * 100.0) / 100.0;
    if (amount <= 0) return "";
    std::lock_guard<std::mutex> lk(mu_);
    Expense e;
    e.id = newId();
    e.amount = amount;
    e.category = trim(category).empty() ? "Food" : normalizeCategory(category);
    const std::string n = cleanNote(note);
    e.note = n.empty() ? e.category + " expense" : n;
    long long ignore;
    e.date = isoToDays(date, ignore) ? date : today();
    e.time = nowTime();
    expenses_.insert(expenses_.begin(), e);  // newest first, like unshift()
    saveLocked();
    return e.id;
}

double Core::deleteExpense(const std::string& id) {
    std::lock_guard<std::mutex> lk(mu_);
    for (auto it = expenses_.begin(); it != expenses_.end(); ++it) {
        if (it->id == id) {
            const double amt = it->amount;
            expenses_.erase(it);
            saveLocked();
            return amt;
        }
    }
    return -1.0;
}

int Core::clearExpenses() {
    std::lock_guard<std::mutex> lk(mu_);
    const int n = static_cast<int>(expenses_.size());
    expenses_.clear();
    saveLocked();
    return n;
}

void Core::resetAll() {
    std::lock_guard<std::mutex> lk(mu_);
    allowance_ = 0;
    savingsGoal_ = 0;
    cycle_ = "weekly";
    expenses_.clear();
    for (double& l : limits_) l = 0;   // the saved history of past cycles and the GCash records are kept
    topups_.clear();
    saveLocked();
}

// ---------------------------------------------------------- category limits

bool Core::setCategoryLimit(const std::string& category, double amount) {
    const int i = categoryIndex(category);
    if (i < 0 || !std::isfinite(amount) || amount < 0) return false;
    std::lock_guard<std::mutex> lk(mu_);
    limits_[i] = round2(amount);
    saveLocked();
    return true;
}

std::string Core::categoriesJson() const {
    std::lock_guard<std::mutex> lk(mu_);
    double spent[kCategoryCount] = {0, 0, 0, 0};
    int count[kCategoryCount] = {0, 0, 0, 0};
    for (const auto& e : expenses_) {
        const int i = categoryIndex(e.category);
        if (i >= 0) { spent[i] += e.amount; count[i]++; }
    }
    std::ostringstream o;
    o << "{\"categories\":[";
    for (int i = 0; i < kCategoryCount; i++) {
        const double limit = limits_[i];
        const double pct = limit > 0 ? spent[i] / limit * 100.0 : 0.0;
        const char* status = limit <= 0 ? "none" : (pct >= 100.0 ? "over" : (pct >= 80.0 ? "warn" : "ok"));
        if (i) o << ",";
        o << "{\"name\":\"" << kCategoryNames[i] << "\",\"spent\":" << num(round2(spent[i]))
          << ",\"count\":" << count[i] << ",\"limit\":" << num(limit)
          << ",\"percent\":" << num(pct, 4) << ",\"remaining\":" << num(limit > 0 ? round2(limit - spent[i]) : 0.0)
          << ",\"status\":\"" << status << "\"}";
    }
    o << "]}";
    return o.str();
}

// ----------------------------------------------------------- cycle history

bool Core::newCycle() {
    std::lock_guard<std::mutex> lk(mu_);
    bool archived = false;
    if (!expenses_.empty()) {
        CycleRecord r;
        r.cycle = cycle_;
        r.allowance = round2(effectiveAllowance());
        r.added = round2(topupTotal());
        r.savingsGoal = std::max(0.0, savingsGoal_);
        std::string first = expenses_[0].date, last = expenses_[0].date;
        double total = 0;
        for (const auto& e : expenses_) {
            total += e.amount;
            const int i = categoryIndex(e.category);
            if (i >= 0) r.byCategory[i] += e.amount;
            if (e.date < first) first = e.date;
            if (e.date > last) last = e.date;
        }
        const std::string t = today();
        r.start = first;
        r.end = t > last ? t : last;
        r.spent = round2(total);
        for (double& v : r.byCategory) v = round2(v);
        r.count = static_cast<int>(expenses_.size());
        history_.push_back(r);
        while (history_.size() > static_cast<size_t>(kMaxHistory)) history_.erase(history_.begin());
        archived = true;
    }
    expenses_.clear();
    topups_.clear();   // the new cycle starts from the base allowance again
    saveLocked();
    return archived;
}

void Core::clearHistory() {
    std::lock_guard<std::mutex> lk(mu_);
    history_.clear();
    saveLocked();
}

std::string Core::historyJson() const {
    std::lock_guard<std::mutex> lk(mu_);
    std::ostringstream o;
    o << "{\"cycles\":[";
    for (size_t k = history_.size(); k-- > 0;) {          // newest first
        const CycleRecord& r = history_[k];
        long long d0 = 0, d1 = 0;
        isoToDays(r.start, d0);
        isoToDays(r.end, d1);
        const long long days = std::max<long long>(1, d1 - d0 + 1);
        const double saved = round2(r.allowance - r.spent);
        const bool goalMet = r.savingsGoal > 0 ? saved >= r.savingsGoal : saved >= 0;
        if (k + 1 != history_.size()) o << ",";
        o << "{\"start\":\"" << r.start << "\",\"end\":\"" << r.end << "\",\"cycle\":\"" << r.cycle
          << "\",\"allowance\":" << num(r.allowance) << ",\"added\":" << num(r.added)
          << ",\"savingsGoal\":" << num(r.savingsGoal)
          << ",\"spent\":" << num(r.spent) << ",\"saved\":" << num(saved)
          << ",\"goalMet\":" << (goalMet ? "true" : "false") << ",\"count\":" << r.count
          << ",\"days\":" << days << ",\"avgDaily\":" << num(round2(r.spent / static_cast<double>(days)))
          << ",\"byCategory\":{";
        for (int i = 0; i < kCategoryCount; i++) {
            if (i) o << ",";
            o << "\"" << kCategoryNames[i] << "\":" << num(r.byCategory[i]);
        }
        o << "},\"hasPrev\":" << (k > 0 ? "true" : "false")
          << ",\"deltaSpent\":" << num(k > 0 ? round2(r.spent - history_[k - 1].spent) : 0.0) << "}";
    }
    o << "]}";
    return o.str();
}

// ------------------------------------------------------------------ add money

double Core::topupTotal() const {
    double t = 0;
    for (const auto& x : topups_) t += x.amount;
    return round2(t);
}

double Core::effectiveAllowance() const { return allowance_ + topupTotal(); }

std::string Core::addMoney(double amount, const std::string& note, const std::string& date) {
    if (!std::isfinite(amount)) return "";
    amount = round2(amount);
    if (amount <= 0) return "";
    std::lock_guard<std::mutex> lk(mu_);
    TopUp t;
    t.id = newId();
    t.amount = amount;
    t.note = cleanNote(note);
    long long ignore;
    t.date = isoToDays(date, ignore) ? date : today();
    t.time = nowTime();
    topups_.insert(topups_.begin(), t);   // newest first
    saveLocked();
    return t.id;
}

double Core::deleteMoney(const std::string& id) {
    std::lock_guard<std::mutex> lk(mu_);
    for (auto it = topups_.begin(); it != topups_.end(); ++it) {
        if (it->id == id) {
            const double amt = it->amount;
            topups_.erase(it);
            saveLocked();
            return amt;
        }
    }
    return -1.0;
}

// ------------------------------------------------------------------- GCash

std::string Core::gcashAdd(const std::string& type, double amount, double fee, const std::string& category,
                           const std::string& note, const std::string& date) {
    const std::string ty = lower(trim(type));
    if ((ty != "in" && ty != "out") || !std::isfinite(amount)) return "";
    amount = round2(amount);
    if (amount <= 0) return "";
    fee = (std::isfinite(fee) && fee > 0) ? round2(fee) : 0.0;
    std::lock_guard<std::mutex> lk(mu_);
    GcashEntry g;
    g.id = newId();
    g.type = ty;
    g.amount = amount;
    g.fee = fee;
    g.category = gcashCategory(ty == "in", category);
    const std::string n = cleanNote(note);
    g.note = n.empty() ? g.category : n;
    long long ignore;
    g.date = isoToDays(date, ignore) ? date : today();
    g.time = nowTime();
    gcash_.insert(gcash_.begin(), g);
    saveLocked();
    return g.id;
}

bool Core::gcashDelete(const std::string& id) {
    std::lock_guard<std::mutex> lk(mu_);
    for (auto it = gcash_.begin(); it != gcash_.end(); ++it) {
        if (it->id == id) {
            gcash_.erase(it);
            saveLocked();
            return true;
        }
    }
    return false;
}

void Core::gcashClear() {
    std::lock_guard<std::mutex> lk(mu_);
    gcash_.clear();
    saveLocked();
}

std::string Core::gcashJson() const {
    std::lock_guard<std::mutex> lk(mu_);
    double totalIn = 0, totalOut = 0, totalFees = 0;
    double spent[kGcashOutCount] = {0, 0, 0, 0, 0, 0};
    int count[kGcashOutCount] = {0, 0, 0, 0, 0, 0};
    for (const auto& g : gcash_) {
        totalFees += g.fee;
        if (g.type == "in") {
            totalIn += g.amount;
        } else {
            totalOut += g.amount;
            for (int i = 0; i < kGcashOutCount; i++)
                if (g.category == kGcashOutNames[i]) { spent[i] += g.amount; count[i]++; }
        }
    }
    totalIn = round2(totalIn); totalOut = round2(totalOut); totalFees = round2(totalFees);
    std::ostringstream o;
    o << "{\"balance\":" << num(round2(totalIn - totalOut - totalFees)) << ",\"totalIn\":" << num(totalIn)
      << ",\"totalOut\":" << num(totalOut) << ",\"totalFees\":" << num(totalFees)
      << ",\"count\":" << gcash_.size() << ",\"outCategories\":[";
    for (int i = 0; i < kGcashOutCount; i++) {
        if (i) o << ",";
        o << "{\"name\":\"" << kGcashOutNames[i] << "\",\"spent\":" << num(round2(spent[i]))
          << ",\"count\":" << count[i] << ",\"percent\":" << num(totalOut > 0 ? spent[i] / totalOut * 100.0 : 0.0, 4) << "}";
    }
    o << "],\"entries\":[";
    for (size_t i = 0; i < gcash_.size(); i++) {
        const auto& g = gcash_[i];
        if (i) o << ",";
        o << "{\"id\":\"" << jsonEscape(g.id) << "\",\"type\":\"" << g.type << "\",\"category\":\""
          << jsonEscape(g.category) << "\",\"note\":\"" << jsonEscape(g.note) << "\",\"amount\":" << num(g.amount)
          << ",\"fee\":" << num(g.fee) << ",\"date\":\"" << jsonEscape(g.date) << "\",\"time\":\""
          << jsonEscape(g.time) << "\"}";
    }
    o << "]}";
    return o.str();
}

// ---------------------------------------------------------------- summary

std::string Core::summaryText() const {
    std::lock_guard<std::mutex> lk(mu_);
    const Metrics m = computeLocked();
    const double eff = effectiveAllowance();
    const double added = topupTotal();
    std::ostringstream o;

    o << "BAONTRACK SUMMARY\n";
    o << (cycle_ == "weekly" ? "Weekly" : "Monthly") << " cycle (" << m.totalDaysInCycle << " days)";
    if (m.cycleStarted) {
        const bool sameYear = m.cycleStart.substr(0, 4) == m.cycleEnd.substr(0, 4);
        o << " · " << prettyDate(m.cycleStart, !sameYear) << " – " << prettyDate(m.cycleEnd, true) << "\n";
        if (m.cycleEnded)
            o << "Cycle ended " << plural(m.cycleDaysOver, "day") << " ago\n";
        else if (m.cycleDaysLeft == 0)
            o << "Day " << m.cycleDay << " of " << m.totalDaysInCycle << " · last day\n";
        else
            o << "Day " << m.cycleDay << " of " << m.totalDaysInCycle << " · " << plural(m.cycleDaysLeft, "day") << " left\n";
    } else {
        o << "\nCycle not started yet (it starts with your first expense)\n";
    }
    o << "\n";

    if (eff > 0) {
        o << "Allowance: " << peso(eff);
        if (added > 0) o << " (" << peso(allowance_) << " + " << peso(added) << " added)";
        o << "\n";
        o << "Total spent: " << peso(m.totalSpent) << " (" << num(m.percentUsed, 1) << "% of allowance)\n";
    } else {
        o << "Allowance: not set\n";
        o << "Total spent: " << peso(m.totalSpent) << "\n";
    }
    o << (m.remaining < 0 ? "Overspent by: " : "Remaining: ") << peso(std::fabs(m.remaining)) << "\n";
    if (m.savingsGoal > 0) {
        const double diff = m.remaining - m.savingsGoal;
        o << "Savings goal: " << peso(m.savingsGoal) << " · "
          << (diff >= 0 ? "on track (" + peso(diff) + " above the goal)" : "short by " + peso(-diff)) << "\n";
    }
    if (eff > 0 && m.remaining >= 0)
        o << "Savings rate: " << num(m.remaining / eff * 100.0, 1) << "% of your allowance is still unspent\n";

    double spent[kCategoryCount] = {0, 0, 0, 0};
    for (const auto& e : expenses_) {
        const int i = categoryIndex(e.category);
        if (i >= 0) spent[i] += e.amount;
    }
    int biggest = -1;
    for (int i = 0; i < kCategoryCount; i++)
        if (spent[i] > 0 && (biggest < 0 || spent[i] > spent[biggest])) biggest = i;

    if (expenses_.empty()) {
        o << "\nNo expenses logged in this cycle yet.\n";
    } else {
        o << "\nBiggest category: " << kCategoryNames[biggest] << " — " << peso(spent[biggest]) << " ("
          << num(spent[biggest] / m.totalSpent * 100.0, 1) << "% of spending)\n";
        o << "Spending by category:\n";
        for (int i = 0; i < kCategoryCount; i++) {
            if (spent[i] <= 0 && limits_[i] <= 0) continue;
            o << "  - " << kCategoryNames[i] << ": " << peso(spent[i]) << " ("
              << num(m.totalSpent > 0 ? spent[i] / m.totalSpent * 100.0 : 0.0, 1) << "%)";
            if (limits_[i] > 0)
                o << " · limit " << peso(limits_[i]) << ", " << num(spent[i] / limits_[i] * 100.0, 0) << "% used";
            o << "\n";
        }
        o << "\nTransactions: " << expenses_.size() << " · average " << peso(m.txAverage) << " per entry · "
          << peso(m.dailyAverage) << " per day\n";
    }
    if (eff > 0) o << "Safe to spend today: " << peso(m.safeDailySpend) << "\n";
    return o.str();
}

// -------------------------------------------------------------- estimation

std::string Core::estimateJson(double dailySpend, int days, double budget, double saveTarget) {
    auto money = [](double v) { return std::isfinite(v) ? std::round(v * 100.0) / 100.0 : 0.0; };
    if (!std::isfinite(dailySpend) || dailySpend < 0) dailySpend = 0;
    if (!std::isfinite(budget) || budget < 0) budget = 0;
    days = std::min(365, std::max(1, days));
    dailySpend = money(dailySpend);
    budget = money(budget);

    const double total = money(dailySpend * days);
    const double left = money(budget - total);
    const bool over = left < 0;
    const double percentUsed = budget > 0 ? total / budget * 100.0 : (total > 0 ? 100.0 : 0.0);
    // how many whole days the budget covers at this pace (-1 = no daily spending entered)
    const long long lastsDays = dailySpend > 0 ? static_cast<long long>(std::floor(budget / dailySpend + 1e-9)) : -1;

    const bool hasTarget = std::isfinite(saveTarget) && saveTarget >= 0;
    const double target = hasTarget ? money(saveTarget) : 0.0;
    const bool targetOk = hasTarget && target <= budget;
    const double maxTotal = targetOk ? money(budget - target) : 0.0;
    const double maxDaily = targetOk ? money(maxTotal / days) : 0.0;
    const bool warn60 = hasTarget && (budget > 0 ? target / budget * 100.0 > 60.0 : target > 0);

    std::ostringstream o;
    o << "{\"dailySpend\":" << num(dailySpend) << ",\"days\":" << days << ",\"budget\":" << num(budget)
      << ",\"total\":" << num(total) << ",\"left\":" << num(left)
      << ",\"over\":" << (over ? "true" : "false") << ",\"overBy\":" << num(over ? -left : 0.0)
      << ",\"percentUsed\":" << num(percentUsed, 4) << ",\"lastsDays\":" << lastsDays
      << ",\"maxDailyInBudget\":" << num(money(budget / days)) << ",\"weekTotal\":" << num(money(dailySpend * 7))
      << ",\"monthTotal\":" << num(money(dailySpend * 30)) << ",\"hasTarget\":" << (hasTarget ? "true" : "false")
      << ",\"target\":" << num(target) << ",\"targetOk\":" << (targetOk ? "true" : "false")
      << ",\"maxTotalForTarget\":" << num(maxTotal) << ",\"maxDailyForTarget\":" << num(maxDaily)
      << ",\"warn60\":" << (warn60 ? "true" : "false") << "}";
    return o.str();
}

// ------------------------------------------------------------------- CSV

std::string Core::exportLocked(bool withBom) const {
    const Metrics m = computeLocked();
    std::string out = withBom ? "\xEF\xBB\xBF" : "";
    auto row = [&](std::initializer_list<std::string> cols) {
        bool first = true;
        for (const auto& c : cols) {
            if (!first) out += ",";
            out += csvField(c);
            first = false;
        }
        out += "\r\n";
    };
    row({"BAONTRACK SUMMARY", "VALUE"});
    row({"Cycle", cycle_ == "weekly" ? "Weekly (7d)" : "Monthly (30d)"});
    row({"Allowance", num(allowance_)});
    row({"Savings Goal", num(m.savingsGoal)});
    for (int i = 0; i < kCategoryCount; i++)
        if (limits_[i] > 0) row({std::string("Limit ") + kCategoryNames[i], num(limits_[i])});
    row({"Total Spent", num(m.totalSpent)});
    row({"Remaining Balance", num(m.remaining)});
    out += "\r\n";
    row({"Date", "Category", "Description", "Amount", "Time"});
    std::vector<Expense> sorted = expenses_;
    std::stable_sort(sorted.begin(), sorted.end(),
                     [](const Expense& a, const Expense& b) { return a.date > b.date; });
    for (const auto& e : sorted) row({e.date, e.category, e.note, num(e.amount), e.time});
    if (!topups_.empty()) {
        out += "\r\n";
        row({"MONEY ADDED", ""});
        row({"Date", "Time", "Amount", "Note"});
        for (const auto& t : topups_) row({t.date, t.time, num(t.amount), t.note});
    }
    if (!gcash_.empty()) {
        out += "\r\n";
        row({"GCASH", ""});
        row({"Date", "Time", "Type", "Category", "Description", "Amount", "Fee"});
        for (const auto& g : gcash_) row({g.date, g.time, g.type, g.category, g.note, num(g.amount), num(g.fee)});
    }
    if (!history_.empty()) {
        out += "\r\n";
        row({"CYCLE HISTORY", ""});
        row({"Start", "End", "Cycle", "Allowance", "Savings Goal", "Total Spent", "Transactions",
             "Food", "School", "Personal", "Strolling", "Added"});
        for (const auto& r : history_)
            row({r.start, r.end, r.cycle == "weekly" ? "Weekly (7d)" : "Monthly (30d)", num(r.allowance),
                 num(r.savingsGoal), num(r.spent), std::to_string(r.count), num(r.byCategory[0]),
                 num(r.byCategory[1]), num(r.byCategory[2]), num(r.byCategory[3]), num(r.added)});
    }
    return out;
}

std::string Core::exportCsv(bool withBom) const {
    std::lock_guard<std::mutex> lk(mu_);
    return exportLocked(withBom);
}

ImportResult Core::importLocked(const std::string& rawIn) {
    ImportResult res;
    std::string text = rawIn;
    if (text.compare(0, 3, "\xEF\xBB\xBF") == 0) text.erase(0, 3);

    std::vector<std::string> lines;
    {
        std::string cur;
        std::istringstream ss(text);
        while (std::getline(ss, cur)) {
            cur = trim(cur);
            if (!cur.empty()) lines.push_back(cur);
        }
    }
    if (lines.empty()) { res.error = "The selected CSV file is empty."; return res; }

    bool haveAllow = false, haveSave = false, haveCycle = false, inExpenses = false;
    bool inHistory = false, haveHistory = false;
    bool inMoney = false, haveMoney = false, inGcash = false, haveGcash = false;
    std::vector<TopUp> impMoney;
    std::vector<GcashEntry> impGcash;
    double impAllow = 0, impSave = 0;
    double impLimit[kCategoryCount] = {0, 0, 0, 0};
    bool haveLimit[kCategoryCount] = {false, false, false, false};
    std::string impCycle;
    std::vector<Expense> imported;
    std::vector<CycleRecord> impHistory;

    for (size_t i = 0; i < lines.size(); i++) {
        const auto cols = parseCsvLine(lines[i]);
        const std::string c0 = trim(cols.empty() ? "" : cols[0]);
        const std::string c0l = lower(c0);
        const bool hasC1 = cols.size() > 1;

        if (c0l == "baontrack summary") { inExpenses = inHistory = inMoney = inGcash = false; continue; }
        if (c0l == "cycle history") { inExpenses = inMoney = inGcash = false; inHistory = true; haveHistory = true; continue; }
        if (c0l == "money added") { inExpenses = inHistory = inGcash = false; inMoney = true; haveMoney = true; continue; }
        if (c0l == "gcash") { inExpenses = inHistory = inMoney = false; inGcash = true; haveGcash = true; continue; }
        if (inMoney) {
            if (c0l == "date" && hasC1 && lower(cols[1]) == "time") continue;   // column titles
            long long d0;
            if (cols.size() >= 3 && isoToDays(c0, d0)) {
                const double amt = parseMoney(cols[2]);
                if (!std::isnan(amt) && amt > 0) {
                    TopUp t;
                    t.id = newId();
                    t.date = c0;
                    t.time = isValidTime(cols[1]) ? cols[1] : "";
                    t.amount = round2(amt);
                    t.note = cols.size() > 3 ? truncateUtf8(cols[3], 60) : "";
                    if (t.amount > 0) impMoney.push_back(t);
                }
            }
            continue;
        }
        if (inGcash) {
            if (c0l == "date" && hasC1 && lower(cols[1]) == "time") continue;   // column titles
            long long d0;
            if (cols.size() >= 6 && isoToDays(c0, d0)) {
                const std::string ty = lower(cols[2]);
                const double amt = parseMoney(cols[5]);
                const double fee = cols.size() > 6 ? parseMoney(cols[6]) : 0.0;
                if ((ty == "in" || ty == "out") && !std::isnan(amt) && amt > 0) {
                    GcashEntry g;
                    g.id = newId();
                    g.type = ty;
                    g.date = c0;
                    g.time = isValidTime(cols[1]) ? cols[1] : "";
                    g.category = gcashCategory(ty == "in", cols[3]);
                    g.note = truncateUtf8(cols[4], 60);
                    if (g.note.empty()) g.note = g.category;
                    g.amount = round2(amt);
                    g.fee = (!std::isnan(fee) && fee > 0) ? round2(fee) : 0.0;
                    if (g.amount > 0) impGcash.push_back(g);
                }
            }
            continue;
        }
        if (inHistory) {
            if (c0l == "start" && hasC1 && lower(cols[1]) == "end") continue;   // column titles
            long long d0, d1;
            if (cols.size() >= 6 && isoToDays(c0, d0) && isoToDays(cols[1], d1)) {
                CycleRecord r;
                r.start = c0;
                r.end = cols[1];
                r.cycle = lower(cols[2]).find("monthly") != std::string::npos ? "monthly" : "weekly";
                const double allow = parseMoney(cols[3]), save = parseMoney(cols[4]), spent = parseMoney(cols[5]);
                if (!std::isnan(allow) && !std::isnan(save) && !std::isnan(spent) && allow >= 0 && save >= 0 && spent >= 0) {
                    r.allowance = round2(allow);
                    r.savingsGoal = round2(save);
                    r.spent = round2(spent);
                    r.count = cols.size() > 6 ? std::max(0, std::atoi(cols[6].c_str())) : 0;
                    const double addedV = cols.size() > 11 ? parseMoney(cols[11]) : std::nan("");
                    r.added = (!std::isnan(addedV) && addedV > 0) ? round2(addedV) : 0.0;
                    for (int k = 0; k < kCategoryCount; k++) {
                        const double v = cols.size() > static_cast<size_t>(7 + k) ? parseMoney(cols[7 + k]) : std::nan("");
                        r.byCategory[k] = (!std::isnan(v) && v > 0) ? round2(v) : 0.0;
                    }
                    impHistory.push_back(r);
                }
            }
            continue;
        }
        if (!inExpenses && c0l == "cycle" && hasC1 && !cols[1].empty()) {
            impCycle = lower(cols[1]).find("monthly") != std::string::npos ? "monthly" : "weekly";
            haveCycle = true;
            continue;
        }
        if (!inExpenses && c0l == "allowance" && hasC1) {
            const double v = parseMoney(cols[1]);
            if (!std::isnan(v) && v >= 0) { impAllow = v; haveAllow = true; }
            continue;
        }
        if (!inExpenses && c0l == "savings goal" && hasC1) {
            const double v = parseMoney(cols[1]);
            if (!std::isnan(v) && v >= 0) { impSave = v; haveSave = true; }
            continue;
        }
        if (!inExpenses && c0l.compare(0, 6, "limit ") == 0 && hasC1) {
            const int idx = categoryIndex(c0.substr(6));
            const double v = parseMoney(cols[1]);
            if (idx >= 0 && !std::isnan(v) && v >= 0) { impLimit[idx] = v; haveLimit[idx] = true; }
            continue;
        }
        if (!inExpenses && (c0l == "total spent" || c0l == "remaining balance")) continue;
        if (c0l == "date" && hasC1 && lower(cols[1]) == "category") { inExpenses = true; continue; }

        if (inExpenses || cols.size() >= 4) {
            const std::string rawCat = (cols.size() > 1 && !cols[1].empty()) ? cols[1] : "Food";
            const std::string cat = normalizeCategory(rawCat);
            std::string note = (cols.size() > 2 && !cols[2].empty()) ? cols[2] : cat + " expense";
            const double amt = cols.size() > 3 ? parseMoney(cols[3]) : std::nan("");
            if (!std::isnan(amt) && amt > 0) {
                Expense e;
                e.id = newId();
                e.date = c0;
                long long ignore;
                if (!isoToDays(e.date, ignore)) e.date = today();
                e.category = cat;
                if (cols.size() > 4 && isValidTime(cols[4])) e.time = cols[4];
                e.note = truncateUtf8(note, 60);
                e.amount = std::round(amt * 100.0) / 100.0;
                if (e.amount > 0) imported.push_back(e);
            }
        }
    }

    const bool haveSummary = haveAllow || haveSave || haveCycle;
    bool anyLimit = false;
    for (bool b : haveLimit) anyLimit = anyLimit || b;
    const bool hasMeta = haveSummary || anyLimit || haveHistory || haveMoney || haveGcash;
    if (!hasMeta && imported.empty()) {
        res.error = "No valid BaonTrack summary or expense rows found in CSV.";
        return res;
    }
    const int importedCount = static_cast<int>(imported.size());
    if (haveCycle) cycle_ = impCycle;
    if (haveAllow) allowance_ = std::round(impAllow * 100.0) / 100.0;
    if (haveSave) savingsGoal_ = std::round(impSave * 100.0) / 100.0;
    if (haveSummary || anyLimit) {
        // a backup lists only the limits that are set, so every other category goes back to "no limit"
        for (int i = 0; i < kCategoryCount; i++) limits_[i] = haveLimit[i] ? round2(impLimit[i]) : 0.0;
    }
    if (haveMoney) topups_ = impMoney;
    else if (haveSummary) topups_.clear();   // a backup without a "MONEY ADDED" block had none
    if (haveGcash) gcash_ = impGcash;        // GCash is separate data: only replaced when the file has it
    if (haveHistory) {
        history_ = impHistory;
        while (history_.size() > static_cast<size_t>(kMaxHistory)) history_.erase(history_.begin());
    }
    if (!imported.empty()) {
        if (hasMeta) {
            expenses_ = imported;
        } else {
            imported.insert(imported.end(), expenses_.begin(), expenses_.end());
            expenses_ = imported;
        }
    }
    res.ok = true;
    res.imported = importedCount;
    res.hasMetadata = hasMeta;
    return res;
}

ImportResult Core::importCsv(const std::string& text) {
    std::lock_guard<std::mutex> lk(mu_);
    ImportResult r = importLocked(text);
    if (r.ok) saveLocked();
    return r;
}

std::string Core::importResultJson(const ImportResult& r) {
    std::ostringstream o;
    o << "{\"ok\":" << (r.ok ? "true" : "false") << ",\"imported\":" << r.imported
      << ",\"hasMetadata\":" << (r.hasMetadata ? "true" : "false") << ",\"error\":\""
      << jsonEscape(r.error) << "\"}";
    return o.str();
}

}  // namespace baon
